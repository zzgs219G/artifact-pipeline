#!/usr/bin/env bash
# migrate-r2-secrets.sh — 把 R2 secrets 一次性灌进目标仓库
#
# 为什么需要它：GitHub 的 secret 是【只写不读】，迁仓库不会带走。
# 唯一能做的就是把「值」重新灌一次。本脚本把 5 次手工操作压成 1 次，
# 且用一次粘贴完成，不用在 5 个提示之间来回切。
#
# 用法（在本机跑，需要 gh 已登录且有目标仓库 admin 权限）：
#   ./migrate-r2-secrets.sh <owner/repo>
#
# 脚本会要求你粘贴 5 行，格式：KEY=VALUE
# 空行/以 # 开头的行忽略，所以可以整段贴进去。
set -euo pipefail

REPO="${1:-}"
[[ -n "$REPO" ]] || { echo "用法: $0 <owner/repo>" >&2; exit 2; }

command -v gh >/dev/null || { echo "❌ 缺 gh CLI" >&2; exit 1; }
gh auth status >/dev/null 2>&1 || { echo "❌ gh 未登录，先 gh auth login" >&2; exit 1; }

echo "目标仓库: $REPO"
echo "现有的 secrets（迁移前）:"
gh secret list --repo "$REPO" 2>/dev/null || echo "  （空）"
echo

cat <<'TIP'
请粘贴 5 行，每行 KEY=VALUE（可从 Cloudflare 控制台 R2 页面复制）：

  R2_ACCESS_KEY=<Access Key ID>
  R2_SECRET_KEY=<Secret Access Key>
  R2_ENDPOINT=https://<account-id>.r2.cloudflarestorage.com
  R2_BUCKET=<bucket 名>
  R2_PUBLIC_DOMAIN=https://<你的 R2 公开域名>

贴完按 Ctrl-D 结束。
TIP
echo

# 从 stdin 读全部 KEY=VALUE，逐条 set。
# ⚠️ 用 stdin 传值，值不出现在命令行参数里
#    （否则会进 shell history 和 ps 输出）。
count=0
while IFS='=' read -r key val; do
    # 跳过空行与注释；去掉可能的首尾空白与 CR（Windows 粘贴常见）
    key="$(printf '%s' "$key" | tr -d '[:space:]')"
    [[ -z "$key" || "$key" == \#* ]] && continue
    val="$(printf '%s' "$val" | sed 's/\r$//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
    [[ -n "$val" ]] || { echo "  ⚠ 跳过 $key（值为空）"; continue; }

    printf '  → %s ... ' "$key"
    if printf '%s' "$val" | gh secret set "$key" --repo "$REPO" >/dev/null 2>&1; then
        echo "✅"
        count=$((count + 1))
    else
        echo "❌ 失败"
    fi
done

echo
echo "已设置 $count 个 secret。"
echo "当前 secrets:"
gh secret list --repo "$REPO" 2>/dev/null || echo "  （空）"
