#!/usr/bin/env python3
"""r2_probe.py — 用 SigV4 直连 R2，验证凭证是否有效（不依赖 aws cli / boto3）

用途：GitHub Secrets 配好后，先确认"这把钥匙真能写"，再跑整条加固流水线——
否则每次都要等 1 分钟构建才知道凭证错了。

用法：
    python3 r2_probe.py <access_key> <secret_key> <endpoint_host> <bucket>

安全提醒：
  · 凭证别硬编码进本文件，从命令行/环境变量传
  · 跑完建议清 shell history（值会进历史记录）
"""
import datetime
import hashlib
import hmac
import sys
import urllib.error
import urllib.request


def _sign(key: bytes, msg: str) -> bytes:
    return hmac.new(key, msg.encode(), hashlib.sha256).digest()


def put_object(ak: str, sk: str, ep: str, bucket: str, obj: str, body: bytes) -> int:
    """PUT 一个对象，返回 HTTP 状态码（200/201 即凭证有效）。"""
    t = datetime.datetime.now(datetime.timezone.utc)
    amzdate = t.strftime("%Y%m%dT%H%M%SZ")
    datestamp = t.strftime("%Y%m%d")
    region = "auto"

    payload_hash = hashlib.sha256(body).hexdigest()
    canonical_uri = f"/{bucket}/{obj}"
    canonical_headers = (
        f"host:{ep}\n"
        f"x-amz-content-sha256:{payload_hash}\n"
        f"x-amz-date:{amzdate}\n"
    )
    signed_headers = "host;x-amz-content-sha256;x-amz-date"
    canonical_request = (
        f"PUT\n{canonical_uri}\n\n{canonical_headers}\n"
        f"{signed_headers}\n{payload_hash}"
    )
    scope = f"{datestamp}/{region}/s3/aws4_request"
    string_to_sign = (
        f"AWS4-HMAC-SHA256\n{amzdate}\n{scope}\n"
        + hashlib.sha256(canonical_request.encode()).hexdigest()
    )

    k = _sign(("AWS4" + sk).encode(), datestamp)
    k = _sign(k, region)
    k = _sign(k, "s3")
    k = _sign(k, "aws4_request")
    sig = hmac.new(k, string_to_sign.encode(), hashlib.sha256).hexdigest()

    auth = (
        f"AWS4-HMAC-SHA256 Credential={ak}/{scope}, "
        f"SignedHeaders={signed_headers}, Signature={sig}"
    )
    req = urllib.request.Request(
        f"https://{ep}/{bucket}/{obj}",
        data=body,
        method="PUT",
        headers={
            "x-amz-content-sha256": payload_hash,
            "x-amz-date": amzdate,
            "Authorization": auth,
            "Content-Length": str(len(body)),
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status
    except urllib.error.HTTPError as e:
        print(f"  HTTP {e.code}: {e.read()[:300].decode('utf-8', 'replace')}", file=sys.stderr)
        return e.code
    except Exception as e:  # noqa: BLE001
        print(f"  异常: {e}", file=sys.stderr)
        return -1


def main() -> int:
    if len(sys.argv) != 5:
        print(__doc__)
        return 2
    ak, sk, ep, bucket = sys.argv[1:]
    print(f"endpoint: {ep}")
    print(f"bucket:   {bucket}")
    code = put_object(ak, sk, ep, bucket, "probe/r2-probe.txt", b"r2 probe")
    if code in (200, 201):
        print(f"✅ 凭证有效（PUT 返回 {code}）")
        return 0
    print(f"❌ 凭证无效或被拒（返回 {code}）")
    return 1


if __name__ == "__main__":
    sys.exit(main())
