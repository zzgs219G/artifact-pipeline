# 三分钟上手

## 1. 解压

    unzip nox-*.zip && cd nox

## 2. 先跑自测，确认工具链正常

    ./test.sh

应该看到 `13 通过 0 失败`。用的是包内自带的测试 APK，与任何真实包无关。

## 3. 看看完整例子

    cd example && ./run.sh

它会：编译 → 加密 → 对比加密前后的机器码 → 运行验证返回正确。
**这一步最直观**：你会看到加密前 `mov w0, #0x5ff` 一眼看懂，
加密后连函数都反汇编不出来了。

## 4. 用你自己的代码

改 `example/mycode.c`，给你要保护的函数加两行：

    __attribute__((section(".ncx"), used, retain))
    int 你的函数(void) { ... }

然后：

    cd example
    ./run.sh /path/to/你的签名APK 你的包名

或者直接用工具：

    ./nox protect 你的代码.c --apk 你的签名APK -o libyour.so

产物放进 APK 的 `lib/arm64-v8a/` 目录。

---

# 必须知道的四条

## 1. 必须给 APK，不能只给 so

密钥由 **APK 的签名证书**派生。运行时从已安装的 APK 重读证书，
读不到就拒绝解密（返回 -12）。

所以它只能保护**Android App 里的 so**，不能保护独立 so / Linux 程序。

## 2. 只能保护你加过标记的函数，且必须重新编译

不能加密已经编好的成品 so —— 没有 `.ncx` 段就没有可加密的东西。

## 3. 用错 APK 会解不开

`--apk` 必须是**最终签名用的那个证书**对应的包。
换 keystore 重签 → 证书变 → 解不开。这是设计，不是 bug。

## 4. 挡的是静态分析，不是动态调试

代码要执行，就必然有明文的一刻。有 Frida 的人可以蹲到那个瞬间。
这套东西的作用是：`strings`、反汇编、静态审计这些手段失效。

---

# 常见问题

**Q: 加密后函数名还在吗？**
默认不在。`nox protect` 会自动 strip。但如果你给函数加了
`visibility("default")`，名字会留在 `.dynstr`（strip 删不掉动态符号表）——
只有需要从 Java 侧 dlsym 的 JNI 入口才该加。

**Q: 提示 "产物里没有 .ncx 段"？**
你的代码没用 `__attribute__((section(".ncx"), used, retain))` 标任何函数。
参考 `fixtures/sample.c`。

**Q: 运行返回 -11？**
MAC 校验失败。常见原因：锁箱用了 `--section .ncx` 但产物里有 `.ncxr`
（两边覆盖范围不一致）。`nox protect` 会自动探测所有段，不会踩这个坑。

**Q: 想保护常量表？**
用 `.ncxr` 而不是 `.ncx`（clang 不允许 const 数据进可执行段）。
注意常量必须真的被代码引用，否则会被 `--gc-sections` 回收。
详见 `fixtures/sample.c` 里的注释。
