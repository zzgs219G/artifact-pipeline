# 三分钟上手（静态库形态）

本包**不含 C 源码**，加密设施以 `so-guard/lib/<abi>/libnox.a` 形式提供。

## 1. 解压并自测

    unzip nox-*.zip && cd nox
    ./test.sh

## 2. 用你自己的代码

    ./nox protect 你的代码.c --apk 你的签名APK -o libyour.so --abi arm64-v8a

## 必须知道的三条

1. **链接必须加 `-Wl,--whole-archive`**
   `ncguard_unlock` 是 constructor，无人显式引用 → 默认会被丢弃。
   不加的后果：加密段 5 个塌成 1 个，连 unlock 都不见了。
   `nox` 工具已自动处理；手工链接时要自己加。

2. **`.a` 与 NDK/编译器版本绑定**
   用 clang-XX 编的 `.o` 不能和 clang-YY 混链。请用配套 NDK 版本。

3. **Python 工具仍是明文**
   `so-section-lock.py`（锁箱算法）无法编译，锁箱格式依然公开。
   本形态藏的是 C 实现，不是锁箱协议。
