#!/usr/bin/env python3
"""so-section-lock.py — 把 so 的代码段加密锁死（构建期"锁箱"）

威胁模型：攻击者拿 libnc.so，用 IDA/Ghidra + LLM 静态分析。
作用：把标记过的代码段用 RC4 加密后写回 so 文件，磁盘上的段是密文。
      运行时由 libnc.so 自己解密（配套运行期"开箱"代码）。
      这不是防住，是推高 AI 静态分析的 token 消耗。

威胁由来（2026-12）：so 原本只有 -fvisibility=hidden/-Oz/strip 这类
编译瘦身，没有任何一层作用在【函数体可读性】上。XopProtector 的
.bitcode 自解密段是业界成熟做法，本脚本是其"锁箱"半边的等价实现。

2026-12 第二版追加 HMAC 完整性校验（加密段从"改坏"升级为"检测到"）：
  对【密文】算 HMAC-SHA256，密钥用独立的 mac 域（label "nc-so-mac-v1"，
  绝不复用 so 域——复用等于"知道 RC4 密钥就能伪造 MAC"，校验形同虚设）。

  ⚠️⚠️ 2026-10-20：本文件此前通篇使用 2026-10-19 改名前的旧段名
  （.ncguard / .ncguard_ro / .ncguard_head / .ncguard_head_ro /
   .nckey / .nckey_stub），与实际操作的常量（SECTION_NAME / SLOT_NAME /
  HEAD_NAME / HEAD_RO_NAME / STUB_SLOT）名实不符 —— 读者按注释里的旧名
  去搜代码会搜不到。现已全部改为现行名。

  段名对照表（旧名 → 现行名，改段名前先查此表）：
    .ncguard          → .ncx     加密代码段（AXR）
    .ncguard_ro       → .ncxr    加密常量表（AWR）
    .ncguard_head     → .ncxh    unlock 本体（二级锁箱对象）
    .ncguard_head_ro  → .ncxhr   master 数据段（32B）
    .nckey            → .nck     一级密钥槽
    .nckey_stub       → .ncks    二级 stub 密钥槽

  ⚠️ scripts/sigcheck/archive/nc_guard_unlock.c 是历史存档（2026-10-20
  已移出 src/），【刻意保留旧名】—— 读到 .ncguard 说明那是旧版实现，
  不要照着改。它不参与任何构建。

  .nck slot 布局（96 字节，2026-10-19 P1-a 起；原 80 字节版见历史记录）：
    [0:16]  magic        seed + 8 个 0（seed 见 SLOT_MAGIC_SEED）
    [16:32] decoy        诱饵（P1-a 起非真密钥，真 k_so 由运行期证书派生）
    [32:48] decoy_mac    诱饵（同上）
    [48:80] expect_mac    HMAC-SHA256(k_mac, 密文)
    [80:88] pkg_sha8      SHA256(包名) 前 8 字节
    [88:96] reserved
  两侧契约：本文件 blob 组装 + assert len(blob)==96，C 侧 nc_guard_probe.c
  的 ncg_key_slot[96] 与 nc_guard_boot.c 的 NCG_SLOT_SIZE / NCG_OFF_*。

与 XopProtector 的对应关系（照抄逻辑、改名以清晰）：
  Xop: PROTECTOR_ENCRYPT 宏 → SECTION(".bitcode")        本: __attribute__((section(SECTION_NAME)))
  Xop: packer/SoSectionEncryptor.java (Java + Gradle)    本: 本脚本 (Python，protect.sh 可直接调)
  Xop: packer/KeyLadder.java HKDF 派生                   本: hkdf_labels() 同 label 规则
  Xop: section_decrypt.cpp decrypt_section()             本: 由运行期 C 代码负责（另行抄）

用法：
  so-section-lock.py <输入.so> <输出.so> [--section .ncx] [--dry-run]

设计约束：
  - size-preserving：加密后段长度不变（ELF 段大小固定，运行期原地解密）
  - 只加密自定义段（默认 .ncx），不动 .text/.rodata 等标准段
  - 幂等：重复锁同一文件 = 二次加密（会毁数据），故默认拒绝已锁文件，
    用 --force 才强制（仅调试用）
"""
import argparse
import hashlib
import math
import os
import re
import struct
import sys
import zlib


# ── 从 nc_guard_layout.h 抽取契约常量（2026-10-20）──────────────────
# 为什么让 Python 从 C 头文件抽，而不是反过来（C 从 Python 抽）：
#   · C 头文件是编译期强制生效的（_Static_assert 已在里头把关偏移重叠），
#     让 Python 当消费者，它不可能漂移；
#   · 反过来 Python 要写一个 C 头解析器，那本身就是新的 bug 源。
#
# 失败即抛错，绝不静默兜底："以为同步了其实没同步"比编译失败危险得多。
def _load_layout_contract():
    """从 nc_guard_layout.h 抽取段名/尺寸/偏移/种子，返回 dict。

    头文件定位：2026-10-30 设施独立后，本脚本与头文件同在 scripts/so-guard/。
    仍保留旧路径（../sigcheck/src/）作为兼容候选——若有人只回退了一半的
    改动，能继续工作而不是直接失败；但正常布局下第一顺位（同目录）就命中。
    找不到头文件 → 抛 FileNotFoundError（调用方应视为构建配置错误）。
    """
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, 'nc_guard_layout.h'),
                 os.path.join(here, '..', 'sigcheck', 'src', 'nc_guard_layout.h')):
        cand = os.path.normpath(cand)
        if os.path.isfile(cand):
            path = cand
            break
    else:
        raise FileNotFoundError(
            '找不到 nc_guard_layout.h（契约真相源）。'
            '它应与本脚本同在 scripts/so-guard/ 下；缺失意味着锁箱契约无从对拍，'
            '拒绝继续——否则会用过期常量锁出一个运行期 SIGILL 的包。')

    with open(path, encoding='utf-8') as f:
        text = f.read()

    out = {}
    # ① 段名：#define NC_SEC_XXX  ".yyy"
    # ⚠️ 字符类必须含数字：NC_SEC_VMP2 带 '2'，用 [A-Z_]+ 匹配不到 →
    #    _LAYOUT 缺键 → lock() 里按名取钥匙抛 KeyError → 一级锁箱整体失败。
    #    2026-11-12 实测踩过（.nct 那轮）。
    for m in re.finditer(r'#define\s+(NC_SEC_[A-Z0-9_]+)\s+"([^"]+)"', text):
        out[m.group(1)] = m.group(2)
    # ② 尺寸/偏移：#define NC_XXX_YYY  104  或  0x1000
    # 2026-10-28 T4：加入 BOOT_（NC_BOOT_BACK / NC_BOOT_FWD）与 INFO（字符串另处理）
    # ⚠️ 必须支持十六进制：NC_BOOT_BACK/FWD 用 0x 前缀写，早期只认十进制
    #    会把它们抽成 0（实测踩过：导致 boot_key 区间长度 0，锁箱静默出错）。
    for m in re.finditer(
            r'#define\s+(NC_(?:SLOT|STUB|OFF|BOOT)_[A-Z0-9_]+)\s+(0x[0-9a-fA-F]+|\d+)',
            text):
        out[m.group(1)] = int(m.group(2), 0)
    # ③ T4：boot_key 的 info 字符串（带引号）
    for m in re.finditer(r'#define\s+(NC_BOOT_INFO)\s+"([^"]+)"', text):
        out[m.group(1)] = m.group(2)
    # ④ T4：boot salt 初始化列表（16 字节十六进制）
    for m in re.finditer(
            r'#define\s+(NC_BOOT_SALT_INIT)\s*\\?\s*\{([^}]*)\}', text):
        vals = [int(x, 16) for x in re.findall(r'0x([0-9a-fA-F]+)', m.group(2))]
        out[m.group(1)] = bytes(vals)
    # ③ magic 种子初始化列表：#define NC_SEED_XXX_INIT { 0x.., ... }
    # ⚠️ 必须支持【续行】形态（`#define X \` + 换行 + `{ ... }`）——
    #    layout.h 为可读性把初始化列表放在下一行，\s* 匹配不到换行。
    #    2026-10-20 实测踩过：漏掉续行支持 → 两个 seed 抽不到 →
    #    "缺少必需常量" 直接构建失败。
    for m in re.finditer(
            r'#define\s+(NC_SEED_[A-Z_]+_INIT)\s*\\?\s*\{([^}]*)\}', text):
        vals = [int(x, 16) for x in re.findall(r'0x([0-9a-fA-F]+)', m.group(2))]
        out[m.group(1)] = bytes(vals)
    # XOR 碎片表（2026-10-21）：同跨行形态。与非 INIT 数组的区别：
    # 这是"逻辑字节 i 取哪个碎片"的映射表，值为十进制小整数。
    for m in re.finditer(
            r'#define\s+(NC_XOR_FRAG_INIT)\s*\\?\s*\{([^}]*)\}', text):
        vals = [int(x) for x in re.findall(r'\d+', m.group(2))]
        out[m.group(1)] = bytes(vals)
    # 碎片区契约（layout.h → 锁箱器，T20 对拍用）
    for m in re.finditer(r'#define\s+(NC_OFF_FRAGS)\s+(\d+)', text):
        out[m.group(1)] = int(m.group(2))

    required = ['NC_SEC_CODE', 'NC_SEC_CONST', 'NC_SEC_HEAD', 'NC_SEC_HEADRO',
                'NC_SEC_SLOT', 'NC_SEC_STUBSLOT',
                'NC_SLOT_SIZE', 'NC_STUB_SIZE',
                'NC_SEED_SLOT_INIT', 'NC_SEED_STUB_INIT',
                'NC_XOR_FRAG_INIT', 'NC_OFF_FRAGS',
                'NC_BOOT_SPAN', 'NC_BOOT_SPAN_MIN', 'NC_BOOT_SALT_INIT',
                'NC_BOOT_INFO', 'NC_OFF_FRAGS_ENC']
    missing = [k for k in required if k not in out]
    if missing:
        raise ValueError(
            'nc_guard_layout.h 缺少必需常量: %s —— 头文件被改坏了？' % ', '.join(missing))
    return out


_LAYOUT = _load_layout_contract()

# ── 常量契约（与运行期 C 代码共享，改这里必须同步改 C 侧）────────────
# ⚠️⚠️ 2026-10-20 起，本区常量不再手写，而是从 nc_guard_layout.h 抽取。
#   那是契约的【唯一真相源】。此前这些值在 C 侧与 Python 侧各写一份，
#   改一处漏一处的症状是运行期 SIGILL（不是编译错误），极难定位；
#   仓库历史报错三/九/十一/十二全是同类根因。
#   抽取失败（头文件缺失/正则不匹配）直接抛错，绝不静默用旧值兜底 ——
#   "以为同步了其实没同步"比编译失败危险得多。
#
# 抽取规则：只认 `#define NAME value` 形态，值必须是 8/16 位十六进制串
# （段名是带引号的字符串，另行处理）。见 _load_layout_contract()。

SECTION_NAME = _LAYOUT['NC_SEC_CODE']   # 加密代码段（Xop 用 .bitcode，改名避开指纹）
SLOT_NAME = _LAYOUT['NC_SEC_SLOT']      # 密钥槽段（Xop 用 .protwrap）
# ⚠️ 2026-10-19：magic 不再以明文字面量落进 .nck/.ncks。
# 原实现直接写 b'NCKEYLOCK' / b'NCSTUBLK'，攻击者 `strings -n 6` 就能扫出
# 两条明确路标（实测旧产物可见 3 条）。现在改成 seed ^ XOR_KEY 的形式，
# 二进制里不再有该字面量；运行期 C 侧由 ncg_magic_ok() 用同样的
# seed ^ 碎片密钥 生成后比对，语义（匹配=已锁，不匹配=未锁放行）不变。
# 改这四个常量必须同步 nc_guard_boot.c 的 NCG_MAGIC_SEED_SLOT/STUB。
SLOT_MAGIC_SEED = _LAYOUT['NC_SEED_SLOT_INIT']   # ← 来自 nc_guard_layout.h
STUB_MAGIC_SEED = _LAYOUT['NC_SEED_STUB_INIT']   # ← 来自 nc_guard_layout.h
XOR_KEY = bytes([0x7E, 0x31, 0xA5, 0x0D, 0xC8, 0x92, 0x4B, 0xF6])
# 注意：'NCKEYLOCK' 是 9 字节，seed 只覆盖前 8 字节（第 9 字节 'K' 由
# 运行期 C 侧的 8 字节比较不涉及——C 侧比的是前 8 字节 'NCKEYLOC'）。
assert bytes(a ^ b for a, b in zip(SLOT_MAGIC_SEED, XOR_KEY)) == b'NCKEYLOC'
assert bytes(a ^ b for a, b in zip(STUB_MAGIC_SEED, XOR_KEY)) == b'NCSTUBLK'
# ⚠️ 落盘的是【seed 本身】，不是 seed^key。这是本机制的关键：
#   - 落盘 seed（看起来是随机字节）→ strings 搜不到任何路标
#   - 运行期 C 侧算 seed ^ 碎片密钥 = "NCKEYLOC" 再与... 不需要再比了：
#     C 侧直接把落盘的 8 字节当作 seed，与自己算出的期望值比对即可。
#   语义："slot 前 8 字节 == SLOT_MAGIC_SEED" ⇒ 已锁。
# 旧的 SLOT_MAGIC/SLOT_MAGIC_SEED 双轨容易搞混，这里只保留 seed 一个真相源。
SLOT_MAGIC = SLOT_MAGIC_SEED + b'\x00' * 8   # 16 字节，后 8 保留
# ⚠️ 2026-10-18 与 LSGS 彻底分离（原注释写"与 LSGS 同源"，是错的）：
# 同一把 8 字节密钥此前同时护三处 —— .ncx 的 wrapped_k_so /
# wrapped_k_mac、.ncxh 的 wrapped_k_stub、以及 make-sig-log.py 的
# 中文日志 XOR 密文。而 LSGS 侧自己的注释就写着"不抗人工逆向"（它只是
# 打散 strings 扫描的纯 XOR）。共用的后果：破掉最脆的那套，强的一起破。
# 现在 nc_guard 侧用本常量，LSGS 侧保持原值不动，两把钥匙互不相关。

# ── 自解谜二级锁箱（2026-10-18，nc_guard_boot.c）──────────────────
# 把"开锁器本身"也锁进密文段，让静态攻击者不能直接读解锁逻辑。
#   HEAD_NAME    装 unlock 本体的段（ncg_head_unlock 及其私有函数）
#   STUB_SLOT    stub 的密钥槽（.text 里的明文 stub 靠它解出 head）
#   STUB_MAGIC   slot 前 8 字节，stub 判"是否已锁"用
# slot 布局（40 字节，与 nc_guard_boot.c 的 stub 逐字节一致）：
#   [ 0: 8) magic NCSTUBLK
#   [ 8:24) wrapped k_stub = k_stub ^ XOR_KEY
#   [24:28) stub_sh_addr —— .ncks 段自身的链接期虚拟地址
#   [28:32) head_sh_addr —— .ncxh 段的链接期虚拟地址
#   [32:36) head_size    —— .ncxh 段字节数
#   [36:40) 预留（对齐与将来扩展）
#
# ⚠️ 2026-10-18 不存 entry_delta（入口符号 − 段起始偏移）：那需要从 .symtab
# 读符号地址，而 NDK ndk-build 默认 strip 符号表（CI 39074690534 实测因此
# fail-fast）。也不能靠"让 CI 不 strip"绕过——那会把 frida_port_probe /
# xposed_maps_probe 等探针名暴露进符号表，等于泄露检测意图。
# 改用 section header table：strip 只删 .symtab/.strtab，段表始终完整。
HEAD_NAME = _LAYOUT['NC_SEC_HEAD']      # 装 unlock 本体的段
HEAD_RO_NAME = _LAYOUT['NC_SEC_HEADRO']  # 存 master（2026-10-19 随机化）
# 字符串段（2026-11-28）：只放显式标记的敏感字符串，构建期整段加密。
# 与 .ncx/.ncxr 完全独立 —— 不改任何现有段名/偏移，历史产物不受影响。
NC_SEC_STR = _LAYOUT['NC_SEC_STR']
STUB_SLOT = _LAYOUT['NC_SEC_STUBSLOT']  # stub 的密钥槽
STUB_MAGIC = STUB_MAGIC_SEED


class ElfError(Exception):
    pass


# ── ELF 解析（ELF64 小端 + ELF32 小端；arm64-v8a 是 64，armeabi-v7a 是 32）──
# 32 位布局差异：e_shoff 在 0x20、 Elf_Shdr 字段宽度从 8→4 字节
class Elf:
    def __init__(self, data: bytes):
        if data[:4] != b'\x7fELF':
            raise ElfError('not an ELF file')
        if data[5] != 1:
            raise ElfError('only little-endian supported (got EI_DATA=%d)' % data[5])
        self.is64 = (data[4] == 2)
        if data[4] not in (1, 2):
            raise ElfError('unknown EI_CLASS=%d' % data[4])
        self.data = bytearray(data)

        if self.is64:
            (self.e_shoff,) = struct.unpack_from('<Q', self.data, 0x28)
            self.e_shentsize = struct.unpack_from('<H', self.data, 0x3A)[0]
            self.e_shnum = struct.unpack_from('<H', self.data, 0x3C)[0]
            self.e_shstrndx = struct.unpack_from('<H', self.data, 0x3E)[0]
            SH_FMT, SH_SIZE = '<IIQQQQIIQQ', 64
        else:
            (self.e_shoff,) = struct.unpack_from('<I', self.data, 0x20)
            self.e_shentsize = struct.unpack_from('<H', self.data, 0x2E)[0]
            self.e_shnum = struct.unpack_from('<H', self.data, 0x30)[0]
            self.e_shstrndx = struct.unpack_from('<H', self.data, 0x32)[0]
            SH_FMT, SH_SIZE = '<IIIIIIIIII', 40

        if self.e_shoff == 0 or self.e_shnum == 0:
            raise ElfError('ELF has no section header table')
        if self.e_shstrndx >= self.e_shnum:
            raise ElfError('e_shstrndx out of range')
        if self.e_shentsize != SH_SIZE:
            raise ElfError('unexpected e_shentsize=%d (want %d)' % (self.e_shentsize, SH_SIZE))

        self.sections = []
        for i in range(self.e_shnum):
            off = self.e_shoff + i * self.e_shentsize
            f = struct.unpack_from(SH_FMT, self.data, off)
            if self.is64:
                sh_name, sh_type, sh_flags, sh_addr, sh_offset, sh_size = f[:6]
            else:
                sh_name, sh_type, sh_flags, sh_addr, sh_offset, sh_size = f[:6]
            self.sections.append(dict(name_off=sh_name, type=sh_type, flags=sh_flags,
                                      addr=sh_addr, offset=sh_offset, size=sh_size))
        stroff = self.sections[self.e_shstrndx]['offset']
        self._strtab = bytes(self.data[stroff:])
        for s in self.sections:
            end = self._strtab.find(b'\x00', s['name_off'])
            s['name'] = self._strtab[s['name_off']:end].decode('utf-8', 'replace')

    def find(self, name: str):
        for s in self.sections:
            if s['name'] == name:
                return s
        return None

    def require_shf_alloc(self, sec) -> None:
        SHF_ALLOC = 0x2
        if not (sec['flags'] & SHF_ALLOC):
            raise ElfError('section %s is not SHF_ALLOC; runtime cannot map it' % sec['name'])


# ── RC4（与 Xop crypto/rc4.c 同算法；size-preserving 流密码）────────
def rc4(key: bytes, data: bytes) -> bytes:
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) & 0xFF
        S[i], S[j] = S[j], S[i]
    out = bytearray()
    i = j = 0
    for b in data:
        i = (i + 1) & 0xFF
        j = (j + S[i]) & 0xFF
        S[i], S[j] = S[j], S[i]
        out.append(b ^ S[(S[i] + S[j]) & 0xFF])
    return bytes(out)


# ── HKDF-SHA256（与 Xop crypto/key_ladder.cpp 同 label 规则）───────
def hkdf_sha256(ikm: bytes, salt: bytes, info: bytes, length: int) -> bytes:
    prk = hmac_sha256(salt, ikm)
    okm = b''
    t = b''
    counter = 1
    while len(okm) < length:
        t = hmac_sha256(prk, t + info + bytes([counter]))
        okm += t
        counter += 1
    return okm[:length]


def hmac_sha256(key: bytes, msg: bytes) -> bytes:
    block = 64
    if len(key) > block:
        key = hashlib.sha256(key).digest()
    key = key + b'\x00' * (block - len(key))
    o = bytes(b ^ 0x5C for b in key)
    i = bytes(b ^ 0x36 for b in key)
    return hashlib.sha256(o + hashlib.sha256(i + msg).digest()).digest()


# ── SHA-256-CTR 密钥流（2026-10-30，取代 16 字节周期 XOR）───────────
# 为什么必须换掉周期 XOR（这是仓库里唯一的密码学硬伤）：
#   原实现 `cipher[i] = plain[i] ^ k[i % 16]`（head 段与 master 段）。
#   16 字节周期的密钥流对【已知明文】完全透明：ARM64 机器码的函数序言
#   高度可猜（stp x29,x30,[sp,#-16]! 等），攻击者对密文做间隔 16 的
#   自相关即可看出周期性，进而恢复 k_stub_eff 全 16 字节 → 整段解开。
#   周期 XOR 只能提供"混淆"，提供不了"抗已知明文"。
#
# 换成 SHA-256-CTR 的理由（不是"更时髦"，是三条具体约束都满足）：
#   ① stub 里【不能】出现 256 字节 S 盒初始化循环——那是"这是 RC4"的
#      活招牌，且会显著撑大 .text 里的 stub（攻击者唯一能直读的部分）。
#      SHA-256 已在 .text 明文段可用（nc_guard_key.c 的 ksha256，且 stub
#      已经在调 khmac_sha256 验 head MAC）→ 零新增依赖、零新增 PLT 项。
#   ② SHA-256 无统计偏差、无已知明文攻击，比 RC4 强一个档次。
#   ③ 代价可接受：.ncxh 实测 1.6KB → 50 次 SHA-256 ≈ 几十微秒，
#      只在 constructor 跑一次（相对 .ncx 的 RC4 解密 102.5μs 同量级）。
#
# ⚠️ 域分隔（dom）：head 与 master 共用同一把 k_stub_eff，若都从
#   counter=0 起算则构成 two-time pad（密文 XOR 可还原明文 XOR）。
#   故给两段各一个 dom 字节：0x01=.ncxh，0x02=.ncxhr。
#   这同时修掉了原实现里 head[0:32] 与 master[0:32] 密钥流相同的问题。
#
# 两侧必须逐字节一致：C 侧见 nc_guard_boot.c 的 ncg_ctr_xor()。
# 跨语言对拍由 test-so-lock.sh 的 T32 负责。
CTR_DOM_HEAD = 0x01      # .ncxh（unlock 本体）
CTR_DOM_HEADRO = 0x02    # .ncxhr（master 数据段）


def ctr_keystream(key: bytes, dom: int, n: int) -> bytes:
    """SHA-256-CTR 密钥流：keystream[i] = SHA256(key || dom || LE32(counter)).

    counter 从 0 起，每块产出 32 字节。截断到 n 字节。
    与 C 侧 ncg_ctr_xor() 逐字节一致（对拍见 test-so-lock.sh T32）。
    """
    out = bytearray()
    ctr = 0
    while len(out) < n:
        out += hashlib.sha256(key + bytes([dom]) + struct.pack('<I', ctr)).digest()
        ctr += 1
    return bytes(out[:n])


def ctr_xor(key: bytes, dom: int, data: bytes) -> bytes:
    """SHA-256-CTR 加解密（对称：同一函数既加密也解密）。"""
    ks = ctr_keystream(key, dom, len(data))
    return bytes(b ^ k for b, k in zip(data, ks))


def derive_app_keys(master: bytes, cert_sha256: bytes, package: str) -> dict:
    """HKDF 派生六把域密钥（label 规则与 Xop 一致，便于日后对拍）。

    2026-12 追加 mac 域：它只参与"密文段是否被改过"的 HMAC 计算，
    绝不能与 so 域复用同一把钥匙——复用等于把 MAC 降级成"知道 RC4 密钥
    就能伪造"，完整性校验形同虚设。域分隔靠 label 前缀，convention 同 Xop。

    2026-10-28 追加 so_r 域（逆向报告 §6.2）：此前 .ncx 与 .ncxr 都用 k_so
    且都从 RC4 keystream 偏移 0 起 → 典型 two-time-pad 误用。实测
    C_ncx[i] ^ C_ncxr[i] == P_ncx[i] ^ P_ncxr[i] 成立，即已知 .ncxr 明文
    （96 字节签名表，结构高度可猜）就能反推 .ncx 前 96 字节明文。
    现在 .ncxr 用独立的 so_r 域，两段的 keystream 互相不可推导。
    """
    out = {}
    for label, dom in (('nc-dex-v1', 'dex'), ('nc-insn-v1', 'insn'),
                       ('nc-so-v1', 'so'), ('nc-warm-v1', 'warm'),
                       ('nc-so-mac-v1', 'mac'),
                       ('nc-so-r-v1', 'so_r')):
        info = (label + package).encode('utf-8')
        out[dom] = hkdf_sha256(master, cert_sha256, info, 16)
    return out


# ── T4：槽段加密（2026-10-28）─────────────────────────────────────
# 与 C 侧的 ncg_boot_key() 必须逐字节一致。任一侧改动都要同步另一侧，
# 否则产物在真机上解不开槽 → 全链失败（且症状是 SIGILL，难定位）。
#
# anchor 的取值：C 侧用 &ncg_stub_recover（一个 .text 内函数的运行期地址）。
# Python 侧无法直接知道该函数的链接期地址（ndk-build 默认 strip 符号表），
# 所以【不从符号取】，而是用 elf 段表里 .ncks 段自身地址反推：
#   .ncks 段在 .text 之后，锚点相对 .ncks 的偏移在构建期可测定并写入契约。
#
# ⚠️⚠️ 这里改用更稳妥的做法：锚点 = .ncks 段的链接期地址（slot_sh_addr，
#    该值本来就在 .ncks[24:28] 里，是明文可算的）。
#    C 侧的 ncg_boot_key() 需要相应改为用 ncg_stub_slot 的地址作锚点，
#    而不是 &ncg_stub_recover —— 因为 ncg_stub_slot 的链接期地址正是
#    slot_sh_addr，两侧天然对齐，且都在 .text 之外的独立段里，
#    不会把自己算进 CRC 区间造成自指。

def _boot_crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF


def _derive_boot_key(elf: 'Elf') -> bytes:
    """与 C 侧 ncg_boot_key() 逐字节同规则。

    ikm  = CRC32(区间)(4B 大端) || 区间首 16B || 区间末 16B
    salt = NC_BOOT_SALT_INIT
    info = NC_BOOT_INFO ("nc-boot-v1")

    ⚠️ 区间定义必须与 C 侧完全一致：C 侧用
         lo = base + text.sh_addr            （.text 段起点）
         span = NC_BOOT_BACK + NC_BOOT_FWD
       即【.text 起始的连续 span 字节】，不是"以某个锚点为中心"。
       早期设计曾想用 stub 函数地址作锚点，但那会导致 Python 侧
       无法复现（ndk-build 默认 strip 符号表）；改用段表起点后两侧
       天然同源。
    """
    span_max = _LAYOUT['NC_BOOT_SPAN']
    span_min = _LAYOUT['NC_BOOT_SPAN_MIN']

    text = elf.find('.text')
    if text is None:
        raise ElfError('.text 段不存在，无法派生 boot_key')
    # 区间自适应：min(上限, .text 实际长度)，与 C 侧 ncg_boot_key 同规则。
    # ⚠️ 2026-10-28 CI 踩坑：原先把区间写成常量相加 16384，而
    #    armeabi-v7a 的 .text 只有 12000 字节 → 锁箱直接失败。
    span = min(span_max, text['size'])
    if span < span_min:
        raise ElfError(
            'boot_key CRC 区间仅 %d 字节（下限 %d）—— .text 过小，'
            'boot_key 强度不足' % (span, span_min))

    region = bytes(elf.data[text['offset']: text['offset'] + span])
    crc = _boot_crc32(region)
    ikm = struct.pack('>I', crc) + region[:16] + region[-16:]
    salt = _LAYOUT['NC_BOOT_SALT_INIT']
    info = _LAYOUT['NC_BOOT_INFO'].encode('utf-8')
    return hkdf_sha256(ikm, salt, info, 16)


def _encrypt_slots(elf: 'Elf') -> None:
    """加密 .ncks[8:112) 与 .nck[0:96)。

    为什么 .ncks[0:8) 豁免：magic 判"未锁"发生在解密之前，加密就判不了。
    该 8 字节只是 seed，无密钥价值。
    为什么 .nck 整段加密：它的 magic 判定发生在一级锁箱之后，
    此时 boot_key 已算出，可以先解密再判定。
    """
    ncks = elf.find(STUB_SLOT)   # .ncks
    nck = elf.find(SLOT_NAME)    # .nck
    if ncks is None or nck is None:
        raise ElfError('.ncks / .nck 缺失，无法执行 T4 槽加密')

    boot_key = _derive_boot_key(elf)
    # ⚠️ 绝不打印 boot_key 本身（2026-11-02 修）。
    # boot_key 是 .ncks/.nck 两个槽段的 RC4 密钥，而槽里装着
    # wrapped k_stub + XOR 碎片 + k_mac_head —— 拿到它就能不逆向
    # 直接剥掉整个解锁链：
    #   boot_key → 解 .ncks → XOR 碎片拼回 XOR_KEY → k_stub
    #   → SHA-256-CTR 解 .ncxh（unlock 本体）→ 解 .ncx/.ncxr
    # 而构建日志会进 CI artifact（protect-modules.yml 的
    # upload-artifact "构建日志-build.log"）与 R2，属于可下载物。
    # 仓库即便私有，日志也可能被外传/截图；泄露一把主密钥不划算。
    # 只留"已派生"的事实，长度都不打（长度也是常量信息）。
    print('   T4 boot_key: 已派生（.text CRC 自绑定，不落日志）')

    enc_off = _LAYOUT['NC_OFF_FRAGS_ENC']          # 8
    # .ncks：[enc_off : size) 加密
    p = bytes(elf.data[ncks['offset'] + enc_off:
                       ncks['offset'] + ncks['size']])
    elf.data[ncks['offset'] + enc_off:
             ncks['offset'] + ncks['size']] = rc4(boot_key, p)
    # .nck：整段加密
    q = bytes(elf.data[nck['offset']: nck['offset'] + nck['size']])
    elf.data[nck['offset']: nck['offset'] + nck['size']] = rc4(boot_key, q)
    print('   T4 已加密: .ncks[%d:%d) + .nck[0:%d)'
          % (enc_off, ncks['size'], nck['size']))


# ── 锁箱主流程 ────────────────────────────────────────────────────
def apk_first_signer_cert_sha256(apk_path: str) -> bytes:
    """从 APK 提取第一签名者证书 DER 的 SHA-256（32 字节）。

    与 C 侧 nc_guard_key.c 的 ncg_apk_first_cert_der() 同规则（照抄 XopProtector
    crypto/apk_sign.cpp）：只读 EOCD + Central Directory + APK Signing Block
    （几十 KB 定点读，不读整个 APK）。v3(0xf05368c0) 优先，回退 v2(0x7109871a)。
    """
    import struct as _s  # noqa: F811  与模块级 struct 同模块，此处为可读性起别名
    with open(apk_path, 'rb') as f:
        f.seek(0, 2)
        fsize = f.tell()
        if fsize < 64:
            raise ElfError('APK 过小: %d' % fsize)
        # 1) EOCD：尾部前 64KB 反向找 PK\x05\x06
        search = max(0, fsize - 65557)
        pos = fsize - 22
        while pos >= search:
            f.seek(pos)
            eocd = f.read(22)
            if eocd[:4] == b'PK\x05\x06':
                break
            pos -= 1
        else:
            raise ElfError('未找到 EOCD')
        cd_off = _s.unpack('<I', eocd[16:20])[0]
        if cd_off < 32 or cd_off >= fsize:
            raise ElfError('CD 偏移非法: %d' % cd_off)
        # 2) Signing Block footer
        f.seek(cd_off - 24)
        footer = f.read(24)
        if len(footer) < 24:
            raise ElfError('footer 读失败')
        # 照抄 XopProtector crypto/apk_sign.cpp:21-22/198：
        #   kMagicLo = 0x20676953204b5041 ("APK Sig ")
        #   kMagicHi = 0x3234206b636f6c42 ("Block 42")
        # ⚠️ 必须校验两个 8 字节——我第一版只查了 "APK Sig Block "（14 字节，
        # 既漏了结尾 "42" 又比切片长），magic 永不匹配 → 真 APK 也提取失败。
        if footer[8:16] != b'APK Sig ' or footer[16:24] != b'Block 42':
            raise ElfError('非 APK Signing Block magic')
        block_size = _s.unpack('<Q', footer[:8])[0]
        if block_size < 24 or block_size + 8 > cd_off:
            raise ElfError('block_size 非法: %d' % block_size)
        # 3) 只读 block 进内存
        total = block_size + 8
        f.seek(cd_off - total)
        blk = f.read(total)
        if _s.unpack('<Q', blk[:8])[0] != block_size:
            raise ElfError('block size 不匹配')
        # 4) 遍历 id-value 对，找 v3/v2
        v3 = v2 = None
        i = 8
        while i + 12 <= len(blk):
            (pl,) = _s.unpack('<Q', blk[i:i + 8])
            i += 8
            if pl < 4 or i + pl > len(blk):
                break
            (bid,) = _s.unpack('<I', blk[i:i + 4])
            val = blk[i + 4:i + pl]
            if bid == 0xf05368c0:
                v3 = val
            elif bid == 0x7109871a:
                v2 = val
            i += pl
    der = _first_cert_der(v3) or _first_cert_der(v2)
    if der is None:
        raise ElfError('v3/v2 中均未找到证书 DER')
    return hashlib.sha256(der).digest()


def manifest_package(apk_path: str) -> str:
    """从 APK 的二进制 AndroidManifest.xml 取 package 属性（stdlib 实现，零依赖）。

    为什么不用 androguard：本脚本是"锁箱"单一职责，为拿一个包名把整个
    dcc 解压链（tools/dcc + sys.path hack）拖进来不划算。
    AXML 规范：XML 头(8) + string pool + element chunk；package 属性挂在
    <manifest> START_ELEMENT 上，值通常是 type=0x03(STRING) 的 pool 索引。
    """
    import struct as _s
    RES_STRING_POOL_TYPE = 0x0001
    RES_XML_START_ELEMENT_TYPE = 0x0102
    import zipfile
    with zipfile.ZipFile(apk_path) as z:
        raw = z.read('AndroidManifest.xml')
    if raw[:2] != b'\x03\x00':
        raise ElfError('非二进制 AXML（magic=%r）' % raw[:4])

    # 1) 收集 chunk
    off = 8
    chunks = {}
    while off + 8 <= len(raw):
        ctype, hsize, csize = _s.unpack_from('<HHI', raw, off)
        if csize < 8 or off + csize > len(raw):
            break
        chunks.setdefault(ctype, []).append((off, csize))
        off += csize
    pools = chunks.get(RES_STRING_POOL_TYPE, [])
    if not pools:
        raise ElfError('AXML 无 string pool')
    poff, psize = pools[0]

    # ResStringPool_header（相对 chunk 开头 poff）：
    #   0:type(2) 2:hsize(2) 4:size(4) 8:stringCount(4) 12:styleCount(4)
    #   16:flags(4) 20:stringsStart(4) 24:stylesStart(4)
    # ⚠️ stringsStart 是【相对 chunk 开头】的偏移，不是绝对地址
    string_count = _s.unpack_from('<I', raw, poff + 8)[0]
    flags = _s.unpack_from('<I', raw, poff + 16)[0]
    strings_start = _s.unpack_from('<I', raw, poff + 20)[0]
    is_utf8 = bool(flags & 0x100)

    pool = []
    sp = poff + strings_start
    for _i in range(string_count):
        if is_utf8:
            # ⚠️ 2026-10-28 修复：AOSP 规范里 UTF-8 形态是【两段长度】
            #   [UTF-16 长度（1~2 字节 varint）]
            #   [UTF-8 字节长度（1~2 字节 varint）]
            #   [UTF-8 数据][NUL]
            # 原实现只读了一段，把 UTF-16 长度当成字节长度用 →
            # 每读一条就错位 1 字节，整个池全错 → 最终"未找到 <manifest>"。
            # 实测触发样本：Toxsk_1.0.apk（flags=0x100 的 UTF-8 池）。
            # 症状：字符串被解成 '\x0bversionCod'（正确是 'versionCode'）。
            # 对照：AOSP frameworks/base/libs/androidfw/ResourceTypes.cpp
            #       ResStringPool::stringAt() 的 isUTF8 分支。
            n16 = raw[sp]; sp += 1
            if n16 & 0x80:
                n16 = ((n16 & 0x7F) << 8) | raw[sp]; sp += 1
            n8 = raw[sp]; sp += 1
            if n8 & 0x80:
                n8 = ((n8 & 0x7F) << 8) | raw[sp]; sp += 1
            pool.append(raw[sp:sp + n8].decode('utf-8', 'replace'))
            sp += n8 + 1
        else:
            slen = raw[sp] | (raw[sp + 1] << 8); sp += 2
            if slen & 0x8000:
                slen = ((slen & 0x7FFF) << 16) | (raw[sp] | (raw[sp + 1] << 8)); sp += 2
            pool.append(raw[sp:sp + slen * 2].decode('utf-16-le', 'replace'))
            sp += slen * 2 + 2

    # 2) 找 <manifest> START_ELEMENT 的 package 属性
    # RES_XML_START_ELEMENT: ns(4) name(4) attrStart(2) attrSize(2)
    #                         attrCount(2) idIdx(2) classIdx(2) styleIdx(2)
    for eoff, _esize in chunks.get(RES_XML_START_ELEMENT_TYPE, []):
        # ResXML_tree_node: header(8) lineNumber(4) comment(4) → 16
        # ResXML_tree_attrExt: ns(4) name(4) attrStart(2) attrSize(2)
        #                       attrCount(2) idIdx(2) classIdx(2) styleIdx(2)
        # ⚠️ name 在 eoff+20（不是 +16——那是 comment 尾部，曾读成 -1 全不匹配）
        name_idx = _s.unpack_from('<i', raw, eoff + 20)[0]
        if not (0 <= name_idx < len(pool)) or pool[name_idx] != 'manifest':
            continue
        attr_start = _s.unpack_from('<H', raw, eoff + 24)[0]
        attr_size = _s.unpack_from('<H', raw, eoff + 26)[0]
        attr_count = _s.unpack_from('<H', raw, eoff + 28)[0]
        for i in range(attr_count):
            # ⚠️ attrStart 相对 attrExt 开头，需先跳过 16 字节 node header
            #    （漏了这 16 字节 → 属性名全错位成 1310740/-1，曾实测）
            ao = eoff + 16 + attr_start + i * attr_size
            aname = _s.unpack_from('<i', raw, ao + 4)[0]
            atype = raw[ao + 15]
            adata = _s.unpack_from('<I', raw, ao + 16)[0]
            if 0 <= aname < len(pool) and pool[aname] == 'package':
                if atype == 0x03 and 0 <= adata < len(pool):
                    return pool[adata]
                return ''
    raise ElfError('未找到 <manifest package=...>')


def _first_cert_der(scheme: bytes):
    """v2/v3 scheme 块里第一个 signer 的第一张证书 DER。

    ⚠️ 2026-10-19 重写。旧实现（"从 signedData 尾部反推证书数"）是错的：
    APK Sig Scheme v2/v3 的 certificates 段是【长度前缀序列】，没有"证书数"。
    旧代码在真 APK 上碰巧从一个错误偏移取到 294 字节、头 `30820122` 的块并
    当作证书返回——那是 **public key**，不是证书。真证书是 712 字节、头
    `308202c4`。后果：k_so 实际绑定的是"公钥"而非"证书"，换了签名密钥但
    证书链相同时绑定形同未变。

    规范布局（source.android.com/docs/security/features/apksigning/v2）：
      signers     = signers_len(4) + [signer_len(4) + signer]...
      signer      = signed_data_len(4) + signed_data
                    + signatures_len(4) + signatures
                    + public_key_len(4) + public_key
      signed_data = digests_len(4) + digests
                    + certificates_len(4) + [cert_len(4) + cert_der]...
                    + additional_attrs_len(4) + ...
    """
    if not scheme or len(scheme) < 12:
        return None

    def _from_signer(signer, n):
        if n < 12:
            return None
        sd_len = int.from_bytes(signer[0:4], 'little')
        if sd_len < 8 or sd_len + 4 > n:
            return None
        sd = signer[4:4 + sd_len]
        q = 0
        dg = int.from_bytes(sd[q:q + 4], 'little')  # digests_len
        if dg < 4 or dg + 8 > sd_len:
            return None
        q += 4 + dg
        certs_len = int.from_bytes(sd[q:q + 4], 'little')
        q += 4
        if certs_len < 4 or q + certs_len > sd_len:
            return None
        cl = int.from_bytes(sd[q:q + 4], 'little')
        q += 4
        if cl == 0 or cl > certs_len - 4 or q + cl > sd_len:
            return None
        return sd[q:q + cl]

    # 规范路径：跳 signers_len，再跳 signer_len
    off = 4
    if off + 4 <= len(scheme):
        sl = int.from_bytes(scheme[off:off + 4], 'little')
        if sl >= 12 and off + 4 + sl <= len(scheme):
            r = _from_signer(scheme[off + 4:off + 4 + sl], sl)
            if r:
                return r
    # 回退路径：signers_len 被写成"个数"（=1）
    cnt = int.from_bytes(scheme[0:4], 'little')
    if 1 <= cnt <= 8 and off + 4 <= len(scheme):
        sl = int.from_bytes(scheme[off:off + 4], 'little')
        if sl >= 12 and off + 4 + sl <= len(scheme):
            return _from_signer(scheme[off + 4:off + 4 + sl], sl)
    return None


def shannon_entropy(data: bytes) -> float:
    """香农熵（bits/byte）。用于验证"加密真的生效了"。

    RC4 输出是伪随机流，熵必然接近 8.0（实测 .ncxh 约 7.4、
    .ncx 视内容在 7.9 以上）。普通代码段只有 6.6~6.9。
    所以熵掉了只能说明一件事：那一段不是密文，是明文。
    """
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    ent = 0.0
    for c in counts:
        if c:
            p = c / n
            ent -= p * math.log2(p)
    return ent


# 密文段熵的下限。RC4 伪随机流的熵通常在 7.9 以上，普通代码段只有 6.6~6.9，
# 两者之间有明显空隙，7.0 是安全阈值。
#
# ⚠️ 但熵值统计需要足够样本才有效：N 字节的段最多只有 N 种不同取值，
# 熵的理论上限是 min(8, log2(N))。24 字节的上限仅 log2(24)≈4.59 ——
# 2026-10-18 实测踩过：拿 24 字节的 .ncx 跑安检，熵 4.502 被判失败，
# 但那其实是接近满值的随机数据（假阳性）。
# 因此段长低于 ENTROPY_MIN_BYTES 时直接跳过安检，不做判断。
ENTROPY_MIN = 7.0
ENTROPY_MIN_BYTES = 256


def ctr_xor_off(key: bytes, dom: int, seg_off: int, data: bytes) -> bytes:
    """带【段内偏移】的 SHA-256-CTR —— 与 C 侧 ncg_ctr_xor_off 逐字节一致。

    用途：.ncxs（字符串段）是"整段一条流，运行期从任意偏移取一条串"。
    加密时整段从 0 起算；解密某条串时 counter 从 seg_off//32 起、
    并在首块跳过 seg_off%32 字节 —— 两侧必须完全同规则，否则乱码。

    与 ctr_xor() 的差别：那个是"从 0 起、整段原地"，这个是"可任意起点"。
    ctr_xor_off(key, dom, 0, data) 与 ctr_xor(key, dom, data) 结果相同。
    """
    out = bytearray()
    ctr = seg_off // 32
    skip = seg_off % 32
    i = 0
    n = len(data)
    while i < n:
        ks = hashlib.sha256(
            key + bytes([dom]) + struct.pack('<I', ctr)).digest()
        for j in range(skip, 32):
            if i >= n:
                break
            out.append(data[i] ^ ks[j])
            i += 1
        skip = 0
        ctr += 1
    return bytes(out)


def strsec(so_path: str, out_path: str, master_hex: str,
           cert_hex: str, package: str) -> int:
    """加密 .ncxs 段（size-preserving）：只加密字符串，不碰 .rodata。

    ═══ 为什么只加密字符串，不加密整个 .rodata ═══════════════════════
    用户约束：「不能大量加密（否则无法利用压缩）」。

    实测（云端真实产物，arm64）：
        .rodata 134,644 B，zlib 压缩后 39,346 B
        整段 RC4 后压缩 134,695 B  → +95,349 B（+242%）
        只加密其中 4,734 B 字符串 → 41,034 B（+1,688 B，+4.3%）

    原因：加密把数据变高熵，zlib 完全失效。而 .rodata 里 115KB 是
    低熵的表/索引（熵≈3，本来也压不动）、14KB 高熵数据。加密它们
    只会让 APK 暴涨，收益接近零 —— 看不出含义的字节不需要加密。

    ═══ 为什么是 .ncxs 新段而不是原地改 .rodata ═══════════════════════
    ① .rodata 里字符串与跳转表混排，原地改需要精确识别边界，
       任何误判都会改坏常量 → 运行期崩溃且症状难定位。
    ② 新段可以让业务代码【显式选择】哪些字符串要加密（标注即生效），
       而不是全量扫描（那正是用户反对的"大量加密"）。
    ③ 新段不影响任何现有段名/偏移 → 历史产物兼容。

    ═══ 密钥 ═════════════════════════════════════════════════════════
    k_so（复用）+ CTR dom=0x03。不新增 HKDF label：7 个基值已占满，
    加一个要动 ncg_label_key + 第 8 张密文表 + 跨语言对拍，代价不值。
    复用 k_so 不降级安全性：拿到 k_so 的攻击者本来就能解 .ncx 业务
    代码，字符串是同一份资产的另一部分，不额外泄露。

    ═══ 时序 ═════════════════════════════════════════════════════════
    ⚠️ 必须在 lock() 【之后】：需要 master（lock 写入 .ncxhr）与证书。
       与 lock_head() 先后无所谓（改的是不同段）。

    ═══ fail-closed ══════════════════════════════════════════════════
    · 段不存在 → 跳过（本产物不启用字符串加密，合法）
    · 段存在但长度 0 → 报错（标记了却没内容，多半是 C 侧写错）
    · 加密后熵 < 7.0 → 报错（说明加密未生效）
    """
    with open(so_path, 'rb') as f:
        raw = f.read()
    elf = Elf(raw)

    sec = elf.find(NC_SEC_STR)
    if sec is None:
        print('   [strsec] 无 %s 段 —— 本产物不启用字符串加密（跳过）'
              % NC_SEC_STR)
        return 0
    if sec['size'] == 0:
        print('❌ %s 段长度为 0 —— 是否只写了 __attribute__ 却没有初值？'
              % NC_SEC_STR, file=sys.stderr)
        return 1
    if not (sec['flags'] & 0x2):          # SHF_ALLOC
        print('❌ %s 段不是 SHF_ALLOC，运行期无法定位' % NC_SEC_STR,
              file=sys.stderr)
        return 1

    master = bytes.fromhex(master_hex)
    cert = bytes.fromhex(cert_hex)
    if len(master) != 32 or len(cert) != 32:
        print('❌ --strsec 需要 32 字节 master hex 与 32 字节证书指纹 hex',
              file=sys.stderr)
        return 1

    key = hkdf_sha256(master, cert, ('nc-so-v1' + package).encode(), 16)

    plain = bytes(elf.data[sec['offset']:sec['offset'] + sec['size']])
    cipher = ctr_xor_off(key, 0x03, 0, plain)
    assert len(cipher) == len(plain)

    elf.data[sec['offset']:sec['offset'] + sec['size']] = cipher

    # 熵值安检：加密后必须高熵。低于 7.0 说明没真加密（例如段内容
    # 本身就是重复字节，或换错了 key —— 后者会静默产出"看起来加密了"
    # 但运行期解不开的产物）。
    ent = _entropy(cipher)
    if len(cipher) >= 256 and ent < 7.0:
        print('❌ [strsec] 加密后熵仅 %.2f —— 加密未生效' % ent,
              file=sys.stderr)
        return 1
    print('   [strsec] %s: %d 字节已加密（熵 %.2f）'
          % (NC_SEC_STR, sec['size'], ent))

    with open(out_path, 'wb') as f:
        f.write(bytes(elf.data))
    return 0


def _entropy(b: bytes) -> float:
    """香农熵（bit/byte）。用于判定"是否真加密"。"""
    if not b:
        return 0.0
    cnt = [0] * 256
    for x in b:
        cnt[x] += 1
    n = len(b)
    e = 0.0
    for c in cnt:
        if c:
            p = c / n
            e -= p * math.log2(p)
    return e


def check_entropy_or_fail(elf: 'Elf', sec_name: str) -> float:
    """校验某段加密后的熵值，异常则抛 ElfError（调用方按 fail-fast 处理）。

    为什么需要这道安检：so 加密是【自动捆绑】的层（用户没有勾选框可取消），
    一旦锁箱静默失效——比如段缺失时返回成功码、或某次改动把明文写回——
    流水线全绿、app 正常，用户完全感知不到。这类"静默失效"比漏洞本身更危险。
    熵值检查把它变成构建期炸响。

    ⚠️ 样本量门槛：N 字节的段最多只有 N 种不同取值，熵的理论上限是
    min(8, log2(N))。段长低于 ENTROPY_MIN_BYTES（256）时统计不具区分度
    （24 字节的上限仅 log2(24)≈4.59，再随机也过不了 7.0），直接跳过。
    """
    sec = elf.find(sec_name)
    if sec is None:
        raise ElfError('熵值安检失败：段 %s 不存在（加密未生效）' % sec_name)
    if sec['size'] < ENTROPY_MIN_BYTES:
        # 段太短，熵值统计不具区分度——跳过而非误判
        return 0.0
    seg = bytes(elf.data[sec['offset']: sec['offset'] + sec['size']])
    ent = shannon_entropy(seg)
    if ent < ENTROPY_MIN:
        raise ElfError(
            '熵值安检失败：段 %s 熵仅 %.3f（下限 %.1f）——'
            '这一段不是密文而是明文，加密未生效。'
            '排查方向：① 锁箱是否真的跑了 ② 段内容是否被后续步骤覆盖回明文'
            % (sec_name, ent, ENTROPY_MIN))
    return ent


def lock(so_path: str, out_path: str, section: str, cert: bytes,
         package: str, force: bool, dry: bool) -> int:
    """锁一个或多个段。

    section 支持逗号分隔的多段名（2026-10-19 新增），例如
    ".ncx,.ncxr"。多段共用同一把 k_so、同一个 MAC ——这是刻意的：
    它们逻辑上是同一份受保护资产（代码 + 它要用的常量表），拆成两把钥匙
    只会让运行期需要多解一次、多存一份 key，收益为零。
    为什么必须分两个 ELF 段：clang 不允许 const 数据进 AXR 段
    （'causes a section type conflict'），所以表只能另开一个 AWR 段。
    """
    with open(so_path, 'rb') as f:
        raw = f.read()
    elf = Elf(raw)

    sec_names = [s.strip() for s in section.split(',') if s.strip()]
    if not sec_names:
        print('❌ --section 为空', file=sys.stderr)
        return 1
    sec = elf.find(sec_names[0])
    if sec is None:
        print('❌ 段 %s 不存在。先确认 C 代码用 __attribute__((section("%s"))) 标记了它。'
              % (section, section), file=sys.stderr)
        print('   现有段: %s' % ', '.join(s['name'] for s in elf.sections), file=sys.stderr)
        return 1

    slot = elf.find(SLOT_NAME)
    if slot is None:
        print('❌ 密钥槽段 %s 不存在（Xop 的 .protwrap 等价物）。' % SLOT_NAME, file=sys.stderr)
        return 1

    elf.require_shf_alloc(sec)

    if sec['size'] == 0:
        print('❌ 段 %s 长度为 0，没有代码可锁' % section, file=sys.stderr)
        return 1

    # 幂等保护：已锁文件（slot 含非零 wrapped）默认拒绝，防二次加密毁数据
    existing = bytes(elf.data[slot['offset'] + 16: slot['offset'] + 16 + 16])
    if any(existing):
        if not force:
            print('❌ %s 已被锁（密钥槽非零）。二次锁会毁数据。用 --force 强制执行（仅调试）。'
                  % so_path, file=sys.stderr)
            return 1
        print('⚠️ --force：对已锁文件强制二次加密', file=sys.stderr)

    # 派生 so 域密钥
    # 派生 so 域密钥（2026-12 证书绑定，照抄 XopProtector key ladder）：
    #   k_so = HKDF-SHA256(ikm=master, salt=SHA256(certDER), info="nc-so-v1"+pkg, 16)
    # master 仍由打包侧注入（此处占位；占位值公开无所谓——盐是证书指纹，
    # 换 key 重打包 → cert 变 → k_so 变 → 密文解不开）。
    # ⚠️ C 侧 nc_guard_key.c 的 ncg_derive_k_so() 必须与本函数逐字节同规则，
    #    改一侧必须同步另一侧（本轮已用 3 场景对拍验证 HKDF/HMAC/SHA256）。
    if cert == b'\x00' * 32:
        # cert 全零 = 调用方没传真证书 → 拒绝锁箱。
        # 静默用全零 salt 等于把密钥暴露给"能跑本脚本的人"（仓库是公开的），
        # 那 4012 字节密文秒变明文。fail-fast，逼调用方提供真证书。
        raise ElfError('cert 全零：必须提供 --cert-hex（证书绑定；全零 salt 会使'
                       '密文可被公开脚本解开）')
    # ── master 随机化（2026-10-19）────────────────────────────────
    # 修实测报告静态 P1-1：master 原是全 0x11 占位符躺在 .rodata，
    # `od` 一条命令读出 → 配合 APK 证书离线算 k_so → 8 分钟解开 .ncx。
    #
    # 这里生成随机 master，并用它派生 k_so / k_mac。
    # master 本身【以明文写进 .ncxhr 段】——注意：这一步写的是
    # 明文，真正的保护来自随后的 --lock-head（用 k_stub 把它 XOR 成密文）。
    # 所以必须严格按「先一级锁箱、再二级锁箱」的顺序跑，中间产物不含明文
    # master 的窗口仅存在于构建机临时目录里。
    head_ro = elf.find(HEAD_RO_NAME)
    if head_ro is None:
        raise ElfError('段 %s 不存在 —— master 无处存放（nc_guard_boot.c 的 '
                       'ncg_master 需标段，且编译时要有 NC_GUARD_SECTIONED）'
                       % HEAD_RO_NAME)
    if head_ro['size'] < 32:
        raise ElfError('%s 仅 %d 字节，容不下 32 字节 master'
                       % (HEAD_RO_NAME, head_ro['size']))
    master = os.urandom(32)
    assert any(master), 'master 不能全零（全零会被运行期判为"未锁"）'
    elf.data[head_ro['offset']: head_ro['offset'] + 32] = master
    print('   master: 32 字节随机生成（将随二级锁箱藏入 %s）' % HEAD_RO_NAME)

    keys = derive_app_keys(master, cert, package or '')
    k_so = keys['so']
    k_mac = keys['mac']          # 2026-12 完整性校验专用，与 so 域硬分隔
    k_so_r = keys['so_r']        # 2026-10-28 .ncxr 专用，隔断 keystream 复用

    # ── 多段加密（2026-10-19：.ncx 代码 + .ncxr 常量表）──────
    # MAC 覆盖【所有密文的拼接】，于是任何一段被改都会让整体验签失败。
    #
    # ⚠️ 2026-10-28：各段不再共用 k_so（逆向报告 §6.2）。
    #   RC4 是流密码，每段独立调用 rc4() 都从 keystream 偏移 0 起 →
    #   两段共用同一段 keystream = two-time-pad 误用。
    #   实测 C_ncx[i]^C_ncxr[i] == P_ncx[i]^P_ncxr[i] 成立，已知 .ncxr
    #   明文即可反推 .ncx 同位置明文（报告已做交叉验证，前 96 字节完全一致）。
    #   现在按段序分配独立域密钥：第 0 段 k_so，第 1 段 k_so_r，再多段则
    #   用 HKDF 继续派生（当前只用两段，超出时显式报错而非静默复用）。
    #
    # ⚠️ 2026-11-13：改成【按段名】映射钥匙，不再按位置下标。
    #   .nct（VMP 数据段）是可选段 —— 没开第二套 VMP 的构建没有它。
    #   曾写死 (k_nct, k_so, k_so_r)，对没有 .nct 的老产物
    #   （--section .ncx,.ncxr）会把 k_nct 用在 .ncx 上 → 解出乱码 →
    #   test.sh 的 V6 报"正常包也会挂"。按名映射与位置无关，无此问题。
    #
    #   ⚠️ 三处必须一致（改任何一处都要同步另外两处）：
    #      so-section-lock.py 的 _KEY_BY_NAME     ← 本处
    #      nc_guard_boot.c 的 segs[] 顺序 + has_nct 分派
    #      protect.sh 的 --section 参数顺序
    _KEY_BY_NAME = {
        _LAYOUT['NC_SEC_CODE']: k_so,
        _LAYOUT['NC_SEC_CONST']: k_so_r,
        # k_nct = HKDF 的 'nc-insn-v1' 域 → .nct（第二套解释器）
        _LAYOUT['NC_SEC_VMP2']: keys['insn'],
        # k_bc  = HKDF 的 'nc-warm-v1' 域 → .ncq（VM 字节码）
        # ⚠️ 不能用 k_nct：RC4 流密码两段共用 keystream = two-time-pad 误用。
        _LAYOUT['NC_SEC_VMPBC']: keys['warm'],
        # .ncv = 消费方第二套字节码。用 'dex' 域（nc-dex-v1）。
        # ⚠️ 与 .ncq 的 k_bc 不同：两套链接进同一个 so，同钥匙 = keystream 复用。
        _LAYOUT['NC_SEC_VMPBC2']: keys['dex'],
    }
    segs = []                      # [(name, sec, plain, cipher)]
    for _idx, nm in enumerate(sec_names):
        sc = elf.find(nm)
        if sc is None:
            print('❌ 段 %s 不存在。先确认 C 代码用 __attribute__((section("%s"))) 标记了它。'
                  % (nm, nm), file=sys.stderr)
            print('   现有段: %s' % ', '.join(x['name'] for x in elf.sections),
                  file=sys.stderr)
            return 1
        elf.require_shf_alloc(sc)
        if sc['size'] == 0:
            print('❌ 段 %s 长度为 0，没有内容可锁' % nm, file=sys.stderr)
            return 1
        if nm not in _KEY_BY_NAME:
            print('❌ 段 %s 没有定义域密钥 —— 新增可锁段必须先在 '
                  'derive_app_keys() 里加对应 label 并在 _KEY_BY_NAME 登记，'
                  '不许静默复用钥匙' % nm, file=sys.stderr)
            return 1
        pl = bytes(elf.data[sc['offset']: sc['offset'] + sc['size']])
        segs.append((nm, sc, pl, rc4(_KEY_BY_NAME[nm], pl)))

    plain = segs[0][2]             # 兼容下方 dry-run 打印与旧日志
    cipher = segs[0][3]

    # 期望 MAC 对【密文】算，不对明文算：密文在解密前就可读，于是可以
    # "先验后解" —— 一旦被改过，根本不会把明文装进 .ncx（fail-closed）。
    # 若对明文算，就必须先解密再验，篡改的明文已经落盘生效，晚一步。
    # 另一个理由是 RC4 是流密码：改密文 1 位恰好只翻明文 1 位，未必崩溃，
    # 攻击者可以"改一位→跑→看行为"做廉价 oracle；MAC 让这种试探第一次就暴露。
    _mac_input = b''.join(sg[3] for sg in segs)   # 所有段密文按顺序拼接
    expect_mac = hmac_sha256(k_mac, _mac_input)

    if dry:
        print('[dry-run] 段 %s: %d 字节 → %d 字节（size-preserving=%s）'
              % (section, len(plain), len(cipher), len(plain) == len(cipher)))
        print('[dry-run] 密钥（hex）: %s' % k_so.hex())
        print('[dry-run] mac 域（hex）: %s' % k_mac.hex())
        print('[dry-run] 期望 MAC（hex，对密文算）: %s' % expect_mac.hex())
        print('[dry-run] 未写文件')
        return 0

    # 写回密文（各段原地，长度不变）
    for nm, sc, pl, ci in segs:
        elf.data[sc['offset']: sc['offset'] + sc['size']] = ci

    # 密钥槽：magic(16) + wrapped_k_so(16) + wrapped_k_mac(16) + expect_mac(32)
    #          + pkg_sha8(8) + reserved(8) = 96 字节
    #          .nck 段必须同步扩到 96（否则 assert 炸）
    # ⚠️ 切片窗口必须与 blob 等长：elf.data[a:b] = blob 若 len(blob) > b-a，
    # Python 会【插入】而非覆盖，把后续字节（段表/相邻段）顶坏。本人踩过。
    # 布局保持 magic+wrapped_k_so 在前 32 字节【不变】——旧 C 侧开箱代码
    # 从 offset 16 读 k_so，向前兼容。
    #
    # 2026-10-19 P1-a 扩容 80→96：
    #   [80:88] pkg_sha8 —— SHA256(包名) 前 8 字节。运行期用 /proc/self/cmdline
    #           取到的进程名算同样指纹做一致性校验，不一致即 fail-closed(-12)。
    #           存指纹而非明文包名：明文会暴露"密钥与包名有关"这条线索。
    #   [88:96] reserved —— 对齐预留，将来加字段不必再动长度契约。
    # ⚠️⚠️ 2026-10-19 P1-a 关键：slot[16:32] 不再存真实 k_so 的 wrapped 版本！
    #
    # 原实现 `wrapped = k_so ^ XOR_KEY` 会让 P1-a 完全失去意义：
    # 证书派生的目的就是"密钥不在文件里"，可 slot 里又躺了一份 packaged
    # 真密钥 → 攻击者 `slot[16:32] ^ XOR_KEY` 照样拿到 k_so，
    # 20 行 Python 解完，运行期派生再多也是白做。
    #
    # 现在这里写【诱饵】：确定性随机值，与真 k_so 无关。
    # 运行期 ncg_head_unlock() 从证书重新派生 k_so，根本不读这段。
    # 保留 16 字节是为了维持 slot 布局与"存在一个 k_so 字段"的假象，
    # 让攻击者以为自己找到了密钥（然后解出乱码）。
    #
    # 同理 k_mac 也不该落盘 —— 它是 HMAC 密钥，落盘等于把完整性校验
    # 交给攻击者。运行期同样从证书重新派生。
    # ⚠️ 2026-10-19 诱饵改真随机（原来是确定性 sha256，被复测报告识破）：
    #   报告 §7.1 实测第一版与第二版的 wrapped_k_so 完全相同
    #   （d6054d96f1e71285...），据此判定「它是诱饵死字段，不参与真实派生」。
    #   确定性诱饵的问题：同一个包名永远生成同一串字节，
    #   **两版产物一比对立功**——攻击者不需要懂任何密码学，只要 diff 两个 so。
    #   改 os.urandom 后每次构建都不同，diff 手法失效。
    _decoy_seed = os.urandom(16)
    wrapped = bytes(b ^ XOR_KEY[i % len(XOR_KEY)]
                    for i, b in enumerate(_decoy_seed))
    _decoy_mac = os.urandom(16)
    wrapped_mac = bytes(b ^ XOR_KEY[i % len(XOR_KEY)]
                        for i, b in enumerate(_decoy_mac))
    pkg_sha8 = hashlib.sha256((package or '').encode('utf-8')).digest()[:8]
    blob = (SLOT_MAGIC + wrapped + wrapped_mac + expect_mac
            + pkg_sha8 + b'\x00' * 8)
    assert len(blob) == _LAYOUT['NC_SLOT_SIZE'], \
        ('blob %d != NC_SLOT_SIZE %d（nc_guard_layout.h 与 C 侧 ncg_key_slot[] '
         '长度不一致；改一侧必须同步另一侧）'
         % (len(blob), _LAYOUT['NC_SLOT_SIZE']))
    assert len(blob) == slot['size'], \
        'blob %d != slot size %d（.nck 段需扩到 %d；改了一侧必须同步另一侧）' \
        % (len(blob), slot['size'], _LAYOUT['NC_SLOT_SIZE'])
    elf.data[slot['offset']: slot['offset'] + len(blob)] = blob

    # 熵值安检（2026-10-18）：必须在【写盘之前】。
    # 若放到写盘之后，fail-fast 时坏包已经落盘，protect.sh 虽然 exit 1 但
    # 文件已在——而它会被后续步骤当成有效产物。所以先验后写。
    if not dry:
        for nm, sc, pl, ci in segs:
            ent = check_entropy_or_fail(elf, nm)
            if ent > 0:
                print('   熵值安检[%s]: %.3f（下限 %.1f）✅' % (nm, ent, ENTROPY_MIN))
            else:
                _sec = elf.find(nm)
                print('   熵值安检[%s]: 段仅 %d 字节（< %d），样本不足跳过'
                      % (nm, _sec['size'] if _sec else 0, ENTROPY_MIN_BYTES))

    with open(out_path, 'wb') as f:
        f.write(bytes(elf.data))

    print('✅ 已锁: %s → %s' % (so_path, out_path))
    for nm, sc, pl, ci in segs:
        _kd = ('k_so' if nm == _LAYOUT['NC_SEC_CODE'] else
               'k_so_r' if nm == _LAYOUT['NC_SEC_CONST'] else
               'k_nct' if nm == _LAYOUT['NC_SEC_VMP2'] else
               'k_bc'  if nm == _LAYOUT['NC_SEC_VMPBC'] else
               'k_bc2' if nm == _LAYOUT['NC_SEC_VMPBC2'] else '?')
        print('   段 %s: %d 字节已加密（size-preserving，域密钥 %s）'
              % (nm, len(pl), _kd))
    print('   密钥槽 %s: %d 字节' % (SLOT_NAME, len(blob)))
    print('   ⚠️ 运行期需配套"开箱"代码解密；没有它，这段代码不可执行')
    return 0


# ── 二级锁箱：把 unlock 本体也锁进密文（自解谜）───────────────────
def lock_head(so_path: str, out_path: str, force: bool = False,
              cert: bytes = b'', package: str = '') -> int:
    """锁 .ncxh 段，并给明文 stub 写它的密钥槽。

    这是"把开锁器锁进它开的那只箱子"的构建期半边：
      .ncxh（unlock 本体）← 用 k_stub 锁
      .ncks（stub 的槽）    ← 写 magic + wrapped_k_stub + stub/head 段
                                     链接期地址 + head_size，让明文 stub 能解它

    k_stub 与 k_so 必须是两把钥匙：stub 只负责解 head，head 才负责解
    业务段。复用一把 = 解开 head 就等于拿到业务段的钥匙，分级失去意义。

    段地址取自 section header table（strip 只删 .symtab/.strtab，段表始终
    完整）。明文 stub 靠 `&ncg_stub_slot(PC 相对) - stub_sh_addr` 算出镜像
    基址，再加 head_sh_addr 定位 head 段 —— 全程不读盘、不碰符号表。
    """
    with open(so_path, 'rb') as f:
        raw = f.read()
    elf = Elf(raw)

    head = elf.find(HEAD_NAME)
    if head is None:
        # ⚠️ 2026-10-18 从 return 0 改为 return 1（fail-fast）。
        # 此前这里"跳过二级锁箱"并返回 0（exit code 0 = 成功），而
        # protect.sh 的判据是 exit != 0 才失败 → 段缺失时静默放行：
        # unlock 本体保持明文、自解谜没发生，但流水线显示成功。
        # 这正是"以为防了其实没防"的静默降级，最该避免。
        #
        # 为什么可以安全地 fail-fast：走到这里说明 protect.sh 已经进了
        # `if [[ -d "$WORK/project/libs" ]]` 分支，即本就要编译 libnc.so；
        # 而只要编译了，nc_guard_boot.c 就在工程里、.ncxh 段就该在。
        # 段不在 = 拷贝漏了 / boot.c 没编入 / 段被 gc-sections 回收，
        # 三种都是真实配置错误，没有一种应该放行。
        # （纯 dex 组合如只勾 stringenc 时根本不调 lock_head，不受影响。）
        print('❌ 段 %s 不存在 —— 二级锁箱无法进行。'
              % HEAD_NAME, file=sys.stderr)
        print('   排查方向：① nc_guard_boot.c 是否拷进 NDK 工程'
              '（protect.sh 的拷贝清单）② 段是否被 --gc-sections 回收'
              '（检查 ncg_key_slot/ncg_stub_slot 的 retain）'
              '③ nc_guard_key.h 是否一并拷入', file=sys.stderr)
        return 1

    slot = elf.find(STUB_SLOT)
    if slot is None:
        print('❌ 密钥槽段 %s 不存在（nc_guard_boot.c 的 ncg_stub_slot 未编入）'
              % STUB_SLOT, file=sys.stderr)
        return 1

    if head['size'] == 0:
        print('❌ 段 %s 长度为 0，没有 unlock 本体可锁' % HEAD_NAME, file=sys.stderr)
        return 1

    # 幂等：已锁（slot magic 在）默认拒绝，防二次加密毁数据
    existing = bytes(elf.data[slot['offset']: slot['offset'] + 8])
    if existing == STUB_MAGIC and not force:
        print('❌ %s 已被锁（stub 槽 magic 已写）。二次锁会毁数据。'
              % so_path, file=sys.stderr)
        return 1

    # ⚠️ 2026-10-18 不再从 .symtab 读入口符号 —— NDK ndk-build 默认 strip
    # 符号表，CI 39074690534 实测因此 fail-fast（"符号 ncg_head_unlock 不在
    # .symtab"）。也不能靠"让 CI 不 strip"绕过：那会把 frida_port_probe /
    # xposed_maps_probe 等探针名暴露进符号表，等于泄露检测意图。
    # 改用【section header table】——strip 只删 .symtab/.strtab，段表始终完整。
    # stub 侧靠 slot 里的 stub_sh_addr + 自身 PC 相对地址算出镜像基址，
    # 再加 head_sh_addr 定位 head 段，全程不碰符号表。

    # k_stub：与 k_so 独立的第二把钥匙。
    #
    # ⚠️⚠️ 2026-10-22 改为【每次构建随机】（原为硬编码常量）。
    # 原注释的理由是"真正的盐是证书指纹，占位值公开不影响换 key 重打包即失效"
    # —— 那个理由对 k_so 成立，对 k_stub【不成立】：
    #   · k_so 走 HKDF(master, SHA256(certDER), pkg)，证书是外部输入，硬编码占位无妨；
    #   · k_stub 直接就是 .ncxh 的加密钥匙，它硬编码在【公开仓库】里 =
    #     攻击者不用逆向，读 so-section-lock.py 第 873 行就知道 k_stub，
    #     再配合 slot 里明文的 wrapped_k_stub 反推 XOR_KEY，.ncxh 直接可解。
    # 实测确认随机化零风险：k_stub 只被本函数 wrap 进 slot，运行期
    # ncg_stub_recover() 从 slot unwrap 取回（boot.c:845），全程不依赖"值是什么"。
    k_stub = os.urandom(16)
    assert len(k_stub) == 16

    # ── 阶段3 代码自绑定（2026-10-19）────────────────────────────────
    # 修强度报告 §6「抗静态 patch = 弱」：此前 k_stub 与代码零关联，
    # 攻击者 patch 明文 stub（如把 HMAC 校验改恒真）无需代价。
    #
    # 现在把 .text 段的 CRC32 混进实际用于加密的密钥：
    #   cipher_key = k_stub ^ fold(crc32(.text))
    # 运行期 stub 先对 .text 算同样的 CRC，异或回去，才能得到正确密钥。
    # 改任何一处明文代码 → CRC 变 → 密钥错 → head 解出乱码 → SIGILL。
    #
    # 为什么能自洽：.text 段 addr==offset 且整体无重定位
    # （实测 readelf -r 的重定位全部落在 0x71d0 之后，.text 结束于 0x2714），
    # 所以锁箱期按文件算的 CRC == 运行期按内存算的 CRC。
    # 注意：CRC 覆盖 .text【锁箱前】的字节；二级锁箱只改 .ncxh，
    # 不动 .text，所以运行期看到的 .text 与锁箱期完全一致。
    text_sec = elf.find('.text')
    if text_sec is None:
        raise ElfError('.text 段不存在，无法做代码自绑定（阶段3）')
    _text_bytes = bytes(elf.data[text_sec['offset']:
                                 text_sec['offset'] + text_sec['size']])
    code_crc = zlib.crc32(_text_bytes) & 0xFFFFFFFF
    # 折叠进 16 字节密钥：与 C 侧 `k[i] ^= (crc >> ((i&3)*8)) & 0xFF` 同规则
    k_stub_eff = bytes(
        k_stub[i] ^ ((code_crc >> ((i & 3) * 8)) & 0xFF) for i in range(16)
    )
    print('   代码自绑定: CRC32(.text)=0x%08x → 已混入 k_stub' % code_crc)
    # k_mac_head：第三把钥匙，只用于 head 段的完整性校验（P0-b）。
    # 与 k_stub / k_so 都必须不同——复用任何一把都意味着"解开 head 就等于
    # 拿到业务段的钥匙"或"知道解密钥匙即可伪造 MAC"，分级失去意义。
    #
    # ⚠️⚠️ 2026-10-22 同 k_stub：改为【每次构建随机】。
    # 原为硬编码常量，等于把"可伪造 head MAC"的能力印在公开仓库里——
    # 攻击者拿到 k_mac_head 就能对任意篡改后的 .ncxh 重算正确 MAC，
    # P0-b 那层完整性校验完全失效（报告 §五「解密器全部明文」的核心）。
    # 零风险：运行期从 slot[NC_OFF_K_MAC_HEAD] unwrap 取回（boot.c:888），
    # 不依赖"值是什么"，只依赖"两边一致"。
    k_mac_head = os.urandom(16)
    assert len(k_mac_head) == 16

    # ── master 随机化 + 藏进 .ncxhr（2026-10-19）──────────
    #
    # 修实测报告静态 P1-1：master[32] 原是 static const 全 0x11 的占位符，
    # 躺在 .rodata，`od` 一条命令读出 → 配合 APK 证书离线算 k_so →
    # 8 分钟解开 .ncx。全程不需要运行、不需要真机、不需要私钥。
    #
    # 只换成随机数不够：随机值若仍是 .rodata 裸常量，`od` 一样读，成本不变。
    # 必须【同时】做到：值随机 + 藏在读不到的地方。
    #
    # 现在：master 写进 .ncxhr 段，用【k_stub】加密（不是 k_so！）。
    #   · 用 k_stub：链路单向 —— 碎片 → XOR_KEY → k_stub → {解 head,
    #     解 head_ro → master} → k_so。没有循环依赖。
    #   · 用 k_so 会死循环：k_so 的派生正需要 master。
    #
    # 攻击链从 2 步变 5 步，且中间产物全不是明文常量。
    head_ro = elf.find(HEAD_RO_NAME)
    if head_ro is None:
        raise ElfError('段 %s 不存在 —— master 无处存放（nc_guard_boot.c 的 '
                       'ncg_master 是否被标段？需 NC_GUARD_SECTIONED）'
                       % HEAD_RO_NAME)
    if head_ro['size'] < 32:
        raise ElfError('%s 只有 %d 字节，容不下 32 字节 master'
                       % (HEAD_RO_NAME, head_ro['size']))
    # master 已由一级锁箱（lock()）写入明文，这里只负责加密它。
    # ⚠️ 顺序不可颠倒：lock() 要用 master 派 k_so，所以它必须先存在；
    #    lock_head() 用 k_stub 把它锁起来。反过来做就没有 master 可用。
    ro_plain = bytes(elf.data[head_ro['offset']:
                             head_ro['offset'] + 32])
    if not any(ro_plain):
        raise ElfError('%s 里的 master 全零 —— 一级锁箱没跑过？'
                       '必须严格按「先 --section 再 --lock-head」的顺序'
                       % HEAD_RO_NAME)
    master = ro_plain
    # ⚠️ 2026-10-30：原为 16 字节周期 XOR（`master[i] ^ k_stub_eff[i % 16]`），
    #   对已知明文完全透明（见 ctr_keystream 的说明）。改为 SHA-256-CTR。
    #   dom=CTR_DOM_HEADRO，与 head 段用不同域 → 不构成 two-time pad。
    ro_cipher = ctr_xor(k_stub_eff, CTR_DOM_HEADRO, master)
    # ⚠️ 等长覆盖：切片赋值长度不等会"插入"而非"覆盖"，顶坏后续字节
    assert len(ro_cipher) == 32
    elf.data[head_ro['offset']: head_ro['offset'] + 32] = ro_cipher
    print('   master: 已锁入 %s（用 k_stub，非 k_so；攻击链 +3 步）'
          % HEAD_RO_NAME)

    plain = bytes(elf.data[head['offset']: head['offset'] + head['size']])
    # ⚠️ 2026-10-30：原为 16 字节周期 XOR（`b ^ k_stub_eff[i % 16]`）。
    #   周期 XOR 对已知明文完全透明——ARM64 函数序言高度可猜，攻击者对
    #   密文做间隔 16 的自相关即可恢复整个密钥 → head 明文直接到手。
    #   改为 SHA-256-CTR（见 ctr_keystream 的完整理由）。
    #
    # ⚠️ 仍不能用 rc4()：stub 侧（.text 明文）不能出现 256 字节 S 盒
    #   初始化循环——那是"这是 RC4"的活招牌，且会撑大攻击者唯一能直读的
    #   stub。SHA-256 已在 .text 明文段可用（nc_guard_key.c 的 ksha256），
    #   stub 已在用它验 head MAC → 零新增依赖。
    #   2026-10-18 踩过的坑（两侧算法不一致 → 乱 C → SIGILL exit 132）
    #   由 test-so-lock.sh T32 的跨语言对拍兜住。
    cipher = ctr_xor(k_stub_eff, CTR_DOM_HEAD, plain)

    elf.data[head['offset']: head['offset'] + head['size']] = cipher

    # P0-b：对【密文】算 HMAC-SHA256(k_mac_head, head 密文)。
    # 与 .ncx 的 expect_mac 完全同构——解密前就能验，验不过就不装明文。
    # 在此之前 head 段只有 XOR，攻击者可改 head 密文中对应"unlock 本体的
    # MAC 校验函数"那几位，把 .ncx 的 HMAC 保护改成恒真从而绕过。
    expect_mac_head = hmac_sha256(k_mac_head, cipher)

    # stub 槽（96 字节，2026-10-19 阶段3）：magic(8) + wrapped_k_stub(16)
    #   + stub_sh_addr(4) + head_sh_addr(4) + head_size(4)
    #   + code_addr(4) + code_len(4) + reserved(4)          ← 阶段3 新增 8+4
    #   + wrapped_k_mac_head(16) + expect_mac_head(32)
    # ⚠️ 全程用 section header table 的 sh_addr/size，不碰 .symtab（见上方注释）
    #
    # 阶段3 代码自绑定（修强度报告「抗静态 patch = 弱」）：
    #   code_addr/code_len 指向 .text 段。运行期 stub 对这段算 CRC32 并
    #   异或进 k_stub —— 改任何一处明文代码 → CRC 变 → k_stub 变 →
    #   head 解出乱码。没有"校验分支"可以单独 patch 掉，形成链式依赖。
    #   为什么能自洽：.text 段 addr==offset 且【整体无重定位】
    #   （readelf -r 的重定位全部落在 0x71d0 之后，而 .text 结束于 0x2714），
    #   所以锁箱期按文件算的 CRC 与运行期按内存算的完全相同。
    import struct as _s
    text = elf.find('.text')
    if text is None:
        raise ElfError('.text 段不存在，无法做代码自绑定（阶段3）')
    wrapped = bytes(b ^ XOR_KEY[i % len(XOR_KEY)] for i, b in enumerate(k_stub))
    wrapped_mac = bytes(b ^ XOR_KEY[i % len(XOR_KEY)]
                        for i, b in enumerate(k_mac_head))
    # 碎片区（2026-10-21）：XOR_KEY 的 4 个 uint16，构建期随机生成。
    # ⚠️ 碎片的【逻辑序】必须与 C 侧 ncg_xor_key 的读取规则一致：
    #    C 侧按 NC_XOR_FRAG 查表 + 高低位规则拼回——但查表本身在 C 侧
    #    仍以常量表存在（.rodata 的 8 字节表，见复盘报告"已摸清"）。
    #    本处直接按"逻辑字节 i 的真实值"生成随机碎片，并同步随机化
    #    查表（NCG_XOR_FRAG 表也在 .rodata——它必须与碎片配套！）
    #    ⚠️⚠️ 但 .rodata 表是【编译期】常量，锁箱器改不了它——
    #    所以碎片必须【按 C 侧既定的查表规则】反推生成：
    #    逻辑字节 i 取 frag[FRAG_TABLE[i]] 的低/高 8 位。
    #    FRAG_TABLE = NC_XOR_FRAG（从 layout.h 抽取）。
    #    锁箱器为每个逻辑字节随机挑一个"放置碎片"并填入对应槽位，
    #    使拼回结果 == 原 XOR_KEY（与 C 侧运行期行为逐字节一致）。
    frag_table = _LAYOUT.get('NC_XOR_FRAG_INIT')
    if not frag_table or len(frag_table) != 8:
        raise ElfError('NC_XOR_FRAG_INIT 缺失或长度异常——layout.h 被改坏？')
    # 4 个碎片槽位，每个 uint16：低 8 位 = 逻辑字节 i<4，高 8 位 = 逻辑字节 i>=4
    frag_slots = [None, None, None, None]   # [uint16 序号] = 16 位值
    for logical, slot_idx in enumerate(frag_table):
        target_byte = XOR_KEY[logical]
        if logical < 4:
            placed = frag_slots[slot_idx]
            lo = target_byte
            hi = (placed >> 8) if placed is not None else os.urandom(1)[0]
            frag_slots[slot_idx] = (hi << 8) | lo
        else:
            placed = frag_slots[slot_idx]
            hi = target_byte
            lo = (placed & 0xFF) if placed is not None else os.urandom(1)[0]
            frag_slots[slot_idx] = (hi << 8) | lo
    # 未被引用的槽位（若查表有重复引用则全被占）填随机值
    frag_bytes = b''.join(_s.pack('<H', v if v is not None else int.from_bytes(os.urandom(2), 'little'))
                          for v in frag_slots)
    # 自检：用 C 侧同款规则拼回，必须 == XOR_KEY
    _verify = bytearray(8)
    for logical, slot_idx in enumerate(frag_table):
        v = _s.unpack('<H', frag_bytes[slot_idx*2: slot_idx*2+2])[0]
        _verify[logical] = (v & 0xFF) if logical < 4 else ((v >> 8) & 0xFF)
    if bytes(_verify) != XOR_KEY:
        raise ElfError('碎片生成自检失败：拼回 != XOR_KEY（查表规则与生成不一致）')
    blob = (STUB_MAGIC + wrapped
            + _s.pack('<I', slot['addr'])
            + _s.pack('<I', head['addr'])
            + _s.pack('<I', head['size'])
            + _s.pack('<I', text['addr'])
            + _s.pack('<I', text['size'])
            + _s.pack('<I', 0)
            + wrapped_mac
            + expect_mac_head
            + _s.pack('<I', head_ro['addr'])
            + _s.pack('<I', 32)
            + frag_bytes)
    assert len(blob) == _LAYOUT['NC_STUB_SIZE'], \
        ('stub blob %d != NC_STUB_SIZE %d（nc_guard_layout.h 与 C 侧 '
         'ncg_stub_slot[] 长度不一致；改一侧必须同步另一侧）'
         % (len(blob), _LAYOUT['NC_STUB_SIZE']))
    assert len(blob) == slot['size'], \
        'blob %d != slot size %d（.ncks 段需扩到 %d 字节；' \
        '改 nc_guard_layout.h 的 NC_STUB_SIZE 必须同步 C 侧）' \
        % (len(blob), slot['size'], _LAYOUT['NC_STUB_SIZE'])
    elf.data[slot['offset']: slot['offset'] + len(blob)] = blob

    # ═══ T4（2026-10-28）：加密两个槽段 ══════════════════════════════
    # 必须在【一级锁箱与二级锁箱都写完之后】执行——两处都要往槽里写字。
    # 见 nc_guard_layout.h 的 T4 说明与 nc_guard_boot.c 的 ncg_boot_key()。
    _encrypt_slots(elf)

    # 熵值安检（2026-10-18）：必须在【写盘之前】，理由同 lock()——
    # fail-fast 时坏包不能已经落盘，否则会被后续步骤当成有效产物。
    # head 段通常 1-2KB（CI 实测 arm64 1588B / v7a 1112B），RC4 输出熵在
    # 7.4 左右，远高于普通代码段的 6.6~6.9。低于 256 字节时自动跳过
    # （采样不足，见 check_entropy_or_fail 的说明）。
    ent = check_entropy_or_fail(elf, HEAD_NAME)
    print('   熵值安检: %.3f（下限 %.1f）✅' % (ent, ENTROPY_MIN))

    # ── 诱饵组（2026-11-27）─────────────────────────────────────────
    #
    # 必须在真锁箱【全部完成之后】：诱饵要用真 .text 的 CRC32 做自绑定，
    # 而 .text 在 lock_head 期间不变（只有 .ncxh/.ncxhr/.ncks 被改），
    # 所以此时取 .text 与真路径看到的完全一致。
    #
    # ⚠️ 必须在 _encrypt_slots() 之后：否则诱饵槽会被 T4 的 boot_key
    #    加密，而诱饵链的派生规则里没有这一步 → 攻击者解不出诱饵槽
    #    → 诱饵立刻露馅（这正是「必须先做完真的再做假的」的原因）。
    #
    # ⚠️ 失败必须 fail-fast：诱饵段存在却填不进内容 = 段表里有 N 组
    #    【全零】的平行段，攻击者一眼看出哪些是真的（全零的必然是没填的）。
    #    这比不做诱饵更糟——它反过来成了「真段在这里」的路标。
    n_bait = _detect_bait_groups(elf)
    if n_bait > 0:
        _txt = _text_bytes_of(elf)
        # 先落盘再读回：诱饵段不在当前 elf 视图里被改过，直接原地改即可，
        # 但 bait_groups 需要完整的"真锁箱已完成"状态，所以先写临时文件。
        _tmp = out_path + '.bait.tmp'
        with open(_tmp, 'wb') as f:
            f.write(bytes(elf.data))
        if bait_groups(_tmp, _tmp, n_bait, _txt, cert, package) != 0:
            try:
                os.unlink(_tmp)
            except OSError:
                pass
            print('❌ 诱饵生成失败 —— 拒绝产出「有诱饵段但没内容」的产物'
                  '（那本身就是真段路标）', file=sys.stderr)
            return 1
        with open(_tmp, 'rb') as f:
            elf.data = bytearray(f.read())
        try:
            os.unlink(_tmp)
        except OSError:
            pass
    else:
        print('   诱饵: 0 组（nc_guard_decoy.c 未编入或 NCG_BAIT_N=0）')

    with open(out_path, 'wb') as f:
        f.write(bytes(elf.data))

    print('✅ 二级锁箱: %s → %s' % (so_path, out_path))
    print('   段 %s: %d 字节已加密（unlock 本体）' % (HEAD_NAME, head['size']))
    print('   密钥槽 %s: %d 字节（magic + wrapped_k_stub + stub/head addr + size）'
          % (STUB_SLOT, len(blob)))
    print('   段地址: stub=0x%x head=0x%x size=0x%x（取自 section header table）'
          % (slot['addr'], head['addr'], head['size']))
    print('   ⚠️ 静态视角：unlock 本体已不可读，只剩明文 stub')
    return 0


# ══════════════════════════════════════════════════════════════════════
# 诱饵组（bait groups）—— 拉长攻击路径
# ══════════════════════════════════════════════════════════════════════
#
# 设计目标：让「零信息静态逆向」从「认出唯一一组加密段」变成
# 「在 N+1 组同构段里逐组排除」。核心不是挡住，是把时间转移到错路上。
#
# 关键纪律（缺一条诱饵就失效）：
#   ① 结构自洽：诱饵槽里的 expect_mac_head 必须用【诱饵自己的】
#      k_mac_head 正确计算。攻击者的 HMAC 校验会通过 → 他确信走对了。
#   ② 内容可信：诱饵 head 解出来必须是【真实 ARM64 代码】（从 .text
#      抄一段），能反汇编、序言合法 → 他确信解开了。
#   ③ 最后才失败：只有用诱饵 master 派生 k_so 解 .ncx 时才失败。
#      此时他已投入大量工作，会怀疑【自己实现错了】而不是怀疑诱饵。
#
# 若违反 ①②（比如填随机字节），攻击者解出来是乱码，5 秒排除 → 等于没做。
#
# ⚠️ 诱饵 master 必须是随机的：若与真 master 相同，等于把真 master
#    多抄了 N 份，攻击者用诱饵链反而直接命中。

def _bait_specs(n):
    """返回 [(head_name, slot_name, ro_name, code_name, idx), ...]。

    ⚠️ 段名必须与真段【平行】（.ncx → .ncx0），不能叫 .decoy/.bait——
    那等于在段表上写「这条是假的」。
    ⚠️ 与 nc_guard_decoy.c 的 section 名逐字一致。改这个名单
    必须同步那个 .c 文件，以及 test.sh 的 V18 断言。
    """
    return [('.ncxh%d' % i, '.ncks%d' % i, '.ncxhr%d' % i, '.ncx%d' % i, i)
            for i in range(n)]


# 诱饵段基名 → 真段名。用于让随机名与真段【同名长】。
# ⚠️ 长度一致很重要：若 .ncx(4字符) 旁边混着 4 字符和 5 字符的诱饵名，
#    "长度参差"本身就是比原方案更明显的痕迹。
_REAL_NAME_FOR_LEN = {
    '.ncx': '.ncx', '.ncxh': '.ncxh', '.ncks': '.ncks', '.ncxhr': '.ncxhr',
}


def _rename_section_inplace(elf: 'Elf', sec, new_name: str) -> bool:
    """原地改段名（只改 shstrtab 里的字符串，不重写 ELF 结构）。

    ═══ 为什么需要这个 ═══════════════════════════════════════════════
    用户指出的破绽：`.ncx` 无后缀、`.ncx0/.ncx1` 带数字 ——
    任何逆向者 2 秒内就知道"无后缀的是原件"。这是段表白送的答案。

    只改【诱饵】的名字就能消除它：诱饵不被任何代码引用，叫什么都可以。
    真段必须保留 `.ncx`（解锁链按名字查），但改完后段表长这样：

        .ncx    ← 真的
        .k3f9   ← 诱饵（随机名，与 .ncx 无任何命名规律）
        .q7f2   ← 诱饵

    攻击者再也无法靠"有没有数字后缀"定位真段。

    ═══ 为什么不用 objcopy --rename-section ══════════════════════════
    实测它会重写 ELF，而 `AGENTS.md §5.4` 明确警告：lock/lock-head 已把
    链接期 sh_addr 写进 .nck/.ncks，任何段挪动都会让运行期基址计算全错，
    且崩溃点是 .ncxh 里的 SIGILL —— 症状完全不指向 objcopy。

    本函数只改 shstrtab 里的几个字节，实测段地址/偏移【完全不变】
    （验证：改名前 .ncx addr=0x630，改名后仍 0x630）。

    ═══ 关键约束 ═══════════════════════════════════════════════════
    ⚠️ 新名长度必须 <= 原名长度，且剩余字节补 NUL。
       段名在 shstrtab 里是 NUL 结尾的紧凑字符串，写超长会覆盖下一个段名。
       诱饵原名如 `.ncxh0`(6B)，所以随机名也必须 <= 6B。
    ⚠️ 新名不能与现有任何段名冲突（否则 readelf 显示重复，反而更可疑）。
    ⚠️ 新名不能用 `.` 结尾或含空格/非打印字符 —— readelf 会显示乱码。
    """
    raw = new_name.encode('ascii')
    if len(raw) > len(sec['name']):
        return False                      # 超长会覆盖相邻字符串
    strh = elf.sections[elf.e_shstrndx]
    base = strh['offset'] + sec['name_off']
    # 原位置总占用 = 名字长度 + 1（NUL 终止符）
    span = len(sec['name'])
    elf.data[base:base + span] = raw + b'\x00' * (span - len(raw))
    sec['name'] = new_name
    return True


def _random_section_name(elf: 'Elf', maxlen: int, taken: set,
                         want_len: int = 0) -> str:
    """生成与真实段名同风格、且不冲突的随机名。

    ⚠️ 三条「不能做」，都是 2026-11-28 实测段表后修出来的：
      ① 不能叫 .decoy0 / .bait0 —— 等于写「我是假的」
      ② 不能以数字开头（如 .1ln）—— 真实段名都是字母开头
         （.text/.rodata/.data/.bss/.got/.plt 无一例外）
      ③ 不能长短不一（.1ln 与 .rerq 混排）—— 同一批段名长度参差，
         比原方案（统一的 .ncx0/.ncx1）更可疑

    策略：`点 + 字母开头 + 字母数字`，总长固定 want_len（= 对应真段名
    长度）。这样段表里看起来像"同一套命名体系下的不同成员"，
    而不是"有人随机生成的名字"。

    want_len 为 0 时退化为 maxlen。
    """
    import string
    import random
    alpha = string.ascii_lowercase
    alnum = string.ascii_lowercase + string.digits
    want = want_len if want_len else maxlen
    if want > maxlen or want < 3:
        want = maxlen
    for _ in range(200):
        body = random.choice(alpha)                     # 首字符必须是字母
        body += ''.join(random.choice(alnum) for _ in range(want - 2))
        new = '.' + body
        if len(new) != want or len(new) > maxlen:
            continue
        if new in taken or elf.find(new) is not None:
            continue
        return new
    return ''


def _resize_section(elf: 'Elf', sec, new_size: int) -> bool:
    """把段的 sh_size 改成 new_size（只改段表，不挪数据）。

    ⚠️ 为什么必须这么做：诱饵段在 C 里声明成固定大小（8192B 的 .ncx0），
    而真 .ncx 实测只有 188B。若不裁，段表上是
        .ncx   0xbc    ← 真
        .ncx0  0x2004  ← 诱饵
    大小差 43 倍，攻击者 `readelf -S | sort -k2` 一眼就认出哪个是真的，
    诱饵全部失效。裁到同尺寸后两组无法区分。

    ⚠️ 只能缩小不能放大（放大要挪数据、改 sh_offset，会破坏后续段）。
    调用方负责保证 new_size <= 当前 size。

    ⚠️ 改了 sh_size 之后，段内超出 new_size 的字节仍在文件里，
    但不再是"段内容" —— 这不影响任何东西：诱饵不被任何代码引用，
    也没有程序会去读它。攻击者按段表读，看到的正是 new_size 字节。
    """
    if new_size > sec['size']:
        return False
    off = elf.e_shoff + (sec['index'] if 'index' in sec else 0) * elf.e_shentsize
    # 用段在 sections 列表中的位置定位（Elf 解析时未存 index，这里回溯）
    idx = None
    for i, s in enumerate(elf.sections):
        if s is sec:
            idx = i
            break
    if idx is None:
        return False
    off = elf.e_shoff + idx * elf.e_shentsize
    if elf.is64:
        # Elf64_Shdr: name(4) type(4) flags(8) addr(8) offset(8) size(8) ...
        # sh_size 在偏移 32
        struct.pack_into('<Q', elf.data, off + 32, new_size)
    else:
        # Elf32_Shdr: name(4) type(4) flags(4) addr(4) offset(4) size(4) ...
        # sh_size 在偏移 20
        struct.pack_into('<I', elf.data, off + 20, new_size)
    sec['size'] = new_size
    return True


def bait_groups(so_path: str, out_path: str, n_groups: int,
                text_src: bytes = b'', cert: bytes = b'',
                package: str = '') -> int:
    """给诱饵段填入自洽内容（在 --lock-head 之后调用）。

    参数：
      text_src  用于派生诱饵 head 明文的【真实代码字节】。必须来自
                已链接的 .text（攻击者反汇编确认是 ARM64 后才会相信）。
      cert      真证书 SHA-256（32B）。诱饵 .ncx 必须用【真证书】派生
                k_so —— 否则攻击者拿真证书解得乱码，立刻排除这组。
      package   真包名。同上，HKDF info 里含包名。

    返回 0 成功 / 1 失败。**失败必须 fail-fast**：静默跳过会让「以为
    加了诱饵其实没加」重演（.comment 失效三个月那次就是这类错误）。
    """
    if len(cert) != 32:
        print('❌ bait_groups 需要 32 字节证书（诱饵 .ncx 必须用真证书派生）',
              file=sys.stderr)
        return 1
    with open(so_path, 'rb') as f:
        raw = f.read()
    elf = Elf(raw)

    specs = _bait_specs(n_groups)
    # 先确认全部段都在——缺一个就整体失败，不做「能填几个填几个」的
    # 部分成功（那会产生「有的组像真的、有的明显是假的」的段表，
    # 反而给攻击者送筛除线索）。
    found = []
    for head_n, slot_n, ro_n, code_n, idx in specs:
        h, s = elf.find(head_n), elf.find(slot_n)
        r, c = elf.find(ro_n), elf.find(code_n)
        if h is None or s is None or r is None or c is None:
            print('❌ 诱饵段缺失：%s / %s / %s / %s（nc_guard_decoy.c 是否编入？'
                  'NCG_BAIT_N 是否为 %d？）'
                  % (head_n, slot_n, ro_n, code_n, n_groups), file=sys.stderr)
            return 1
        if h['size'] == 0 or s['size'] < _LAYOUT['NC_STUB_SIZE'] or r['size'] < 32:
            print('❌ 诱饵段 %s 尺寸异常（head=%d slot=%d ro=%d）'
                  % (head_n, h['size'], s['size'], r['size']), file=sys.stderr)
            return 1
        found.append((h, s, r, c, idx))

    # ── 诱饵 head 的明文：必须是真实 ARM64 代码 ─────────────────────
    #
    # 为什么抄 .text：攻击者验证「解开没有」的标准动作是
    # `objdump -D -b binary -m aarch64` 看能否反汇编成合法指令。
    # 若诱饵明文是随机字节，反汇编会得到海量非法指令 → 立刻排除。
    # 抄一段真实 .text 后，他将看到 stp/sub/ldr 等标准序言，无法区分。
    #
    # ⚠️ 不能抄 .text 的【开头】：那是明文，攻击者可以逐字节比对，
    #    发现诱饵 head 明文与 .text 首字节相同 → 立刻识破是复制。
    #    所以从 .text 中段取，且每组的取法不同。
    if not text_src:
        print('❌ bait_groups 缺少 .text 样本（无法构造可信的诱饵明文）',
              file=sys.stderr)
        return 1

    # ── 尺寸对齐：诱饵段必须与真段【同量级但不同值】───────────────
    #
    # ⚠️⚠️ 这里有两个互相拉扯的要求，2026-11-27 两版都没做对：
    #
    #   第一版：诱饵容量直接用链接期大小（8196B / 真段 192B）
    #           → 差 42 倍，攻击者 `readelf -S | sort -k6` 一眼认出真段。
    #   第二版（修完）：把诱饵裁到【与真段逐字节相等】
    #           → 三份 11344B / 3760B 精确相同。这个也不自然：
    #             自然编译绝不会产生两个字节数完全相等的段，
    #             而且"数值完全相同"本身就是人造痕迹。
    #
    # 现在：同量级、不同值。真段 N，诱饵在 N 的 ±4% 内浮动（下限保证
    # 不为 0）。效果：
    #   · 按大小排序，真段既不在首也不在尾，位置随机 → 排序法失效
    #   · 三份数值互不相同 → 没有"三胞胎"这种人造感
    #   · 仍在同一数量级 → 不能用"大小差太多"排除诱饵
    #
    # ⚠️ 浮动幅度不能太大：超过 ~10% 就会形成"明显偏小/偏大"的簇，
    #    攻击者可以按簇排除。4% 是实测下来既能打破相等、又不形成簇的值。
    #
    # ⚠️ 只能缩小不能放大（放大要挪数据、改后续所有 sh_offset，
    #    会破坏已有段地址）。所以调用方给的 capacity 必须 >= 真段 × 1.04。
    real_head = elf.find(HEAD_NAME)
    real_code = elf.find(SECTION_NAME)
    real_ro = elf.find(HEAD_RO_NAME)
    if real_head is None or real_code is None or real_ro is None:
        print('❌ 找不到真段（%s/%s/%s），无法对齐诱饵尺寸'
              % (HEAD_NAME, SECTION_NAME, HEAD_RO_NAME), file=sys.stderr)
        return 1
    real_head_sz = real_head['size']
    real_code_sz = real_code['size']
    real_ro_sz = real_ro['size']

    def _jitter(base, idx, salt):
        """在 base 的 ±4% 内取一个确定但看起来随机的值。

        用构建期随机而非纯 idx 推导：同一份源码多次构建得到不同的
        尺寸组合，攻击者无法用"上次构建的规律"套这次。
        下限 clamp 到 32 字节（不能让段小到不可能是真段）。
        """
        span = max(1, base // 25)              # ≈4%
        lo = max(32, base - span)
        hi = max(lo + 1, base + span)
        return lo + salt % (hi - lo)

    for head, slot, ro, code, idx in found:
        # 每组独立随机（组间不共享，避免"三胞胎"）
        salt_h = int.from_bytes(os.urandom(2), 'little')
        salt_c = int.from_bytes(os.urandom(2), 'little')
        t_head = _jitter(real_head_sz, idx, salt_h)
        t_code = _jitter(real_code_sz, idx, salt_c)
        # master 段：不浮动，保持 32B。
        #
        # ⚠️ 这里有一个必须如实记录的取舍（2026-11-27 两次试错）：
        #
        #   试过浮动到 32~48B（+0~16），结果 V18a 报
        #   「.ncxhr 诱饵 47B 偏离真段 32B 超过 10%」——
        #   32B 的 ±10% 只有 3 字节空间，任何有意义的浮动都会超出，
        #   反而制造出「诱饵明显比真段大」这个新破绽。**比不浮动更糟。**
        #
        #   ⚠️ 根本限制：段只能缩小不能放大（放大要挪后续所有
        #   sh_offset），而 32B 已是最小可用值，没有缩小空间。
        #
        # 为什么接受「三份相等」这个痕迹：
        #   ① master 段只有 32 字节，攻击者不会用它做判据 ——
        #      真正能区分的是 11KB 的 .ncx 和 4KB 的 .ncxh
        #   ② 32B 的段在任何 so 里都常见（对齐填充、小常量），
        #      "三个 32B 段"本身不引人注目
        #   ③ 强行浮动引入的破绽（大小超出 ±10%）比它更明显
        #
        # 代价如实说：攻击者若真去比 .ncxhr 大小，仍能看出三份一致。
        # 但这条线索的定位能力远弱于 .ncx/.ncxh 的大小 —— 那两段已经修好。
        t_ro = real_ro_sz
        if not _resize_section(elf, head, t_head):
            print('❌ 诱饵 %s 无法裁到 %dB（当前 %dB）—— 需调大 '
                  'nc_guard_decoy.c 的 NCG_BAIT_HEAD_PAD'
                  % (head['name'], t_head, head['size']), file=sys.stderr)
            return 1
        if not _resize_section(elf, code, t_code):
            print('❌ 诱饵 %s 无法裁到 %dB（当前 %dB）—— 需调大 '
                  'NCG_BAIT_CODE_MAX'
                  % (code['name'], t_code, code['size']), file=sys.stderr)
            return 1
        if not _resize_section(elf, ro, t_ro):
            print('❌ 诱饵 %s 无法裁到 %dB' % (ro['name'], t_ro),
                  file=sys.stderr)
            return 1
    print('   诱饵尺寸: 真 head=%dB code=%dB；诱饵在 ±4%% 内浮动（不同值）'
          % (real_head_sz, real_code_sz))

    # ── 段名随机化：消除「无后缀 = 原件」这个白送的答案 ──────────────
    #
    # 用户指出的破绽（2026-11-28）：`.ncx` 无后缀、`.ncx0/.ncx1` 带数字，
    # 任何逆向者 2 秒就知道哪个是真的 —— 段表白送答案。
    #
    # 只改【诱饵】的名字即可：它们不被任何代码引用，叫什么都可以。
    # 真段必须保留 `.ncx`（解锁链 ncg_find_section 按名字查），
    # 但改完后段表变成：
    #     .ncx    ← 真的
    #     .k3f9   ← 诱饵，随机名，与 .ncx 无命名规律
    #     .q7f2   ← 诱饵
    # "没有数字后缀"这条线索彻底消失。
    #
    # ⚠️ 改完必须【重新收集】段引用：found 里的 dict 是 Elf 解析时的对象，
    #    _rename_section_inplace 会同时更新 sec['name']，但后续代码用
    #    head['offset'] / head['size'] 仍然有效（只改了名字）。
    # ⚠️ 失败必须 fail-fast：若某个诱饵改名失败而其他成功，段表会出现
    #    "一半随机一半带数字"的形态 —— 那比不改更可疑。
    if n_groups > 0:
        taken = set(s['name'] for s in elf.sections)
        for head, slot, ro, code, idx in found:
            for secobj in (head, slot, ro, code):
                old_nm = secobj['name']
                base_nm = old_nm.rstrip('0123456789')
                want_len = len(_REAL_NAME_FOR_LEN.get(base_nm, base_nm))
                new_nm = _random_section_name(elf, len(old_nm), taken,
                                              want_len)
                if not new_nm or not _rename_section_inplace(elf, secobj, new_nm):
                    print('❌ 诱饵段 %s 改名失败 —— 拒绝产出半随机的段表'
                          % old_nm, file=sys.stderr)
                    return 1
                taken.discard(old_nm)
                taken.add(new_nm)
        print('   诱饵段名已随机化（真段保留 %s，诱饵无命名规律）'
              % SECTION_NAME)

    for gi, (head, slot, ro, code, idx) in enumerate(found):
        # 每组独立的随机密钥材料——组间绝不能复用（复用 = two-time pad）
        k_stub_g = os.urandom(16)
        k_mac_g = os.urandom(16)
        master_g = os.urandom(32)
        # 每组的 XOR_KEY 也独立，避免靠"碎片相同"识别真段
        xkey_g = os.urandom(8)

        # 诱饵 head 明文：必须【以真实函数序言开头】的 .text 片段。
        # 详见 _pick_code_region 的注释（实测踩过：随便取一段会落在
        # 字面量池，反汇编出非法指令，诱饵被一眼识破）。
        headlen = head['size']
        plain = _pick_code_region(text_src, headlen, idx)
        assert len(plain) == headlen

        # 代码自绑定：与真路径同构（CRC32(.text) 折进密钥）。
        # ⚠️ 用同一个 .text 的 CRC，因为诱饵槽里的 code_addr 也指向 .text——
        #    这样攻击者算出来的 CRC 与真路径一致，不会因「CRC 对不上」露馅。
        text = elf.find('.text')
        code_crc = zlib.crc32(bytes(text_src)) & 0xFFFFFFFF
        # ⚠️ 这里用诱饵自己的 k_stub，但折叠规则与真路径逐字节相同
        k_stub_eff = bytes(
            k_stub_g[i] ^ ((code_crc >> ((i & 3) * 8)) & 0xFF) for i in range(16)
        )

        # 用与真路径【完全相同】的算法加密诱饵 head
        head_cipher = ctr_xor(k_stub_eff, CTR_DOM_HEAD, plain)
        elf.data[head['offset']:head['offset'] + headlen] = head_cipher
        # ── 诱饵业务代码段（.ncxN）──────────────────────────────────
        #
        # 为什么必须有它：若只有 .ncx 一份、诱饵 head 有 N 份，攻击者
        # 发现「解 .ncx 的段只有一组」就能直接锁定真链，诱饵全部白做。
        # 加了诱饵 .ncx 后，段表里出现 N+1 组完整的 (.ncx,.ncxh,.ncks,.ncxhr)
        # 四元组，他必须逐组跑完全链才能排除。
        #
        # 加密方式必须与真 .ncx 【逐字节同构】：
        #   k_so = HKDF(master_g, SHA256(certDER), "nc-so-v1" + pkg)
        #   cipher = RC4(k_so, plain)
        # 攻击者按同一规则解，会得到合法 ARM64 代码（因为明文是从 .text
        # 抄的真实函数），从而确信这组是真的 —— 直到他去执行它。
        #
        # ⚠️ 明文不能用 _pick_code_region 的同一段（否则各组 .ncx 明文相同，
        #    攻击者一比就知道是复制的）。用不同 seed 错开。
        code_len = code['size']
        code_plain = _pick_code_region(text_src, code_len, idx + max(1, n_groups))
        assert len(code_plain) == code_len
        # 与真路径同规则派生 k_so（cert 与 pkg 在诱饵这里无关紧要 ——
        # 攻击者会用真证书算，若我们不用真证书，他解得乱码就会排除。
        # 所以这里必须用【真证书 + 真包名】派生，才能让他解得通。）
        k_so_g = derive_app_keys(master_g, cert, package)['so']
        code_cipher = rc4(k_so_g, code_plain)
        elf.data[code['offset']:code['offset'] + code_len] = code_cipher
        # 诱饵 master 用同样方式锁（dom 相同——攻击者按同样规则解）
        ro_cipher = ctr_xor(k_stub_eff, CTR_DOM_HEADRO, master_g)
        elf.data[ro['offset']:ro['offset'] + 32] = ro_cipher

        # ── 关键：expect_mac_head 用【诱饵自己的】k_mac_head 正确计算 ──
        # 这一行决定了诱饵值不值得做。若这里填 0 或随机值，
        # 攻击者的 HMAC 校验必然失败 → 立刻排除这组 → 诱饵无效。
        expect_mac_g = hmac_sha256(k_mac_g, head_cipher)
        wrapped_g = bytes(b ^ xkey_g[i % len(xkey_g)]
                          for i, b in enumerate(k_stub_g))
        wrapped_mac_g = bytes(b ^ xkey_g[i % len(xkey_g)]
                              for i, b in enumerate(k_mac_g))

        # ── 诱饵碎片区：必须按 C 侧 FRAG_TABLE 规则反推生成 ──────────
        #
        # ⚠️⚠️ 这是最容易写错、且错了诱饵就完全失效的一处。
        #
        # 攻击者解诱饵槽的流程与解真槽【完全一样】：
        #   frag[104:112) → 按 NC_XOR_FRAG 查表重组成 XOR_KEY
        #   → k_stub = wrapped ^ XOR_KEY → 解 head
        #
        # 所以诱饵碎片必须满足：按同一张表重组后 == xkey_g。
        # 若直接写 xkey_g 的原始字节，重组结果会是别的值 → k_stub 错
        # → head 解出乱码 → 攻击者 5 秒排除这组 → 诱饵白做。
        #
        # 生成规则与真路径逐字节相同（见 lock_head 里 frag_slots 那段）：
        #   逻辑字节 i 的真实值放在 frag[FRAG_TABLE[i]] 的低 8 位（i<4）
        #   或高 8 位（i>=4）
        import struct as _s
        frag_table = _LAYOUT.get('NC_XOR_FRAG_INIT')
        if not frag_table or len(frag_table) != 8:
            print('❌ NC_XOR_FRAG_INIT 缺失，无法生成自洽的诱饵碎片',
                  file=sys.stderr)
            return 1
        frag_slots = [None, None, None, None]
        for logical, slot_idx in enumerate(frag_table):
            target = xkey_g[logical]
            placed = frag_slots[slot_idx]
            if logical < 4:
                hi = (placed >> 8) if placed is not None else os.urandom(1)[0]
                frag_slots[slot_idx] = (hi << 8) | target
            else:
                lo = (placed & 0xFF) if placed is not None else os.urandom(1)[0]
                frag_slots[slot_idx] = (target << 8) | lo
        frag_bytes = b''.join(
            _s.pack('<H', v if v is not None else int.from_bytes(os.urandom(2), 'little'))
            for v in frag_slots)
        # 自检：按攻击者会用的规则重组，必须 == xkey_g。
        # 这条断言是诱饵有效性的最后一道保险——它失败说明诱饵会在
        # 解 head 阶段就露馅（而不是在解 .ncx 阶段），价值归零。
        _chk = bytearray(8)
        for logical, slot_idx in enumerate(frag_table):
            v = _s.unpack('<H', frag_bytes[slot_idx * 2: slot_idx * 2 + 2])[0]
            _chk[logical] = (v & 0xFF) if logical < 4 else ((v >> 8) & 0xFF)
        if bytes(_chk) != xkey_g:
            print('❌ 诱饵碎片自检失败：按 FRAG_TABLE 重组 != 预期 XOR_KEY',
                  file=sys.stderr)
            return 1

        # 诱饵槽：与真 .ncks 逐字段同构
        import struct as _s2
        blob = (STUB_MAGIC_SEED
                + wrapped_g
                + _s2.pack('<I', slot['addr'])     # stub_sh_addr（指向自己）
                + _s2.pack('<I', head['addr'])
                + _s2.pack('<I', headlen)
                + _s2.pack('<I', text['addr'])     # code_addr：指向真 .text
                + _s2.pack('<I', text['size'])     # code_len
                + _s2.pack('<I', 0)
                + wrapped_mac_g
                + expect_mac_g
                + _s2.pack('<I', ro['addr'])
                + _s2.pack('<I', 32)
                + frag_bytes)                      # 碎片区 8 字节（NC_OFF_FRAGS）
        if len(blob) != _LAYOUT['NC_STUB_SIZE']:
            print('❌ 诱饵槽长度 %d != %d'
                  % (len(blob), _LAYOUT['NC_STUB_SIZE']), file=sys.stderr)
            return 1

        # ⚠️⚠️ 诱饵槽也必须过 T4（boot_key RC4），与真 .ncks 一模一样。
        #
        # 这一处是诱饵有效性的第二个坑（第一个是碎片重构规则）：
        # 攻击者解【任何】槽的第一步都是
        #     slot_plain = magic + rc4(boot_key, slot[8:])
        # 因为真槽就是这么加密的（_encrypt_slots）。
        # 若诱饵槽写明文，攻击者对诱饵也做一次 rc4 → 拿到乱码碎片
        # → XOR_KEY 错 → k_stub 错 → head 乱码 → 第一步就排除诱饵。
        #
        # 所以诱饵必须复现「锁箱期加密」这一步，让攻击者的解密【成功】。
        boot_key_g = _derive_boot_key(elf)
        enc = rc4(boot_key_g, bytes(blob[_LAYOUT['NC_OFF_FRAGS_ENC']:]))
        blob_final = blob[:_LAYOUT['NC_OFF_FRAGS_ENC']] + enc
        elf.data[slot['offset']:slot['offset'] + len(blob_final)] = blob_final
        # 每组独立报告（排障需要知道哪一组填了、多大）
        print('   诱饵组 %d: %s/%s/%s 已填入（head=%dB，MAC 自洽）'
              % (idx, head['name'], slot['name'], ro['name'], headlen))

    with open(out_path, 'wb') as f:
        f.write(bytes(elf.data))
    print('✅ 诱饵: %d 组已生成 → %s' % (len(found), out_path))
    print('   攻击者需逐组跑完整派生链才能排除，单组成本 ≈ 真链')
    return 0


def _text_bytes_of(elf: 'Elf') -> bytes:
    """取 .text 内容（供诱饵构造可信明文）。缺段返回空。"""
    t = elf.find('.text')
    if t is None or t['size'] == 0:
        return b''
    return bytes(elf.data[t['offset']:t['offset'] + t['size']])


# ── 诱饵明文取样：必须落在【真正的函数入口】──────────────────────────
#
# ⚠️⚠️ 这是诱饵有效性的第三个坑，也是最隐蔽的一个。
#
# 攻击者判断「解出来是不是代码」的标准动作是反汇编前几条指令。
# 若诱饵从 .text 中段随便取一段，很可能取到字面量池 / 跳转表 /
# 长指令中间 —— 反汇编出来是 `0x0b0d016b` 这类非法指令，
# 他立刻知道「这组是假的」，诱饵白做。
#
# 实测踩过（2026-11-27）：诱饵0 取 .text[5728:] 落在字面量池，
# 解出来前 16 字节 `6b010d0b 6b010c0b 4b4100b9 efffff17` —— 0/4 合法。
#
# 修法：只在【函数序言签名】处取样。ARM64 两种标准序言：
#   stp x29, x30, [sp, #-N]!   编码 0xA9..7BFD（低 16 位 = 0x7BFD）
#   sub sp, sp, #N             编码 0xD10.....
# 这类字节序列在 .text 里有很多（每个非叶函数都有），取之即得合法代码。

_ARM64_PROLOGUE_STP = 0xA9   # stp 家族高字节
_ARM64_PROLOGUE_SUBSP = 0xD1  # sub (immediate) 高字节


def _is_prologue_at(text: bytes, off: int) -> bool:
    """判断 text[off:off+4] 是否是 ARM64 函数序言的第一条指令。"""
    if off + 4 > len(text):
        return False
    import struct as _s
    w = _s.unpack_from('<I', text, off)[0]
    # stp x29, x30, [sp, #-N]!  →  1010 1001 1xxx xxxx 0111 1011 1111 1101
    if (w & 0xFFC07FFF) == 0xA9807BFD:
        return True
    # sub sp, sp, #imm  →  1101 0001 00xx xxxx xxxx xxxx xxx1 1111
    if (w & 0xFF8003FF) == 0xD10003FF:
        return True
    return False


def _pick_code_region(text: bytes, want: int, seed: int) -> bytes:
    """从 .text 里挑一段【由真实函数体拼成】的 want 字节。

    ⚠️⚠️ 这里踩过一个真实的坑（2026-11-27，云端产物暴露）：

    早先的实现是「找到任一函数序言，从那里往后取 want 字节」。本地
    example 的真 .ncx 只有 184B，取出来的确实全是代码，一切正常。
    但云端真实包的 .ncx 有 11344B —— 从某个序言往后取 11KB 必然
    跨出函数体、越过字面量池和跳转表，解出来后攻击者一反汇编就看到
    大段非法指令 → 立刻识别为诱饵。

    实测：诱饵 .ncx 明文前 16 字节 = 5a92292a...（非法），
    而真段 = ff0301d1 = sub sp,sp,#0x40（合法）。
    这种段只要存在一组，诱饵的全部价值就归零。

    现在的做法：**按函数体拼接** —— 从 seed 指定的序言开始，逐个函数
    追加，直到凑够 want 字节。每个片段都从序言开始，拼起来仍是一串
    合法指令（虽然控制流是拼接的，但静态反汇编看到的全是真代码）。
    这样不论 want 多大都不会跨进数据区。

    返回长度恒为 want。找不到足够候选时退化为整段 .text 循环填充
    （此时调用方应视为降级，但至少不是随机字节）。
    """
    if want <= 0:
        return b''

    cands = [o for o in range(0, max(1, len(text) - 16), 4)
             if _is_prologue_at(text, o)]
    if not cands:
        # 没有任何序言签名（异常情况）：整段循环填充，至少是真实指令字节
        if len(text) >= want:
            return text[:want]
        return (text * (want // max(1, len(text)) + 1))[:want]

    # 每个函数体的长度 = 到下一个序言的距离（最后一个到 .text 末尾）。
    # 这样切片天然落在函数边界内，不会跨进字面量池。
    bounds = cands + [len(text)]
    out = bytearray()
    n = len(cands)
    # 从 seed 指定的位置开始，循环往后取，直到凑够 want
    idx = seed % n
    guard = 0
    while len(out) < want and guard <= n * 2:
        start = cands[idx % n]
        end = bounds[(idx % n) + 1]
        seg = text[start:end]
        if seg:
            out += seg
        idx += 1
        guard += 1
    if not out:
        return text[:want] if len(text) >= want else (text * (want // max(1, len(text)) + 1))[:want]
    # 循环填充到 want（若函数总量不足）；循环点是 32B 对齐的函数边界，
    # 所以重复拼接仍是合法指令序列
    reps = want // len(out) + 1
    return bytes(out * reps)[:want]


def _detect_bait_groups(elf: 'Elf') -> int:
    """数产物里实际存在几组诱饵段（.ncxhN/.ncksN/.ncxhrN 三个都在才算一组）。

    ⚠️ 不能靠 NCG_BAIT_N 宏取数：宏在 C 编译单元里，Python 侧看不到，
    而且产物可能是用旧版 nc_guard_decoy.c 编的（组数不同）。
    以【产物段表为准】才与"实际要填几组"一致。

    只有三件套齐全才计入：缺一组的产物无法构成"平行同构"的干扰，
    强行填反而会在段表上留下不对称痕迹。
    """
    n = 0
    while True:
        if (elf.find('.ncxh%d' % n) is not None
                and elf.find('.ncks%d' % n) is not None
                and elf.find('.ncxhr%d' % n) is not None):
            n += 1
        else:
            break
    return n


# ── 元数据清理：删 .eh_frame / 源码路径（2026-11-02）──────────────────
# 对齐 Epic report §4.3/§4.6 与本次实测审计的 6 个泄露项里最难修的两项。
#
# 为什么需要独立一阶段（不在 lock/lock_head 里做）：
#   ① 必须在【所有锁箱之后】：objcopy 会重写 ELF，若在锁箱前跑，
#      slot 里已写好的链接期 sh_addr 会失配 → 运行期基址计算崩。
#   ② 实测确认 objcopy --remove-section 对本产物【不改变任何 sh_addr /
#      sh_offset】（双 ABI 各 7/7 段逐一比对），所以放在最后是安全的。
#
# 删什么、为什么：
#   .eh_frame / .eh_frame_hdr
#       709 个 FDE，每条给出一个函数的精确起止地址。加密了 6 个段，
#       但异常表把这些函数的位置、大小、个数全列出来了 —— 等于把
#       「.ncx 里有 15 个函数、.ncxh 里有 8 个函数、每个多大」直接公布。
#       代价：失去 C++ 异常栈回溯（崩溃时 backtrace 会残缺）。
#       nc_guard/sig_check 全是 C，不用 C++ 异常；dex2c 产物用
#       EX_LandingPad 但那是显式 goto 分发，不依赖 .eh_frame。
#   .comment
#       工具链指纹（clang 18.0.4 + LLVM commit + PGO/BOLT/LTO 配置）。
#       artifact-pipeline 的 protect.sh 也在删，但那里 CI 环境可能没有
#       objcopy（实测 GH Actions 上从未成功过）；在锁箱器里删是最后一道。
#   .debug_*
#       libc++ 的源码路径（out/llvm-project/libcxxabi/src/...）。
#       --strip-all 删不掉它们（那属于 .debug_line），必须显式 remove。
def strip_meta(so_path: str, out_path: str) -> int:
    """删 .eh_frame / .eh_frame_hdr / .comment / .debug_*。

    用 llvm-objcopy（NDK 自带优先，其次系统）。找不到工具即 fail-fast——
    静默跳过会让「以为清理了其实没清」重演（这正是 .comment 那一项
    在 CI 上失效三个月的原因）。
    """
    import shutil
    import subprocess

    cands = []
    ndk = os.environ.get('ANDROID_NDK_HOME', '')
    if ndk:
        for host in ('linux-x86_64', 'linux-aarch64', 'darwin-x86_64'):
            cands.append(os.path.join(ndk, 'toolchains', 'llvm', 'prebuilt',
                                      host, 'bin', 'llvm-objcopy'))
    for nm in ('llvm-objcopy', 'objcopy'):
        p = shutil.which(nm)
        if p:
            cands.append(p)

    tool = next((c for c in cands if os.path.isfile(c) and os.access(c, os.X_OK)), None)
    if tool is None:
        print('❌ 找不到 llvm-objcopy / objcopy —— 无法清理元数据。', file=sys.stderr)
        print('   （静默跳过会让产物继续泄露工具链指纹与函数边界，故 fail-fast）',
              file=sys.stderr)
        return 1

    # 逐个删，某一段不存在时 objcopy 会报错但其它段仍会删；用 --remove-section
    # 多次传入，缺失的段由 objcopy 忽略（llvm-objcopy 对不存在的段静默跳过）。
    sections = ['.eh_frame', '.eh_frame_hdr', '.comment',
                '.debug_line', '.debug_info', '.debug_abbrev',
                '.debug_str', '.debug_aranges', '.debug_ranges']

    # 先查实际存在哪些，只删存在的（避免某些 objcopy 版本对缺失段报错）
    elf = Elf(open(so_path, 'rb').read())
    present = [s for s in sections if elf.find(s) is not None]
    if not present:
        print('   元数据清理: 无可删段（已干净）')
        # ⚠️ 不能无条件 copyfile：protect.sh 是 in-place 调用（in==out），
        #    同文件拷贝会抛 SameFileError（v7a 那轮就是这么失败的）。
        if os.path.abspath(so_path) != os.path.abspath(out_path):
            shutil.copyfile(so_path, out_path)
        return 0

    # in-place 时必须先写临时文件再替换：objcopy 不允许 in==out，
    # 且直接覆盖会破坏正在读的输入。
    inplace = os.path.abspath(so_path) == os.path.abspath(out_path)
    if inplace:
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix='.so', dir=os.path.dirname(out_path) or '.')
        os.close(fd)
    else:
        tmp = out_path

    cmd = [tool]
    for s in present:
        cmd += ['--remove-section', s]
    cmd += [so_path, tmp]
    r = subprocess.run(cmd, capture_output=True)
    if r.returncode != 0:
        print('❌ 元数据清理失败（%s 退出码 %d）：%s'
              % (os.path.basename(tool), r.returncode,
                 r.stderr.decode('utf-8', 'replace').strip()[:200]), file=sys.stderr)
        if inplace and os.path.exists(tmp):
            os.unlink(tmp)
        return 1
    if inplace:
        os.replace(tmp, out_path)

    # 校验：删掉的段必须真的不在输出里，且关键段地址未变（锁箱契约）
    after = Elf(open(out_path, 'rb').read())
    still = [s for s in present if after.find(s) is not None]
    if still:
        print('❌ 清理后仍存在: %s（objcopy 行为异常）' % ', '.join(still), file=sys.stderr)
        return 1
    for name in (SECTION_NAME, HEAD_NAME, SLOT_NAME, STUB_SLOT, HEAD_RO_NAME):
        b, a = elf.find(name), after.find(name)
        if b and a and (b['addr'] != a['addr'] or b['offset'] != a['offset']):
            print('❌ 段 %s 地址被 objcopy 改动（锁箱契约破坏）: '
                  'addr 0x%x→0x%x' % (name, b['addr'], a['addr']), file=sys.stderr)
            return 1

    print('   元数据清理: 已删 %s（%s）'
          % (', '.join(present), os.path.basename(tool)))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description='把 so 的代码段加密锁死（构建期锁箱）')
    ap.add_argument('input', help='输入 .so')
    ap.add_argument('output', help='输出 .so')
    ap.add_argument('--section', default=SECTION_NAME,
                    help='要锁的段名（默认 %s）' % SECTION_NAME)
    ap.add_argument('--cert-hex', default='',
                    help='证书 SHA-256（hex，32 字节）。与 --from-apk 二选一')
    ap.add_argument('--from-apk', default='',
                    help='从 APK 自动提取第一签名者证书 SHA-256（与 --cert-hex 等价，'
                         '但免去手工提证书；v3 优先回退 v2）')
    ap.add_argument('--cert-only', action='store_true',
                    help='只打印 APK 证书 SHA-256 后退出（供流水线校验/搬运）')
    ap.add_argument('--package', default='', help='包名（HKDF info 的一部分）')
    ap.add_argument('--force', action='store_true', help='允许对已锁文件二次加密（调试用）')
    ap.add_argument('--dry-run', action='store_true', help='只演示不写文件')
    ap.add_argument('--lock-head', action='store_true',
                    help='二级锁箱：把 unlock 本体也锁进 %s（自解谜，需先跑过一级锁箱）'
                         % HEAD_NAME)
    ap.add_argument('--strsec', action='store_true',
                    help='加密 %s 段（字符串段）：只加密显式标记的字符串，'
                         '不碰 .rodata。需配合 --master-hex 与 --from-apk/'
                         '--cert-hex。必须在 --section 之后跑。'
                         % NC_SEC_STR)
    ap.add_argument('--master-hex', default='',
                    help='32 字节 master（hex）。--strsec 需要它与 lock() 一致')
    ap.add_argument('--strip-meta', action='store_true',
                    help='元数据清理：删 .eh_frame（709 个函数边界）/ .comment'
                         '（工具链指纹）/ .debug_*（源码路径）。'
                         '⚠️ 必须在 --lock-head 之后跑（objcopy 会重写 ELF）')
    args = ap.parse_args(argv)

    # 证书与包名来源：
    #   --from-apk  自动提 cert（定点读 Signing Block）+ package（AXML 解析）
    #   --cert-hex  手工给 cert；package 仍可缺省（HKDF info 只有 label 前缀，
    #               换 key 重打包依然解不开——cert 才是关键 salt）
    #   都无 → cert 全零 → lock() fail-fast（全零 salt = 公开脚本可解，等于没锁）
    package = args.package
    if args.from_apk:
        cert = apk_first_signer_cert_sha256(args.from_apk)
        if args.cert_only:
            print(cert.hex())
            return 0
        if not package:
            # 自动补包名（原来指望 apktool.yml 的 package 字段——那字段不存在，
            # 2026-10-17 CI 因此 fail-fast；改为从 AXML 直接解析）
            package = manifest_package(args.from_apk)
    elif args.cert_hex:
        cert = bytes.fromhex(args.cert_hex)
    else:
        cert = b'\x00' * 32

    try:
        if args.strsec:
            if not args.master_hex:
                print('❌ --strsec 需要 --master-hex（与 lock() 用的同一个）',
                      file=sys.stderr)
                return 1
            if len(cert) != 32 or not any(cert):
                print('❌ --strsec 需要真证书（--from-apk 或 --cert-hex）',
                      file=sys.stderr)
                return 1
            return strsec(args.input, args.output, args.master_hex,
                          cert.hex(), package or '')
        if args.strip_meta:
            return strip_meta(args.input, args.output)
        if args.lock_head:
            return lock_head(args.input, args.output, args.force,
                             cert, package)
        return lock(args.input, args.output, args.section, cert,
                    package, args.force, args.dry_run)
    except ElfError as e:
        print('❌ ELF 错误: %s' % e, file=sys.stderr)
        return 1
    except OSError as e:
        print('❌ 文件错误: %s' % e, file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
