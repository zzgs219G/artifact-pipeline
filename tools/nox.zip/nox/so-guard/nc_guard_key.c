/* nc_guard_key.c — .ncx 密钥派生（证书绑定）
 *
 * 照抄 XopProtector 的 key ladder（crypto/key_ladder.cpp + crypto/sha256.cpp
 * 的 hkdf_sha256 + crypto/apk_sign.cpp 的定点读证书），剥离其对
 * protector::sys_* / std::vector 的依赖，只保留四件事：
 *   1. sha256（自带精简实现，避免依赖 sig_check.c/sig_guard2.c 的 static 版）
 *   2. hmac_sha256
 *   3. hkdf_sha256（RFC 5869）
 *   4. apk 第一签名者证书 DER 的定点读（只读 EOCD/CD/Signing Block，几十 KB）
 *
 * 为什么做证书绑定（威胁模型）：
 *   原实现 K_so 由 --cert-hex 传入或落默认值，而 so-section-lock.py 就在仓库里、
 *   派生逻辑公开 → 攻击者自己跑一遍脚本就能解出密钥，4012 字节密文秒变明文。
 *   证书绑定后 K_so = HKDF(master, SHA256(certDER), pkg)：换 key 重打包 →
 *   cert 变 → K_so 变 → 密文解不开。这是 Xop 的原设计，我们照抄。
 *
 * 2026-10-20 更正一处过期表述：早期注释写本文件"没有调用方，是 HKDF 契约的
 * 可执行证明"。那是 P1-a 之前的口径。现行链路（P1-a，运行期证书派生）：
 *   nc_guard_boot.c:533  ncg_derive_k_so_from_der()  ─┐
 *   nc_guard_boot.c:591  ncg_derive_k_mac_from_der()  ─┼─→ 本文件的
 *   nc_guard_boot.c:368  ksha256()                    ─┘   ncg_derive_k_so /
 *                                                     ncg_derive_k_mac / khkdf
 * 三者都真实参与解锁，不是契约证明。
 *
 * 与 so-section-lock.py 的契约（两侧必须逐字节一致）：
 *   label = "nc-so-v1" + package          （Xop 用 "xop-so-v1"+package）
 *   salt  = SHA256(certDER)
 *   ikm   = master（32 字节，构建期与运行期同源）
 *   out   = 16 字节
 */
#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>   /* 2026-10-21:malloc/free（cert 读取缓冲由 static 改堆分配） */
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <elf.h>

#include "nc_guard_key.h"
/* 2026-11-08：label 基值从 NC_BOOT_SALT_INIT 派生（见 ncg_label_key）。
 * ⚠️ 只引 layout.h（零 include 零逻辑的契约文件），不引 internal.h ——
 *    本文件被 test-so-lock.sh 的 T32 对拍驱动【单独链接】，
 *    多引一个头就等于多一份跨 TU 依赖，而 internal.h 里的 ncg_wipe
 *    定义在 nc_guard_boot.c（T32 不链它）。本文件已改为就地 volatile 清零，
 *    不再需要任何外部函数。 */
#include "nc_guard_layout.h"

/* ── HKDF 域 label 的密文存储（2026-11-06，P0）────────────────────
 *
 * 问题：label 是 HKDF 的 info 参数，运行期必须参与运算，所以它必然
 *   在二进制里。实测 v0.9.5 产物：
 *       strings libnc.so | grep nc-boot-v1   → 命中（.rodata 0xcd96）
 *       r2: axt 0xcd96                        → 0x389bc（VM wrapper 旁边）
 *   攻击者 5 秒就能定位到"这里是 boot_key 派生"，VMP 保护了函数体却
 *   没保护这个路标。这就是 AGENTS §3.4「加密了内容 ≠ 隐藏了结构」。
 *
 * 为什么不能"拆成两段运行期拼"（曾以为可行，实测无效）：
 *   LLVM 会把相邻的字符串字面量合并成一个常量：
 *       "\x." "nc-bo" "ot-v1"  →  .rodata.str1.1 里出现
 *       nc-boot-v1.nc-bo.ot-v1
 *   三段挨在一起，strings 照样扫得到全文，收益为零。
 *   （这正是 nc_guard_boot.c 记的"LLVM 做函数间常量传播"同源问题。）
 *
 * 现方案：整数表存储，运行期逐字节 XOR 还原。
 *   · 每字节 ^ 0x5A 存成 uint8_t，编译期不会有任何字符串字面量
 *   · 与本设施既有做法一致（ncg_apk_path_fault 的规则表也是 XOR 0x5A）
 *   · 派生结果【逐字节不变】→ 历史产物兼容性零影响（已实测对拍）
 *
 * ⚠️ 这是【混淆】不是【加密】：0x5A 就在源码里，愿意读的人能还原。
 *    它买的是"strings/grep 自动扫描失效 + xref 断链"，不是抗人工逆向。
 *    与 layout.h 里 magic seed 的诚实口径一致，别高估。
 *
 * ⚠️ 改这三张表必须同步 so-section-lock.py 的 derive_app_keys()：
 *    Python 侧用明文 label 算（构建期，不进产物），两侧结果必须逐字节一致。
 *    对拍方法见下方 ncg_label_so 的注释。 */

/* 各 label 的明文长度（不含 NUL） */
#define NCGL_SO       8    /* "nc-so-v1" */
#define NCGL_MAC     12    /* "nc-so-mac-v1" */
#define NCGL_SO_R    10    /* "nc-so-r-v1" */
#define NCGL_BOOT    10    /* "nc-boot-v1" */
/* 2026-11-13：第五张表，给 .nct（消费方 VMP 数据段）用。
 * ⚠️ 长度必须等于 strlen("nc-insn-v1") = 10。曾写成 11 —— C 侧多读一个
 *    字节（读到噪声位）→ 还原出 "nc-insn-v1\x??" → HKDF info 错 →
 *    k_nct 错 → 解出乱码 → 真机 SIGILL。已加 _Static_assert 钉死。 */
#define NCGL_INSN    10    /* "nc-insn-v1" */
/* 2026-11-13：第六张表，.ncq（VM 字节码段）用。
 * label 明文 "nc-warm-v1"，与 so-section-lock.py 的 derive_app_keys
 * 里 ('nc-warm-v1','warm') 逐字节一致。
 * 为什么不复用 k_nct：RC4 是流密码，两段共用同一 keystream =
 * two-time-pad 误用（本项目 2026-10-28 踩过 .ncx/.ncxr 同款坑）。 */
#define NCGL_BC      10    /* "nc-warm-v1" */
/* 2026-11-13：第七张表，.ncv（消费方第二套 VM 字节码段）用。
 * label 明文 "nc-dex-v1"，与 derive_app_keys 的 ('nc-dex-v1','dex') 一致。
 * ⚠️ 必须与 .ncq 的 k_bc 不同：两套链接进同一个 so，同钥匙 = keystream 复用。 */
#define NCGL_BC2      9    /* "nc-dex-v1" */
/* 运行时把 label 明文长度与实际字符串对拍（编译期即失败）。 */
_Static_assert(sizeof("nc-insn-v1") - 1 == NCGL_INSN,
               "NCGL_INSN 与 label 明文长度不一致 —— C 侧会多读/少读噪声位");
_Static_assert(sizeof("nc-so-v1") - 1 == NCGL_SO, "NCGL_SO 长度不符");
_Static_assert(sizeof("nc-so-mac-v1") - 1 == NCGL_MAC, "NCGL_MAC 长度不符");
_Static_assert(sizeof("nc-so-r-v1") - 1 == NCGL_SO_R, "NCGL_SO_R 长度不符");
_Static_assert(sizeof("nc-boot-v1") - 1 == NCGL_BOOT, "NCGL_BOOT 长度不符");
_Static_assert(sizeof("nc-warm-v1") - 1 == NCGL_BC, "NCGL_BC 长度不符");
_Static_assert(sizeof("nc-dex-v1") - 1 == NCGL_BC2, "NCGL_BC2 长度不符");

/* ── 2026-11-08：四张表各自独立基值（不再统一 0x5A）────────────────
 *
 * 修的是什么（实测发现，见 docs/so层防御/简盒样本验证报告-2026-11-08.md）：
 *   原方案四张表全部 ^0x5A，且【在 .rodata 里连排】：
 *       0x349e0: 34 39 77 29 35 77 2c 6b   → nc-so-v1
 *       0x349e8: 34 39 77 29 35 77 37 3b   → nc-so-mac-v1
 *       0x349f4: 34 39 77 29 35 77 28 77   → nc-so-r-v1
 *       0x349fe: 34 39 77 38 35 35 2e 77   → nc-boot-v1
 *   攻击者只需：搜 `34 39 77`（"nc"^0x5A）→ 找到连排四表 → 试 XOR 0x5A。
 *   【完全不需要碰 VMP】。而 VMP 保护的 13 个函数全部以 label 为输入，
 *   等于 VMP 的输入参数是公开的。
 *
 * 本改动的三个层次：
 *   ① 每张表用【不同】基值 → 四张表不再是同一模式的序列，`34 39 77`
 *      这个签名消失（so 表保留 0x5A 只是因为它恰好是基准，无特殊性）
 *   ② 基值不连续、无规律（0x5A / 0xA7 / 0x3C / 0xE1）
 *   ③ 基值本身也不裸放：从 NC_BOOT_SALT_INIT 派生（见 ncg_label_key）
 *      —— 那个常量已经在产物里（boot_key 派生要用），复用它不新增泄露面
 *
 * ⚠️ 强度边界（如实，勿高估）：
 *   这是【混淆】不是【加密】。基值可由 SALT 静态算出，攻击者愿意反汇编
 *   ncg_label_key 就能还原。它买到的是"自动扫描失效 + 四表不再互相印证"，
 *   不是抗人工逆向。与 layout.h 里 magic seed 的诚实口径一致。
 *
 * ⚠️ 派生结果【逐字节不变】：label 明文本身一个字节没改，只是换了存储编码。
 *   所以历史产物兼容性零影响（test.sh V10 验这一点）。
 *
 * 生成方式（改表前用它校验）：
 *     printf '%s' "nc-so-v1" | od -An -tx1 | tr -d ' \n'   → 6e632d736f2d7631
 *     再逐字节 ^ 对应基值（见下方每张表的注释）
 */
/* 存储格式（2026-11-08 二次加固）：每张表 = 2n 字节，偶数位放真实字节、
 * 奇数位放噪声。这样四张表不再是"连续可读的常量块"，而是四段噪声。
 *
 * 为什么必须交错（而不是只换基值）：
 *   实测只换基值后，四张表仍在 .rodata 里【紧邻】排布（间隔 8/12/10 字节，
 *   总跨度 40 字节）。攻击者即使不知道基值，也能看到"40 字节的常量块"，
 *   然后对每个字节试 256 种 XOR —— 四张表一起解出来的概率不低。
 *   交错后真实字节被噪声隔开，单字节试错不再能还原整串。
 *
 * 噪声来源：SALT 的确定性派生（不用 rand，保证构建可复现）。
 *   noise(i, kidx) = SALT[(i*5 + kidx*3) % 16] ^ 0x9E
 * ⚠️ 不同表的噪声序列有重叠片段（都来自同一 SALT 循环），这是已知弱点：
 *    攻击者若识别出噪声规律，可跳读偶数位。但它至少要求"先认出这是交错表"，
 *    比"直接看到一个 40 字节块"高一层门槛。如实记录，勿高估。
 */
/* 噪声说明（表已由构建期脚本生成，运行期不再重算噪声）：
 *   noise(i, kidx) = SALT[(i*5 + kidx*3) % 16] ^ 0x9E
 * 生成方式见 scripts/gen-label-tables.py（可复核、可重新生成）。 */

/* 四张表：偶数位 = label[i] ^ 基值，奇数位 = 噪声
 * 基值见 ncg_label_key()：0x5A / 0xA7 / 0x3C / 0xE1 */
static const uint8_t ncg_label_enc_so[NCGL_SO * 2] = {
    0x34, 0xf0, 0x39, 0xda, 0x77, 0x78, 0x29, 0x5a,
    0x35, 0xe4, 0x77, 0xc2, 0x2c, 0xa7, 0x6b, 0xb5,
};
static const uint8_t ncg_label_enc_mac[NCGL_MAC * 2] = {
    0xc9, 0xb5, 0xc4, 0x9d, 0x8a, 0xec, 0xd4, 0x81,
    0xc8, 0x46, 0x8a, 0x31, 0xca, 0xfd, 0xc6, 0x0f,
    0xc4, 0x86, 0x8a, 0xf0, 0xd1, 0xda, 0x96, 0x78,
};
static const uint8_t ncg_label_enc_so_r[NCGL_SO_R * 2] = {
    0x52, 0x0f, 0x5f, 0x86, 0x11, 0xf0, 0x4f, 0xda,
    0x53, 0x78, 0x11, 0x5a, 0x4e, 0xe4, 0x11, 0xc2,
    0x4a, 0xa7, 0x0d, 0xb5,
};
static const uint8_t ncg_label_enc_boot[NCGL_BOOT * 2] = {
    0x8f, 0xc2, 0x82, 0xa7, 0xcc, 0xb5, 0x83, 0x9d,
    0x8e, 0xec, 0x8e, 0x81, 0x95, 0x46, 0xcc, 0x31,
    0x97, 0xfd, 0xd0, 0x0f,
};
/* 2026-11-13：第五张表（label "nc-insn-v1"），.nct 段密钥用。
 * 由 gen-label-tables.py 生成，勿手改；`--check` 会对拍。 */
/* 2026-11-13：.ncv（消费方第二套字节码）段密钥用，label "nc-dex-v1"。 */
static const uint8_t ncg_label_enc_bc2[NCGL_BC2 * 2] = {
    0xa4, 0x81, 0xa9, 0x46, 0xe7, 0x31, 0xae, 0xfd,
    0xaf, 0x0f, 0xb2, 0x86, 0xe7, 0xf0, 0xbc, 0xda,
    0xfb, 0x78,
};
/* 2026-11-13：.ncq（VM 字节码）段密钥用，label "nc-warm-v1"。 */
static const uint8_t ncg_label_enc_bc[NCGL_BC * 2] = {
    0x7e, 0x5a, 0x73, 0xe4, 0x3d, 0xc2, 0x67, 0xa7,
    0x71, 0xb5, 0x62, 0x9d, 0x7d, 0xec, 0x3d, 0x81,
    0x66, 0x46, 0x21, 0x31,
};
static const uint8_t ncg_label_enc_insn[NCGL_INSN * 2] = {
    0x0a, 0x31, 0x07, 0xfd, 0x49, 0x0f, 0x0d, 0x86,
    0x0a, 0xf0, 0x17, 0xda, 0x0a, 0x78, 0x49, 0x5a,
    0x12, 0xe4, 0x55, 0xc2,
};

/* 把密文表还原进调用方缓冲（不写 NUL —— 调用方按长度用 memcpy 拼包名）。
 * ⚠️ 用 volatile 写：防止编译器把"解码后立刻使用"优化成常量折叠，
 *    那样明文又会回到 .rodata（本文件已踩过同类坑）。
 * ⚠️ 不返回指针：避免指向内部静态区，也让调用方必须自己管缓冲寿命。
 * ⚠️ noinline 不可省：内联后编译器可能把 enc[] 与 key 一起折叠成常量。 */
__attribute__((noinline))
static void ncg_label_decode(const uint8_t *enc, size_t n, uint8_t key,
                             uint8_t *out) {
    /* 跳读：enc[0], enc[2], enc[4], ... 是真实字节；奇数位是噪声 */
    volatile uint8_t *v = (volatile uint8_t *)out;
    for (size_t i = 0; i < n; i++) v[i] = (uint8_t)(enc[i * 2] ^ key);
}

/* 从 SALT 派生五个基值。返回值与上面五张表的 ^ 值逐一对应：
 *   0x5A / 0xA7 / 0x3C / 0xE1 / 0x64
 * ⚠️ 私有扰动量（0x34/0xDD/0x3F/0x4E/0x7B）与 SALT 的对应字节异或后
 *    恰好产出上述五个基值。改 SALT 或改这里任一字节都会导致 label 错
 *    → k_so 错 → .ncx 解出乱码 → 全链崩（fail-closed，不会静默）。 */
__attribute__((noinline))
static void ncg_label_key(uint8_t out[7]) {
    static const uint8_t salt[16] = NC_BOOT_SALT_INIT;
    /* SALT 索引：0 / 4 / 8 / 12 / 2（前四个每 4 字节取一个，避开相邻字节；
     * 第五个取 2 —— 前四个已用掉 0/4/8/12，取中间下标与它们都不同）
     * 私有扰动：0x34 / 0xDD / 0x3F / 0x4E / 0x7B （本文件私有，无外部契约）
     * 逐项校验：
     *   salt[0]=0x6e ^ 0x34 = 0x5A   ✓
     *   salt[4]=0x7a ^ 0xDD = 0xA7   ✓
     *   salt[8]=0x03 ^ 0x3F = 0x3C   ✓
     *   salt[12]=0xaf ^ 0x4E = 0xE1  ✓
     *   salt[2]=0x1f ^ 0x7B = 0x64   ✓（与前四个都不同） */
    volatile uint8_t *v = (volatile uint8_t *)out;
    v[0] = (uint8_t)(salt[0]  ^ 0x34);
    v[1] = (uint8_t)(salt[4]  ^ 0xDD);
    v[2] = (uint8_t)(salt[8]  ^ 0x3F);
    v[3] = (uint8_t)(salt[12] ^ 0x4E);
    v[4] = (uint8_t)(salt[2]  ^ 0x7B);
    v[5] = (uint8_t)(salt[6]  ^ 0x81);
    v[6] = (uint8_t)(salt[10] ^ 0x2C);
}


/* ── SHA-256（FIPS 180-4）───────────────────────────────────────────
 * 照抄 scripts/sigcheck/src/sig_check.c:239-305 的已验证实现
 * （test-sig-guard2.sh 与 test-lsgs-strings.sh 6/6 对拍钉死）。
 * 不自己另写——我自己写的那版 block 压缩有错，NIST 向量全错
 * （"abc" 应 ba7816bf...，实得 554144d9...）。教训：密码学原语
 * 必须复用仓内已验证实现，不重造轮子。 */
#define ROTR(x,n) (((x)>>(n))|((x)<<(32-(n))))
#define CH(x,y,z)  (((x)&(y))^(~(x)&(z)))
#define MAJ(x,y,z) (((x)&(y))^((x)&(z))^((y)&(z)))
#define EP0(x) (ROTR(x,2)^ROTR(x,13)^ROTR(x,22))
#define EP1(x) (ROTR(x,6)^ROTR(x,11)^ROTR(x,25))
#define SIG0(x) (ROTR(x,7)^ROTR(x,18)^((x)>>3))
#define SIG1(x) (ROTR(x,17)^ROTR(x,19)^((x)>>10))

struct ksha_ctx_s {
    uint32_t state[8];
    uint8_t data[64];
    size_t datalen;
    unsigned long long bitlen;
};

static const uint32_t K256[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};

static void k_sha_transform(ksha_ctx *ctx, const uint8_t *data) {
    uint32_t m[64], a, b, c, d, e, f, g, h, t1, t2;
    int i;
    for (i = 0; i < 16; i++)
        m[i] = (uint32_t)data[i*4] << 24 | (uint32_t)data[i*4+1] << 16 |
               (uint32_t)data[i*4+2] << 8 | (uint32_t)data[i*4+3];
    for (; i < 64; i++)
        m[i] = SIG1(m[i-2]) + m[i-7] + SIG0(m[i-15]) + m[i-16];
    a=ctx->state[0]; b=ctx->state[1]; c=ctx->state[2]; d=ctx->state[3];
    e=ctx->state[4]; f=ctx->state[5]; g=ctx->state[6]; h=ctx->state[7];
    for (i = 0; i < 64; i++) {
        t1 = h + EP1(e) + CH(e,f,g) + K256[i] + m[i];
        t2 = EP0(a) + MAJ(a,b,c);
        h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
    }
    ctx->state[0]+=a; ctx->state[1]+=b; ctx->state[2]+=c; ctx->state[3]+=d;
    ctx->state[4]+=e; ctx->state[5]+=f; ctx->state[6]+=g; ctx->state[7]+=h;
}

void ksha_init(ksha_ctx *ctx) {
    ctx->datalen = 0; ctx->bitlen = 0;
    ctx->state[0]=0x6a09e667; ctx->state[1]=0xbb67ae85;
    ctx->state[2]=0x3c6ef372; ctx->state[3]=0xa54ff53a;
    ctx->state[4]=0x510e527f; ctx->state[5]=0x9b05688c;
    ctx->state[6]=0x1f83d9ab; ctx->state[7]=0x5be0cd19;
}

void ksha_update(ksha_ctx *ctx, const uint8_t *data, size_t len) {
    size_t i;
    for (i = 0; i < len; i++) {
        ctx->data[ctx->datalen++] = data[i];
        if (ctx->datalen == 64) {
            k_sha_transform(ctx, ctx->data);
            ctx->bitlen += 512;
            ctx->datalen = 0;
        }
    }
}

void ksha_final(ksha_ctx *ctx, uint8_t *out) {
    unsigned long long bits = ctx->bitlen + (unsigned long long)ctx->datalen * 8;
    unsigned char tail[128];
    size_t padlen, i;

    padlen = (ctx->datalen < 56) ? (56 - ctx->datalen) : (120 - ctx->datalen);
    memset(tail, 0, sizeof(tail));
    memcpy(tail, ctx->data, ctx->datalen);
    tail[ctx->datalen] = 0x80;
    for (i = 0; i < 8; i++)
        tail[ctx->datalen + padlen + i] = (unsigned char)(bits >> (56 - i*8));

    if (ctx->datalen + padlen + 8 == 64) {
        k_sha_transform(ctx, tail);
    } else {
        k_sha_transform(ctx, tail);
        k_sha_transform(ctx, tail + 64);
    }
    for (i = 0; i < 8; i++) {
        out[i*4]   = (uint8_t)(ctx->state[i] >> 24);
        out[i*4+1] = (uint8_t)(ctx->state[i] >> 16);
        out[i*4+2] = (uint8_t)(ctx->state[i] >> 8);
        out[i*4+3] = (uint8_t)(ctx->state[i]);
    }
}

/* 一步到位 SHA-256。存在的理由同 ncg_derive_k_so_from_der：ksha_ctx 是
 * 不透明句柄，密文段里的调用方开不出栈对象。与三步式逐字节等价。 */
void ksha256(const uint8_t *data, size_t len, uint8_t out[32]) {
    ksha_ctx ctx;
    ksha_init(&ctx);
    ksha_update(&ctx, data, len);
    ksha_final(&ctx, out);
}

/* ── HMAC-SHA256（RFC 2104，照抄 Xop crypto/sha256.cpp:123）──────── */
void khmac_sha256(const uint8_t *key,size_t key_len,
                  const uint8_t *msg,size_t msg_len,uint8_t out[32]){
    uint8_t k0[64],ipad[64],opad[64],inner[32]; ksha_ctx c; size_t i;
    memset(k0,0,64);
    if(key_len>64){ksha_ctx t; ksha_init(&t);ksha_update(&t,key,key_len);ksha_final(&t,k0);}
    else memcpy(k0,key,key_len);
    for(i=0;i<64;i++){ipad[i]=k0[i]^0x36;opad[i]=k0[i]^0x5c;}
    ksha_init(&c);ksha_update(&c,ipad,64);ksha_update(&c,msg,msg_len);ksha_final(&c,inner);
    ksha_init(&c);ksha_update(&c,opad,64);ksha_update(&c,inner,32);ksha_final(&c,out);
}

/* ── 增量 HMAC（2026-10-19）─────────────────────────────────────────
 * 动机：.ncx 与 .ncxr 是两段不连续内存，一次性算 HMAC 需要
 * 先把两段拼接进临时缓冲（最多几十 KB）。增量式零额外内存、零拷贝。
 *
 * 完整性：与 khmac_sha256(key, m1||m2) 逐字节等价 —— 由
 * scripts/lib/tests/test-so-lock.sh 的 HMAC 对拍项钉死。
 *
 * 结构（RFC 2104）：
 *   inner = SHA(ipad || m1 || m2 || ...)
 *   out   = SHA(opad || inner)
 * 故 ctx 里保存：内层 SHA 上下文 + 已算好的 opad（32 字节未压缩的 k0^0x5c）
 * 不能在 final 时再算 opad——feed 阶段 key 已不在手上。
 * ⚠️ k0 必须先清零再用：key_len<64 时 memcpy 只写前 klen 字节，
 *    后面 64-klen 必须是 0（哈希块填充语义）。 */
struct khmac_ctx_s {
    ksha_ctx inner;          /* 内层 SHA 上下文 */
    uint8_t  opad[64];       /* 外层 pad（k0 ^ 0x5c），final 时用 */
};

/* 编译期把关：.h 里声明的 KHMAC_CTX_SIZE 必须 >= 实际结构体大小。
 * 不一致会在这里直接编译失败，而不是运行期栈溢出（那种 bug 极难查）。 */
typedef char khmac_size_check_t[
    (sizeof(struct khmac_ctx_s) <= KHMAC_CTX_SIZE) ? 1 : -1];

void khmac_init(khmac_ctx *ctx,const uint8_t *key,size_t key_len){
    uint8_t k0[64]; size_t i;
    memset(k0,0,sizeof k0);
    if(key_len>64){ksha_init(&ctx->inner);ksha_update(&ctx->inner,key,key_len);
        ksha_final(&ctx->inner,k0);}
    else memcpy(k0,key,key_len);
    for(i=0;i<64;i++) ctx->opad[i]=(uint8_t)(k0[i]^0x5c);
    {
        uint8_t ipad[64];
        for(i=0;i<64;i++) ipad[i]=(uint8_t)(k0[i]^0x36);
        ksha_init(&ctx->inner);
        ksha_update(&ctx->inner,ipad,64);
        memset(ipad,0,sizeof ipad);
    }
    memset(k0,0,sizeof k0);
}

void khmac_update(khmac_ctx *ctx,const uint8_t *data,size_t len){
    ksha_update(&ctx->inner,data,len);
}

void khmac_final(khmac_ctx *ctx,uint8_t out[32]){
    uint8_t inner[32];
    ksha_ctx outer;
    ksha_final(&ctx->inner,inner);
    ksha_init(&outer);
    ksha_update(&outer,ctx->opad,64);
    ksha_update(&outer,inner,32);
    ksha_final(&outer,out);
    memset(inner,0,sizeof inner);
    memset(ctx,0,sizeof *ctx);
}

/* ── HKDF-SHA256（RFC 5869，extract-then-expand）───────────────────
 * 与 so-section-lock.py 的 hkdf_sha256() 逐字节同算法：
 *   prk = HMAC(salt, ikm)
 *   okm = T(1)||T(2)||... , T(i)=HMAC(prk, T(i-1)||info||i)
 */
void khkdf_sha256(const uint8_t *ikm,size_t ikm_len,
                  const uint8_t *salt,size_t salt_len,
                  const uint8_t *info,size_t info_len,
                  uint8_t *out,size_t out_len){
    /* RFC 5869 expand：T(i) = HMAC(prk, T(i-1) || info || i)。
     * ⚠️ info 严禁截断——我第一版写了 `if(info_len>32) info_len=32`，
     * RFC 测试向量因此全错（34104666... vs 3cb25f25...）。info 极短
     * （label+pkg < 64B）但语义上必须完整传入。 */
    uint8_t prk[32],t[32]; size_t done=0; uint8_t counter=1;
    uint8_t msg[96]; size_t msglen;
    khmac_sha256(salt,salt_len,ikm,ikm_len,prk);
    memset(t,0,sizeof t);
    while(done<out_len){
        size_t n=0;
        if(counter>1){ memcpy(msg,t,32); n=32; }
        if(info_len){ size_t cp=info_len; if(cp>sizeof msg-1) cp=sizeof msg-1;
                      memcpy(msg+n,info,cp); n+=cp; }
        msg[n++]=counter;
        msglen=n;
        khmac_sha256(prk,32,msg,msglen,t);
        { size_t take=out_len-done; if(take>32)take=32; memcpy(out+done,t,take); done+=take; }
        counter++;
    }
    memset(prk,0,sizeof prk);
}

/* ── APK 第一签名者证书 DER 的定点读 ─────────────────────────────
 * 照抄 Xop crypto/apk_sign.cpp 的 parse_apk：只读 EOCD 尾区 + Signing
 * Block，不读整个 APK（4.6MB → 几十 KB）。v3 优先，回退 v2。
 * 与 sig_guard2.c 的 g2_extract_cert 同逻辑，但此处自带以免依赖 static 符号。 */
static int rd_at(int fd,uint64_t off,void *buf,size_t n){
    return pread(fd,buf,n,(off_t)off)==(ssize_t)n?0:-1;
}
static uint32_t le32(const uint8_t*p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint64_t le64(const uint8_t*p){uint64_t v=0;int i;for(i=7;i>=0;i--)v=v<<8|p[i];return v;}

/* v2/v3 scheme block 里第一个 certificate 的 DER */
/* 从 v2/v3 scheme 块里取第一张证书 DER。
 *
 * ⚠️ 2026-10-19 重写。旧实现（从 signed_data 尾部反推"证书数"）是错的：
 * APK Sig Scheme v2/v3 的 certificates 段是【长度前缀序列】，压根没有
 * "证书数量"字段。旧代码把 `i+sl-4` 处的字节当证书数，实测在真 APK 上
 * 取到 920551173，`certs<n` 判假 → 100% 失败（该函数此前无调用方，
 * 所以从未暴露；P1-a 落地时才被实测抓到）。
 *
 * 规范布局（https://source.android.com/docs/security/features/apksigning/v2）：
 *   signer      = signed_data_len(4) + signed_data + signatures
 *                 + public_key_len(4) + public_key
 *   signed_data = digests_len(4) + digests
 *               + certificates_len(4) + [cert_len(4) + cert_der]...
 *                 + additional_attrs_len(4) + ...
 *
 * 入参 p 指向【单个 signer】的起点（已跳过外层 signers_len 与 signer_len），
 * n 是 signer 块长度。 */
static int first_cert_der(const uint8_t *p,size_t n,const uint8_t **der,uint32_t *der_len){
    if(n<12) return -1;
    uint32_t sd_len=le32(p);                 /* signed_data 长度 */
    if(sd_len<8||(size_t)sd_len+4>n) return -1;
    const uint8_t *sd=p+4;
    size_t q=0;
    uint32_t dg=le32(sd+q);                  /* digests_len */
    if(dg<4||(size_t)dg+8>sd_len) return -1;
    q+=4+(size_t)dg;
    uint32_t certs_len=le32(sd+q);           /* certificates 段总长 */
    q+=4;
    if(certs_len<4||q+(size_t)certs_len>sd_len) return -1;
    uint32_t cl=le32(sd+q);                  /* 第一张证书长度 */
    q+=4;
    if(cl==0||cl>certs_len-4||q+(size_t)cl>sd_len) return -1;
    *der=sd+q; *der_len=cl;
    return 0;
}

/* 从 scheme 块（v2/v3 的 value）里定位第一个 signer。
 *   signers     = signers_len(4) + [signer_len(4) + signer]...
 * 兼容 signers_len 写成"1"（= signer 个数）的实现差异——两种都能走通。 */
static int apk_first_cert_der_from_scheme(const uint8_t *s,size_t sn,
                                          const uint8_t **der,uint32_t *der_len){
    if(!s||sn<12) return -1;
    size_t off=4;                            /* 跳 signers_len */
    /* 先按规范：signers_len 是字节数，紧跟 signer_len(4) */
    if(off+4<=sn){
        uint32_t sl=le32(s+off);
        if(sl>=12&&off+4+(size_t)sl<=sn){
            if(first_cert_der(s+off+4,sl,der,der_len)==0) return 0;
        }
    }
    /* 回退：把第一个 4 字节当 signer 个数(=1)，后面直接是 signer_len */
    {
        uint32_t cnt=le32(s);
        if(cnt>=1&&cnt<=8&&off+4<=sn){
            uint32_t sl=le32(s+off);
            if(sl>=12&&off+4+(size_t)sl<=sn)
                if(first_cert_der(s+off+4,sl,der,der_len)==0) return 0;
        }
    }
    return -1;
}

int ncg_apk_first_cert_der(const char *apk_path,uint8_t *der,size_t der_cap,size_t *der_len){
    int fd=open(apk_path,O_RDONLY);
    if(fd<0) return -1;
    struct stat st; if(fstat(fd,&st)!=0||st.st_size<64){close(fd);return -1;}
    uint64_t fsize=(uint64_t)st.st_size;
    uint8_t eocd[22];

    /* 1) EOCD：尾部前 64KB 内反向找 PK\x05\x06
     *
     * ⚠️ 2026-10-19：改成【一次性读 64KB 到内存扫】，不再逐字节 pread。
     * 旧实现每个偏移一次 syscall，最坏情况（EOCD 带 64KB 注释，合法且常见）
     * 要 65535 次 pread。实测 on-device 级存储上 92 ms —— 一旦 P1-a 上
     * 运行期，这就是可见的启动卡顿。改后同一最坏样本 74.8 us（1234x）。
     * 内存需求 64KB 缓冲。
     *
     * ⚠️ 2026-10-21 由 static 改为 malloc/free：static 让 64KB 常驻 .bss
     * 至进程死亡（全进程 .bss 由此一项占掉近一半），而本函数只在
     * constructor 跑一次，malloc 的开销（微秒级）与"一次性"语义完全匹配。
     * 本函数为冻结模块，此改动经用户授权；16 条 return 路径中缓冲存活
     * 区间内的 3 条均已补 free（下方三处）。 */
    {
        uint8_t *tail=(uint8_t*)malloc(65557);
        if(!tail){close(fd);return -1;}
        uint64_t start=fsize>65557?fsize-65557:0;
        size_t len=(size_t)(fsize-start);
        if(rd_at(fd,start,tail,len)!=0){free(tail);close(fd);return -1;}
        long eo=-1;
        if(len>=22){
            for(size_t i=len-22+1;i-->0;)
                if(tail[i]==0x50&&tail[i+1]==0x4b&&tail[i+2]==0x05&&tail[i+3]==0x06){
                    eo=(long)i;break;
                }
        }
        if(eo<0){free(tail);close(fd);return -1;}
        memcpy(eocd,tail+eo,22);
        free(tail);
    }
    uint64_t cd_off=le32(eocd+16);
    if(cd_off<32||cd_off>=fsize){close(fd);return -1;}

    /* 2) Signing Block footer：cd_off-24 处 size+magic
     * 照抄 XopProtector crypto/apk_sign.cpp:21-22：
     *   kMagicLo = 0x20676953204b5041 ("APK Sig ")
     *   kMagicHi = 0x3234206b636f6c42 ("Block 42")
     * ⚠️ 我第一版凭印象编了 0x342e726f6e6f632e / 0x2e706f6f6c，小端解出来是
     * ".conor.4" / "loop." —— magic 永不匹配，真 APK 提取必失败。 */
    uint8_t footer[24];
    if(rd_at(fd,cd_off-24,footer,24)!=0){close(fd);return -1;}
    if(le64(footer+8)!=0x20676953204b5041ULL||le64(footer+16)!=0x3234206b636f6c42ULL){
        close(fd);return -1;
    }
    uint64_t block_size=le64(footer);
    if(block_size<24||block_size+8>cd_off){close(fd);return -1;}
    uint64_t total=block_size+8, block_off=cd_off-total;
    if(total>der_cap+4096){close(fd);return -1;}     /* 防御性上限 */

    /* 3) 只把 block 读进缓冲，再在其中找 v3/v2 的 id-value 对
     *
     * ⚠️ 2026-10-21 由 static 改为 malloc/free（理由同上方 tail 块）。
     * ⚠️⚠️ free 必须放在【函数末尾、memcpy(der,cd,cl) 之后】：
     *   v3/v2 是指向 blk 内部的指针（apk_first_cert_der_from_scheme
     *   返回的 der 也指向 blk 内），提前 free = use-after-free。
     *   下方每条提前 return 的路径都补了 free(blk)。 */
    uint8_t *blk=(uint8_t*)malloc(65536);
    if(!blk){close(fd);return -1;}
    if(total>65536){free(blk);close(fd);return -1;}
    if(rd_at(fd,block_off,blk,(size_t)total)!=0){free(blk);close(fd);return -1;}
    if(le64(blk)!=block_size){free(blk);close(fd);return -1;}

    /* id-value 对遍历：APK Sig Block v2=0x7109871a, v3=0xf05368c0 */
    const uint8_t *v3=NULL,*v2=NULL; size_t v3n=0,v2n=0;
    {   size_t i=8;
        while(i+12<=total){
            uint64_t pl=le64(blk+i); i+=8;
            if(pl<4||i+pl>total) break;
            uint32_t id=le32(blk+i);
            const uint8_t *val=blk+i+4; size_t vn=(size_t)pl-4;
            if(id==0xf05368c0U){v3=val;v3n=vn;}
            else if(id==0x7109871aU){v2=val;v2n=vn;}
            i+=pl;
        }
    }
    const uint8_t *cd=NULL; uint32_t cl=0;
    if(v3&&apk_first_cert_der_from_scheme(v3,v3n,&cd,&cl)==0) ;
    else if(v2&&apk_first_cert_der_from_scheme(v2,v2n,&cd,&cl)==0) ;
    else {free(blk);close(fd);return -1;}
    if((size_t)cl>der_cap){free(blk);close(fd);return -1;}
    memcpy(der,cd,cl); *der_len=cl;
    free(blk);
    close(fd);
    return 0;
}

/* ── 派生 K_so（与 so-section-lock.py 的 derive_app_keys['so'] 一致）──
 * k_so = HKDF-SHA256(ikm=master, salt=SHA256(certDER), info="nc-so-v1"+pkg, 16) */
int ncg_derive_k_so(const uint8_t master[32],const uint8_t cert_sha256[32],
                    const char *pkg,uint8_t out[16]){
    if(!master||!cert_sha256||!pkg||!pkg[0]||!out) return -1;
    uint8_t info[128]; size_t n=0; uint8_t lk[7];
    /* label 从密文表还原（2026-11-06 P0：消除 .rodata 明文锚点，见文件头）
     * 2026-11-08：基值不再统一 0x5A，从 SALT 派生（见 ncg_label_key） */
    ncg_label_key(lk);
    ncg_label_decode(ncg_label_enc_so, NCGL_SO, lk[0], info);
    n=NCGL_SO;
    { size_t l=strlen(pkg); if(l>sizeof info-9) l=sizeof info-9; memcpy(info+n,pkg,l); n+=l; }
    khkdf_sha256(master,32,cert_sha256,32,info,n,out,16);
    return 0;
}

/* 便捷版：吃 certDER，内部 SHA256(der) 再派生。
 * 存在的唯一理由：ksha_ctx 在 .h 里是不透明句柄，调用方在栈上开不出来；
 * head 本体是密文段里的代码，不宜为它引入额外依赖。
 * ⚠️ salt = SHA256(certDER)，不是 certDER 本身——必须与 Python 侧
 *    apk_first_signer_cert_sha256() 逐字节一致。 */
int ncg_derive_k_so_from_der(const uint8_t master[32],
                             const uint8_t *cert_der,size_t der_len,
                             const char *pkg,uint8_t out[16]){
    if(!master||!cert_der||!der_len||!pkg||!pkg[0]||!out) return -1;
    uint8_t sha[32];
    ksha_ctx ctx;
    ksha_init(&ctx);
    ksha_update(&ctx,cert_der,der_len);
    ksha_final(&ctx,sha);
    int rc=ncg_derive_k_so(master,sha,pkg,out);
    memset(sha,0,sizeof sha);
    return rc;
}

/* mac 域同上（label "nc-so-mac-v1"）。与 so 域必须硬分隔：
 * 复用同一把钥匙 = 知道 RC4 密钥即可伪造 MAC，完整性校验形同虚设。 */
int ncg_derive_k_mac_from_der(const uint8_t master[32],
                              const uint8_t *cert_der,size_t der_len,
                              const char *pkg,uint8_t out[16]){
    if(!master||!cert_der||!der_len||!pkg||!pkg[0]||!out) return -1;
    uint8_t sha[32];
    ksha_ctx ctx;
    ksha_init(&ctx);
    ksha_update(&ctx,cert_der,der_len);
    ksha_final(&ctx,sha);
    int rc=ncg_derive_k_mac(master,sha,pkg,out);
    memset(sha,0,sizeof sha);
    return rc;
}

/* ── 派生 K_mac（与 so-section-lock.py 的 derive_app_keys['mac'] 一致）──
 * k_mac = HKDF-SHA256(ikm=master, salt=SHA256(certDER), info="nc-so-mac-v1"+pkg, 16)
 * 2026-12 完整性校验专用：只参与 .ncx 密文的 HMAC 计算，绝不与 so 域复用
 * 同一把钥匙（复用 = 知道 RC4 密钥即可伪造 MAC，校验形同虚设）。 */
int ncg_derive_k_mac(const uint8_t master[32],const uint8_t cert_sha256[32],
                     const char *pkg,uint8_t out[16]){
    if(!master||!cert_sha256||!pkg||!pkg[0]||!out) return -1;
    uint8_t info[128]; size_t n=0; uint8_t lk[7];
    ncg_label_key(lk);
    ncg_label_decode(ncg_label_enc_mac, NCGL_MAC, lk[1], info);
    n=NCGL_MAC;
    { size_t l=strlen(pkg); if(l>sizeof info-13) l=sizeof info-13; memcpy(info+n,pkg,l); n+=l; }
    khkdf_sha256(master,32,cert_sha256,32,info,n,out,16);
    return 0;
}

/* ── 派生 K_so_r（与 so-section-lock.py 的 derive_app_keys['so_r'] 一致）──
 * k_so_r = HKDF-SHA256(ikm=master, salt=SHA256(certDER),
 *                      info="nc-so-r-v1"+pkg, 16)
 *
 * 2026-10-28 新增（逆向报告 §6.2）：.ncxr 常量表段专用密钥，隔断 RC4
 * keystream 跨段复用。此前 .ncx 与 .ncxr 都从 keystream 偏移 0 起，
 * 实测属于 two-time-pad 误用，已知 .ncxr 明文即可反推 .ncx 明文。
 *
 * ⚠️ 与 k_so / k_mac / k_stub 必须全部不同。改 label 必须同步 Python 侧
 *    derive_app_keys()（T20 跨语言对拍会抓不一致）。 */
int ncg_derive_k_so_r(const uint8_t master[32],const uint8_t cert_sha256[32],
                      const char *pkg,uint8_t out[16]){
    if(!master||!cert_sha256||!pkg||!pkg[0]||!out) return -1;
    uint8_t info[128]; size_t n=0; uint8_t lk[7];
    ncg_label_key(lk);
    ncg_label_decode(ncg_label_enc_so_r, NCGL_SO_R, lk[2], info);
    n=NCGL_SO_R;
    { size_t l=strlen(pkg); if(l>sizeof info-11) l=sizeof info-11; memcpy(info+n,pkg,l); n+=l; }
    khkdf_sha256(master,32,cert_sha256,32,info,n,out,16);
    return 0;
}

/* 便捷版：吃 certDER，内部 SHA256 再派生。存在的理由与
 * ncg_derive_k_so_from_der 完全相同（ksha_ctx 是不透明句柄，密文段里的
 * 调用方开不出栈对象）。 */
int ncg_derive_k_so_r_from_der(const uint8_t master[32],
                               const uint8_t *cert_der,size_t der_len,
                               const char *pkg,uint8_t out[16]){
    if(!master||!cert_der||!der_len||!pkg||!pkg[0]||!out) return -1;
    uint8_t sha[32];
    ksha_ctx ctx;
    ksha_init(&ctx);
    ksha_update(&ctx,cert_der,der_len);
    ksha_final(&ctx,sha);
    int rc=ncg_derive_k_so_r(master,sha,pkg,out);
    memset(sha,0,sizeof sha);
    return rc;
}

/* ── 派生 k_nct（与 so-section-lock.py 的 derive_app_keys['insn'] 一致）──
 * k_nct = HKDF-SHA256(ikm=master, salt=SHA256(certDER),
 *                     info="nc-insn-v1"+pkg, 16)
 *
 * 2026-11-13：.nct 段专用 —— 消费方（第二套）VMP 的字节码 / const_pool。
 *
 * 为什么这一段可以加密，而 .ncr（第一套）不行：
 *   .ncr 里的字节码属于本仓库自己的解密链。解它的钥匙要由 master 派生，
 *   而 master 要 k_stub，k_stub 要 boot_key，boot_key 由 ncg_boot_key 算
 *   —— 那个函数自己就被 VMP，字节码就在 .ncr 里。要解 .ncr 得先跑
 *   .ncr 里的代码，结构上无法同时满足。
 *   而 .nct 装的是消费方的 VMP（sig_check 等），那些函数在
 *   constructor(65535) 才第一次执行，那时本文件所在的解锁流程
 *   （constructor(50)）早已跑完，不存在循环依赖。
 *
 * ⚠️ 加密的只是【纯数据】：指针表（descriptor_table / native_call_table）
 *    由 amice 分到 .ncd，**不能加密** —— 那些位置是 R_AARCH64_RELATIVE
 *    重定位槽，dlopen 时由动态链接器填真值，解锁时写回会覆盖掉它们
 *    → 垃圾指针 → 解释器跳错地址 → 真机 SIGILL（2026-11-12 实测）。
 *
 * ⚠️ label 必须与 so-section-lock.py 的 derive_app_keys() 的
 *    ('nc-insn-v1', 'insn') 逐字节一致。 */
int ncg_derive_k_nct(const uint8_t master[32],const uint8_t cert_sha256[32],
                     const char *pkg,uint8_t out[16]){
    if(!master||!cert_sha256||!pkg||!pkg[0]||!out) return -1;
    uint8_t info[128]; size_t n=0; uint8_t lk[7];
    ncg_label_key(lk);
    ncg_label_decode(ncg_label_enc_insn, NCGL_INSN, lk[4], info);
    n=NCGL_INSN;
    { size_t l=strlen(pkg); if(l>sizeof info-11) l=sizeof info-11; memcpy(info+n,pkg,l); n+=l; }
    khkdf_sha256(master,32,cert_sha256,32,info,n,out,16);
    return 0;
}

/* ── 派生 k_bc（.ncq VM 字节码段，2026-11-13）──────────────────────────
 * k_bc = HKDF-SHA256(ikm=master, salt=SHA256(certDER),
 *                    info="nc-warm-v1"+pkg, 16)
 *
 * 与 so-section-lock.py 的 derive_app_keys()['warm'] 逐字节一致。
 * ⚠️ 为什么不复用 k_nct：RC4 是流密码，两段共用 keystream = two-time-pad
 *    误用（本项目 2026-10-28 在 .ncx/.ncxr 上踩过：C_a[i]^C_b[i] == P_a[i]^P_b[i]）。
 */
int ncg_derive_k_bc(const uint8_t master[32],const uint8_t cert_sha256[32],
                    const char *pkg,uint8_t out[16]){
    if(!master||!cert_sha256||!pkg||!pkg[0]||!out) return -1;
    uint8_t info[128]; size_t n=0; uint8_t lk[7];
    ncg_label_key(lk);
    ncg_label_decode(ncg_label_enc_bc, NCGL_BC, lk[5], info);
    n=NCGL_BC;
    { size_t l=strlen(pkg); if(l>sizeof info-11) l=sizeof info-11; memcpy(info+n,pkg,l); n+=l; }
    khkdf_sha256(master,32,cert_sha256,32,info,n,out,16);
    return 0;
}

int ncg_derive_k_bc_from_der(const uint8_t master[32],
                             const uint8_t *cert_der,size_t der_len,
                             const char *pkg,uint8_t out[16]){
    if(!master||!cert_der||!der_len||!pkg||!pkg[0]||!out) return -1;
    uint8_t sha[32];
    ksha_ctx ctx;
    ksha_init(&ctx);
    ksha_update(&ctx,cert_der,der_len);
    ksha_final(&ctx,sha);
    int rc=ncg_derive_k_bc(master,sha,pkg,out);
    memset(sha,0,sizeof sha);
    return rc;
}

/* ── 派生 k_bc2（.ncv 消费方第二套字节码段，2026-11-13）─────────────
 * k_bc2 = HKDF-SHA256(..., info="nc-dex-v1"+pkg, 16)
 * 与 derive_app_keys()['dex'] 逐字节一致。
 * ⚠️ 与 k_bc（.ncq，第一套）必须不同：两套链接进同一个 so。 */
int ncg_derive_k_bc2(const uint8_t master[32],const uint8_t cert_sha256[32],
                     const char *pkg,uint8_t out[16]){
    if(!master||!cert_sha256||!pkg||!pkg[0]||!out) return -1;
    uint8_t info[128]; size_t n=0; uint8_t lk[7];
    ncg_label_key(lk);
    ncg_label_decode(ncg_label_enc_bc2, NCGL_BC2, lk[6], info);
    n=NCGL_BC2;
    { size_t l=strlen(pkg); if(l>sizeof info-11) l=sizeof info-11; memcpy(info+n,pkg,l); n+=l; }
    khkdf_sha256(master,32,cert_sha256,32,info,n,out,16);
    return 0;
}

int ncg_derive_k_bc2_from_der(const uint8_t master[32],
                              const uint8_t *cert_der,size_t der_len,
                              const char *pkg,uint8_t out[16]){
    if(!master||!cert_der||!der_len||!pkg||!pkg[0]||!out) return -1;
    uint8_t sha[32];
    ksha_ctx ctx;
    ksha_init(&ctx);
    ksha_update(&ctx,cert_der,der_len);
    ksha_final(&ctx,sha);
    int rc=ncg_derive_k_bc2(master,sha,pkg,out);
    memset(sha,0,sizeof sha);
    return rc;
}

/* 便捷版：吃 certDER。存在的理由与 ncg_derive_k_so_r_from_der 相同。 */
int ncg_derive_k_nct_from_der(const uint8_t master[32],
                              const uint8_t *cert_der,size_t der_len,
                              const char *pkg,uint8_t out[16]){
    if(!master||!cert_der||!der_len||!pkg||!pkg[0]||!out) return -1;
    uint8_t sha[32];
    ksha_ctx ctx;
    ksha_init(&ctx);
    ksha_update(&ctx,cert_der,der_len);
    ksha_final(&ctx,sha);
    int rc=ncg_derive_k_nct(master,sha,pkg,out);
    memset(sha,0,sizeof sha);
    return rc;
}

/* ── 还原 HKDF 的 boot label（2026-11-06 P0）────────────────────────
 * 给 ncg_boot_key 用（它在 nc_guard_crypto.c，为本文件的外部调用方）。
 *
 * 为什么不把 NC_BOOT_INFO 宏直接暴露过去：
 *   那个宏是字符串字面量，被任何 .c 引用就会以明文进 .rodata ——
 *   正是本文件头要消除的那个泄露点。改成函数把解码过程封起来，
 *   明文只存在于调用方的栈缓冲里，二进制中不留常量。
 *
 * 为什么不放进 nc_guard_layout.h 一起改：
 *   那是【产物格式契约】文件，且 so-section-lock.py:114 用正则
 *   `#define\s+NC_BOOT_INFO\s+"([^"]+)"` 从它抽取字符串给 Python 侧算。
 *   改成整数表会让该正则抽不到 → 锁箱直接 fail-fast。
 *   所以 layout.h 保留字符串（仅作 Python 的抽取源，本仓库 C 代码
 *   不再引用它 → 宏不进二进制，已实测确认）。
 *
 * out 需要至少 10 字节；返回写入长度（不含 NUL）。
 * ⚠️ 调用方用完应擦除缓冲（含密钥材料的派生输入）。 */
size_t ncg_label_boot(uint8_t *out, size_t cap) {
    if (!out || cap < NCGL_BOOT) return 0;
    uint8_t lk[7];
    ncg_label_key(lk);
    ncg_label_decode(ncg_label_enc_boot, NCGL_BOOT, lk[3], out);
    /* 基值用完即擦。不用 ncg_wipe：它定义在 nc_guard_boot.c，而本文件
     * 被 test-so-lock.sh 的 T32 对拍驱动【单独链接】（只链 nc_guard_key.c）
     * —— 引它会 undefined symbol。这里就地用 volatile 写 0，
     * 与 ncg_wipe 同语义（防 -Oz 当死存储删掉），零跨 TU 依赖。 */
    {
        volatile uint8_t *v = (volatile uint8_t *)lk;
        size_t i;
        for (i = 0; i < sizeof(lk); i++) v[i] = 0;
    }
    return NCGL_BOOT;
}
