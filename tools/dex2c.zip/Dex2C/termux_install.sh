#!/data/data/com.termux/files/usr/bin/bash

if ! command -v termux-setup-storage; then
  echo "This script can be executed only on Termux"
  exit 1
fi

termux-setup-storage

cd "$HOME" || exit

pkg update
pkg upgrade -y
pkg i -y ncurses-utils

green="$(tput setaf 2)"
nocolor="$(tput sgr0)"
red="$(tput setaf 1)"
blue="$(tput setaf 32)"
yellow="$(tput setaf 3)"
note="$(tput setaf 6)"
ollvm_enable=false

download_ndk() {
  local ver="$1"
  local name="$2"
  echo "${yellow}Warning! This NDK only for aarch64${nocolor}"
  echo "Selected this version $name ($ver) to install"
  mkdir -p "$HOME/android-sdk/ndk"
  wget "https://github.com/codehasan/dex2c/releases/download/ollvm-termux/android-ndk-$name.tar.xz" \
    --no-verbose --show-progress -N || {
    echo "${red}Download failed!${nocolor}"
    return 1
  }
  tar -xvf "android-ndk-$name.tar.xz" -C "$HOME/android-sdk/ndk"
  rm "android-ndk-$name.tar.xz"
  if [ "$name" == "r25c-ollvm-aarch64" ]; then
    echo "python3" > "$HOME/android-sdk/ndk/$ver/toolchains/llvm/prebuilt/linux-x86_64/python3/bin/python3"
  fi
}

echo "${green}━━━ Basic Requirements Setup ━━━${nocolor}"

pkg install -y python git cmake rust clang make wget ndk-sysroot zlib libxml2 libxslt pkg-config libjpeg-turbo build-essential binutils openssl aapt
# UnComment below line if you face clang error during installation procedure
# _file=$(find $PREFIX/lib/python3.11/_sysconfigdata*.py)
# rm -rf $PREFIX/lib/python3.11/__pycache__
# sed -i 's|-fno-openmp-implicit-rpath||g' "$_file"
pkg install -y python-cryptography
LDFLAGS="-L${PREFIX}/lib/" CFLAGS="-I${PREFIX}/include/" pip install --upgrade wheel pillow
pip install cython setuptools
CFLAGS="-Wno-error=incompatible-function-pointer-types -O0" pip install --upgrade lxml

echo "${green}━━━ Starting SDK Tools installation ━━━${nocolor}"
if [ -d "android-sdk" ]; then
  echo "${red}Seems like sdk tools already installed, skipping...${nocolor}"
elif [ -d "androidide-tools" ]; then
  rm -rf androidide-tools
  git clone https://github.com/AndroidIDEOfficial/androidide-tools
  cd androidide-tools/scripts || exit
  ./idesetup -c
else
  git clone https://github.com/AndroidIDEOfficial/androidide-tools
  cd androidide-tools/scripts || exit
  ./idesetup -c
fi

echo "${yellow}ANDROID SDK TOOLS Successfully Installed!${nocolor}"

cd "$HOME" || exit
echo "${green}━━━ Starting NDK installation ━━━${nocolor}"
echo "Would you like to enable support for OLLVM ?"
echo "Please note that ollvm support requires heavy resources and might not work/hang your device if enabled on low-end devices."
read -r -p "(Y/n) > " enable_ollvm
if [[ $enable_ollvm == "y" || $enable_ollvm == "Y" ]]; then
  ollvm_enable=true
  ndk_ver=""
  ndk_ver_name=""
  echo "${yellow}Select which NDK version you need to install?${nocolor}"
  echo "Skip (q) if you've it installed already"
  select item in r25c r28c; do
    case $item in
    "r25c")
      ndk_ver="25.2.9519653"
      ndk_ver_name="r25c-ollvm-aarch64"
      download_ndk "$ndk_ver" "$ndk_ver_name"
      break
      ;;
    "r28c")
      ndk_ver="28.2.13676358"
      ndk_ver_name="r28c"
      download_ndk "$ndk_ver" "$ndk_ver_name"
      break
      ;;
    *)
      echo "${yellow}No OLLVM NDK selected, skipping download.${nocolor}"
      echo "Will try to use already installed NDK instead if found..."
      break
      ;;
    esac
  done
else
  echo "Now You'll be asked about which version of NDK to isntall"
  echo "${note}If your Android Version is 9 or above then choose ${red}'9'${nocolor}"
  echo "${note}If your Android Version is below 9 or if you faced issues with '9' (A9 and above users) then choose ${red}'8'${nocolor}"
  echo "${red} If you're choosing other options then you're on your own and experiment yourself ¯⁠\⁠_⁠ಠ⁠_⁠ಠ⁠_⁠/⁠¯${nocolor}"
  if [ -f "ndk-install.sh" ]; then
    chmod +x ndk-install.sh && bash ndk-install.sh
  else
    cd && echo -ne "Prepering, please wait..." && pkg upgrade &>/dev/null && pkg install wget &>/dev/null && wget -q https://github.com/MrIkso/AndroidIDE-NDK/raw/main/ndk-install.sh -N && echo -ne "\r                     \r" && chmod +x ndk-install.sh && bash ndk-install.sh
  fi

  if [ -f "ndk-install.sh" ]; then
    rm ndk-install.sh
  fi
fi

ndk_versions=("17.2.4988734" "18.1.5063045" "19.2.5345600" "20.1.5948944" "21.4.7075529" "22.1.7171670" "23.2.8568313" "24.0.8215888" "26.1.10909125" "27.1.12297006" "27.2.12479018" "28.1.13356709" "29.0.13113456" "27.3.13750724" "26.3.11579264" "28.2.13676358" "29.0.14033849-beta4" "23.1.7779620" "25.2.9519653" "29.0.14206865")

installed=()
for v in "${ndk_versions[@]}"; do
  [ -d "$HOME/android-sdk/ndk/$v" ] && installed+=("$v")
done

ndk_version=""
if [ ${#installed[@]} -gt 1 ]; then
  echo "Multiple NDK versions found:"
  for i in "${!installed[@]}"; do
    echo "$((i + 1))) ${installed[i]}"
  done

  while true; do
    read -rp "Hit Enter to auto-select (${installed[0]}), or choose one: " choice
    case "$choice" in
    "")
      ndk_version="${installed[0]}"
      break
      ;;
    *[!0-9]*)
      echo "Invalid input, try again."
      ;;
    *)
      ndk_version="${installed[$((choice - 1))]}"
      if [ -n "$ndk_version" ]; then
        break
      else
        echo "Invalid selection, try again."
      fi
      ;;
    esac
  done
fi

if [ -z "$ndk_version" ]; then
  for v in "${ndk_versions[@]}"; do
    if [ -d "$HOME/android-sdk/ndk/$v" ]; then
      ndk_version="$v"
      break
    fi
  done
fi

echo "Using NDK version: $ndk_version"

if [ -z "$ndk_version" ]; then
  echo "${red}You didn't install any NDK. Terminating!"
  exit 1
fi
echo "${yellow}ANDROID NDK Successfully Installed!${nocolor}"

cd "$HOME" || exit
if [ -d "dex2c" ]; then
  cd dex2c || exit
elif [ -f "dcc.py" ] && [ -d "tools" ]; then
  :
else
  git clone https://github.com/ratsan/dex2c || exit 2
  cd dex2c || exit 2
fi

if [ -f "$HOME/dex2c/tools/apkeditor.jar" ]; then
  rm $HOME/dex2c/tools/apkeditor.jar
  cp $PREFIX/bin/apkeditor.jar $HOME/dex2c/tools/apkeditor.jar
else
  sh -c 'wget https://github.com/REAndroid/APKEditor/releases/download/V1.4.1/APKEditor-1.4.1.jar -O $HOME/dex2c/tools/apkeditor.jar'
fi

cd ~/dex2c || exit
python3 -m pip install -r requirements.txt || exit 2

update_rc() {
  local file="$1"
  sed -i '/export ANDROID_HOME=/d' "$file"
  sed -i '/export PATH=.*\/android-sdk\/cmdline-tools\/latest\/bin/d' "$file"
  sed -i '/export PATH=.*\/android-sdk\/platform-tools/d' "$file"
  sed -i '/export PATH=.*\/android-sdk\/build-tools\/34.0.4/d' "$file"
  sed -i '/export PATH=.*\/android-sdk\/ndk\/.*/d' "$file"
  sed -i '/export ANDROID_NDK_ROOT=/d' "$file"

  echo -e "export ANDROID_HOME=$HOME/android-sdk\nexport PATH=\$PATH:$HOME/android-sdk/cmdline-tools/latest/bin\nexport PATH=\$PATH:$HOME/android-sdk/platform-tools\nexport PATH=\$PATH:$HOME/android-sdk/build-tools/34.0.4\nexport PATH=\$PATH:$HOME/android-sdk/ndk/$ndk_version\nexport ANDROID_NDK_ROOT=$HOME/android-sdk/ndk/$ndk_version" >>"$file"
}

update_xonsh_rc() {
  local file="$1"
  sed -i "/\$ANDROID_HOME =/d" "$file"
  sed -i "/\$PATH.*\/android-sdk\/cmdline-tools\/latest\/bin/d" "$file"
  sed -i "/\$PATH.*\/android-sdk\/platform-tools/d" "$file"
  sed -i "/\$PATH.*\/android-sdk\/build-tools\/34.0.4/d" "$file"
  sed -i "/\$PATH.*\/android-sdk\/ndk\/.*/d" "$file"
  sed -i "/\$ANDROID_NDK_ROOT =/d" "$file"
  cat <<EOF >>"$file"
\$ANDROID_HOME = "${HOME}/android-sdk"
\$PATH.append('${HOME}/android-sdk/cmdline-tools/latest/bin')
\$PATH.append('${HOME}/android-sdk/platform-tools')
\$PATH.append('${HOME}/android-sdk/build-tools/34.0.4')
\$PATH.append('${HOME}/android-sdk/ndk/${ndk_version}')
\$ANDROID_NDK_ROOT = "${HOME}/android-sdk/ndk/${ndk_version}"
EOF
}

if [ -f "$HOME/.bashrc" ]; then
  update_rc "$HOME/.bashrc"
fi
if [ -f "$HOME/.zshrc" ]; then
  update_rc "$HOME/.zshrc"
fi
if [ -f "$HOME/.xonshrc" ]; then
  update_xonsh_rc "$HOME/.xonshrc"
fi
if [ -f "$PREFIX/etc/bash.bashrc" ]; then
  update_rc "$PREFIX/etc/bash.bashrc"
fi

cat >"$HOME"/dex2c/dcc.cfg <<EOL
{
    "apkeditor": "tools/apkeditor.jar",
    "ndk_dir": "$HOME/android-sdk/ndk/${ndk_version}",
    "signature": {
        "keystore_path": "keystore/debug.keystore",
        "alias": "androiddebugkey",
        "keystore_pass": "android",
        "store_pass": "android",
        "v1_enabled": true,
        "v2_enabled": true,
        "v3_enabled": true
    },
    "ollvm": {
        "enable": $ollvm_enable,
        "flags": "-fvisibility=hidden -mllvm -fla -mllvm -split -mllvm -split_num=5 -mllvm -sub -mllvm -sub_loop=5 -mllvm -sobf -mllvm -bcf_loop=5 -mllvm -bcf_prob=100"
    }
}
EOL

echo "${green}============================"
echo "Great! dex2c installed successfully!"
echo "============================${nocolor}"
