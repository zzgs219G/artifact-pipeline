LOCAL_PATH:= $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE    := stub
LOCAL_LDLIBS    := -llog

LOCAL_LDFLAGS += "-Wl,-z,max-page-size=16384"

SOURCES := $(wildcard $(LOCAL_PATH)/nc/*.cpp)
LOCAL_C_INCLUDES := $(LOCAL_PATH)/nc

LOCAL_SRC_FILES := $(SOURCES:$(LOCAL_PATH)/%=%)

include $(BUILD_SHARED_LIBRARY)
